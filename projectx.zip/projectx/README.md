# ProjectX: UAV Command & Control (C2)

Web application to monitor UAVs (ground and air, water in the future) on a live map and send them to a destination.

- **Backend:** Python, FastAPI, PostgreSQL
- **Frontend:** React, TypeScript, MapLibre GL
- **Communication:** HTTP and WebSocket (browser to backend), Zenoh pub/sub (backend to assets)
- **Assets:** X-Verse (simulator, drives CARLA) and real drones on the same network
- **Packaging:** Docker Compose

## Quickstart

### 1. Get the code and configure
```
git clone <repository-url> projectx
cd projectx
cp .env.example .env        # defaults work for local development
```
You need Git, Docker with Compose v2 and `make`. On Windows use WSL (see [docs/windows-wsl-setup.md](docs/windows-wsl-setup.md)).

With Docker you do **not** need `npm install` or `uv sync`: the images install everything. You only install dependencies by hand when you run the apps outside Docker (see [section 3](#3-run-frontend-and-backend-separately)).

### 2. Pick the command for your role
| You are... | Run | What you get |
|---|---|---|
| Trying the app, a demo, or working on the UI | `make up` | Built-in simulator. No Zenoh. Works on its own. |
| A C2 developer | `make mock` | Zenoh with the **X-Verse mock**: it publishes assets and answers commands. Console on :5174. |
| An X-Verse / CARLA developer | `make carla` | Zenoh with a **real X-Verse/CARLA**. A passive console listens on :7447 (CARLA connects there) and :5174. Positions are CARLA metres. |
| Using a **real drone** (or any Zenoh node with real lat/lon) | `ZENOH_CONNECT=<ip> make zenoh` | Only the C2 stack, connected to that Zenoh node. Positions are lat/lon. Do not use `make carla` for this: it converts positions as CARLA metres. |

Stop everything with `make down`. Open http://localhost:5173 when it is up.

Which data source is used? Open **Settings** in the top bar, or read the backend log at startup: it prints the driver, the Zenoh endpoint and where the settings came from.

### Make commands

| Command | What it does |
|---|---|
| `make` or `make up` | Builds and starts the full stack with the simulator. If `ZENOH_CONNECT` is set and `C2_DRIVER` is empty, it uses Zenoh instead. |
| `make mock` | Stack plus the X-Verse mock, with `C2_DRIVER=zenoh`. For faster flights: `MOCK_TIME_SCALE=20 make mock`. |
| `make carla` | Stack plus a passive console for a real X-Verse/CARLA (`C2_POSITION_FORMAT=carla`). Optional `CARLA_ZENOH=<ip>` to use another Zenoh node. |
| `make zenoh` | Stack connected to the Zenoh node in `ZENOH_CONNECT`, for real drones. Fails if it is not set. |
| `make down` | Stops and removes the Compose containers. |
| `make test` | Runs backend pytest and frontend tests in containers. |
| `make test-mock` | Runs the X-Verse mock unit and contract tests on the host with `uv`. |
| `make lint` | Runs backend Ruff and frontend TypeScript checks. |
| `make migrate` | Applies pending Alembic database migrations. |

**Good to know**
- `C2_DRIVER` empty (the default) means: Zenoh if `ZENOH_CONNECT` is set, simulator otherwise. Setting `C2_DRIVER=sim` forces the simulator.
- Settings saved in the **Settings** screen are kept in the database and **win over** the environment at the next start. If the app ignores your variables, open Settings and use **Reset**.
- With the Zenoh driver and an empty `ZENOH_CONNECT`, the backend discovers Zenoh nodes by multicast. Always set an endpoint when you can reach real assets.

### URLs
- Frontend: http://localhost:5173 (top bar **Settings**: driver, Zenoh endpoint, operator, speed; admin token `dev-admin` by default, see [docs/zenoh-driver.md](docs/zenoh-driver.md#settings-screen-c2-top-bar---settings))
- **Zenoh console** (`make mock` and `make carla`): http://localhost:5174. It logs the Zenoh messages and has a form to publish messages by hand. See [docs/zenoh-driver.md](docs/zenoh-driver.md#mock-developer-console-httplocalhost5174). The C2 top bar also links to it.
- API docs: http://localhost:8000/docs
- OpenAPI JSON: http://localhost:8000/openapi.json
- Endpoint reference, including WebSocket: [docs/api.md](docs/api.md)
- Backend command/Zenoh/frontend integration guide: [docs/backend-zenoh-frontend.md](docs/backend-zenoh-frontend.md)

### 3. Run frontend and backend separately
Only for hot reload and debugging. Here you install dependencies yourself: Python 3.12 + [uv](https://docs.astral.sh/uv/) for the backend, Node 20+ with pnpm (`corepack enable`) for the frontend. Start only the database (Docker), then run each app in its own terminal:
```
docker compose up postgres                      # terminal 1: PostgreSQL on localhost:5432

cd backend                                      # terminal 2: backend
uv sync --extra dev
DATABASE_URL=postgresql+psycopg://c2:c2@localhost:5432/c2 uv run alembic upgrade head
DATABASE_URL=postgresql+psycopg://c2:c2@localhost:5432/c2 uv run uvicorn c2.main:app --reload

cd frontend                                     # terminal 3: frontend
pnpm install
pnpm dev
```
**3b. Same, with the mock (or any Zenoh node):** also start the mock (`docker compose --profile mock up xverse-mock`, publishes port 7447) and start the backend with the extra variables:
```
C2_DRIVER=zenoh ZENOH_CONNECT=tcp/127.0.0.1:7447 DATABASE_URL=postgresql+psycopg://c2:c2@localhost:5432/c2 uv run uvicorn c2.main:app --reload
```
The frontend runs without the backend too: `VITE_FLEET_SOURCE=local pnpm dev` uses an in-browser simulator.

Full guide: [docs/onboarding.md](docs/onboarding.md)
Windows machine: [docs/windows-wsl-setup.md](docs/windows-wsl-setup.md) (WSL2, Docker, troubleshooting)
VS Code connected to WSL: [docs/vscode-wsl.md](docs/vscode-wsl.md)

### With the X-Verse mock (Zenoh)
Guide, ICD mapping, persisted events and open gaps: [docs/zenoh-driver.md](docs/zenoh-driver.md)

## Documentation
| Doc | What it covers |
|---|---|
| [docs/onboarding.md](docs/onboarding.md) | Setup, daily workflow, WebSocket (5.1), Alembic migrations (5.2), Zenoh mock (5.3), troubleshooting |
| [docs/windows-wsl-setup.md](docs/windows-wsl-setup.md) | Windows + WSL2 + Docker setup and the errors we hit |
| [docs/vscode-wsl.md](docs/vscode-wsl.md) | VS Code Remote - WSL setup and project workflow |
| [docs/zenoh-driver.md](docs/zenoh-driver.md) | Zenoh driver, X-Verse mock, ICD signals and mappings, `mission_event` persistence, gaps to raise with X-Verse |
| [docs/backend-zenoh-frontend.md](docs/backend-zenoh-frontend.md) | REST command implementation, Zenoh topics, and forwarding telemetry to the frontend |
| [docs/api.md](docs/api.md) | Generated OpenAPI locations and HTTP/WebSocket endpoint reference |
| [docs/architecture.md](docs/architecture.md) | Architecture notes with the C4 diagrams in `docs/architecture/images/` |

## Repository layout
| Path | Content |
|---|---|
| `backend/` | FastAPI app: api, services, domain, ports (`FleetPort`), drivers (`sim`, `zenoh`), Alembic migrations |
| `frontend/` | React app with the map, UAV panel and command panel (fleet over WebSocket, commands over HTTP) |
| `contracts/` | OpenAPI, WebSocket schema and the Zenoh ICD |
| `tools/xverse-mock/` | Zenoh mock of X-Verse (compose profile `mock`, `make mock`) |
| `docs/` | Onboarding, Zenoh driver guide, architecture notes and ADRs |

## Architecture
See [docs/architecture.md](docs/architecture.md) and the GitLab wiki (C4 levels, flows, glossary).

## Status
Sprint 0 done: skeleton, UI ported from the prototype, WebSocket fleet feed, Alembic migrations, Zenoh driver and X-Verse mock. Features are tracked as PBIs in the backlog.
