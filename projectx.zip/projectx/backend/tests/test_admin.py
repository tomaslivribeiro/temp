from fastapi.testclient import TestClient
from sqlalchemy import create_engine

from c2 import db
from c2.config import settings
from c2.drivers.sim import SimFleet
from c2.main import app
from c2.models import Base

TOKEN = {"X-Admin-Token": "secret"}
BODY = {"driver": "sim", "zenoh_connect": "", "operator_id": "ops-9", "default_speed_mps": 22, "lost_after_s": 20}


def _client(monkeypatch, tmp_path, token="secret"):
    engine = create_engine(f"sqlite:///{tmp_path / 'admin.db'}")
    Base.metadata.create_all(engine)
    monkeypatch.setattr(db, "engine", engine)
    monkeypatch.setattr(settings, "c2_driver", "sim")
    monkeypatch.setattr(settings, "c2_admin_token", token)
    return TestClient(app)


def test_admin_requires_the_token(monkeypatch, tmp_path):
    with _client(monkeypatch, tmp_path) as client:
        assert client.get("/admin/config").status_code == 401
        assert client.get("/admin/config", headers={"X-Admin-Token": "nope"}).status_code == 401
        assert client.get("/admin/config", headers=TOKEN).status_code == 200


def test_admin_is_disabled_without_a_configured_token(monkeypatch, tmp_path):
    with _client(monkeypatch, tmp_path, token="") as client:
        assert client.get("/admin/config", headers=TOKEN).status_code == 503


def test_saved_settings_apply_persist_and_reset(monkeypatch, tmp_path):
    with _client(monkeypatch, tmp_path) as client:
        first = client.get("/admin/config", headers=TOKEN).json()
        assert first["origin"] == "environment"

        saved = client.put("/admin/config", json={**BODY, "lost_after_s": 20}, headers=TOKEN).json()
        assert saved["origin"] == "saved" and saved["persisted"] is True
        assert saved["settings"]["operator_id"] == "ops-9"
        assert isinstance(app.state.runtime._source, SimFleet)

    with _client(monkeypatch, tmp_path) as client:  # restart: saved values win over the environment
        again = client.get("/admin/config", headers=TOKEN).json()
        assert again["origin"] == "saved" and again["settings"]["lost_after_s"] == 20

        reset = client.delete("/admin/config", headers=TOKEN).json()
        assert reset["origin"] == "environment"

    with _client(monkeypatch, tmp_path) as client:
        assert client.get("/admin/config", headers=TOKEN).json()["origin"] == "environment"


def test_invalid_settings_are_rejected(monkeypatch, tmp_path):
    with _client(monkeypatch, tmp_path) as client:
        for bad in (
            {**BODY, "zenoh_connect": "10.0.0.5:7447"},
            {**BODY, "default_speed_mps": 0},
            {**BODY, "operator_id": "has space"},
        ):
            assert client.put("/admin/config", json=bad, headers=TOKEN).status_code == 422
        assert client.put("/admin/config", json={**BODY, "driver": "nato"}, headers=TOKEN).status_code == 422
        assert client.get("/admin/config", headers=TOKEN).json()["origin"] == "environment"


def test_applying_a_driver_announces_it_over_websocket(monkeypatch, tmp_path):
    with _client(monkeypatch, tmp_path) as client, client.websocket_connect("/ws") as sock:
        assert sock.receive_json()["type"] == "hello"
        client.put("/admin/config", json=BODY, headers=TOKEN)
        types = [sock.receive_json()["type"] for _ in range(4)]
        assert "hello" in types


def test_admin_uavs_lists_sim_fleet_and_patch_persists_metadata(monkeypatch, tmp_path):
    with _client(monkeypatch, tmp_path) as client:
        listing = client.get("/admin/uavs", headers=TOKEN)
        assert listing.status_code == 200
        ids = {u["id"] for u in listing.json()["uavs"]}
        assert "GAMA" in ids and "EANES" in ids

        patched = client.patch(
            "/admin/uavs/GAMA",
            json={"callsign": "ALPHA-1", "higher_formation": "1 ESQAV", "echelon": "SECTION"},
            headers=TOKEN,
        )
        assert patched.status_code == 200
        body = patched.json()
        assert body["callsign"] == "ALPHA-1"
        assert body["echelon"] == "SECTION"

        again = client.get("/admin/uavs", headers=TOKEN).json()["uavs"]
        gama = next(u for u in again if u["id"] == "GAMA")
        assert gama["callsign"] == "ALPHA-1"


def test_admin_uavs_rejects_invalid_enum_values(monkeypatch, tmp_path):
    with _client(monkeypatch, tmp_path) as client:
        for bad in (
            {"affiliation": "ENEMY"},
            {"platform_type": "WARSHIP"},
            {"echelon": "COLONEL"},
        ):
            assert client.patch("/admin/uavs/GAMA", json=bad, headers=TOKEN).status_code == 422
