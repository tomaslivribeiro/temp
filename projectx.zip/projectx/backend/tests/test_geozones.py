import math
from datetime import UTC, datetime, timedelta

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine

from c2.api import geozones as geozones_api
from c2.domain.geozones import (
    CIRCLE_SEGMENTS,
    M_PER_DEG_LAT,
    InvalidShape,
    is_active,
    route_entry,
    shape_bounds,
    to_geojson_geometry,
    validate_shape,
)
from c2.models import Base
from c2.repositories.geozones import SqlAlchemyGeozoneRepository
from c2.services.geozone_registry import GeozoneRegistry

CIRCLE = {"type": "circle", "center": [-9.14, 38.72], "radius_m": 1000}
RECTANGLE = {"type": "rectangle", "bounds": [-9.2, 38.7, -9.1, 38.8]}
POLYGON = {"type": "polygon", "rings": [[[-9.0, 38.0], [-8.9, 38.0], [-8.9, 38.1], [-9.0, 38.0]]]}
MULTIPOLYGON = {"type": "multipolygon", "polygons": [POLYGON["rings"], POLYGON["rings"]]}


def test_circle_becomes_closed_ring_around_center_at_the_radius():
    geometry = to_geojson_geometry(CIRCLE)
    ring = geometry["coordinates"][0]
    assert geometry["type"] == "Polygon"
    assert len(ring) == CIRCLE_SEGMENTS + 1
    assert ring[0] == ring[-1]
    lon0, lat0 = CIRCLE["center"]
    for lon, lat in ring:
        east = (lon - lon0) * 111_320.0 * math.cos(math.radians(lat0))
        north = (lat - lat0) * M_PER_DEG_LAT
        assert math.hypot(east, north) == pytest.approx(1000, rel=1e-6)


def test_rectangle_becomes_closed_five_point_ring():
    ring = to_geojson_geometry(RECTANGLE)["coordinates"][0]
    assert len(ring) == 5
    assert ring[0] == ring[-1]
    assert {tuple(p) for p in ring} == {(-9.2, 38.7), (-9.1, 38.7), (-9.1, 38.8), (-9.2, 38.8)}


def test_polygon_and_multipolygon_pass_through():
    assert to_geojson_geometry(POLYGON) == {"type": "Polygon", "coordinates": POLYGON["rings"]}
    multi = to_geojson_geometry(MULTIPOLYGON)
    assert multi["type"] == "MultiPolygon"
    assert len(multi["coordinates"]) == 2


def test_open_polygon_ring_is_closed():
    open_ring = {"type": "polygon", "rings": [[[0, 0], [1, 0], [1, 1], [0, 1]]]}
    ring = validate_shape(open_ring)["rings"][0]
    assert ring[0] == ring[-1]
    assert len(ring) == 5


@pytest.mark.parametrize(
    "shape",
    [
        {"type": "triangle"},
        {"type": "circle", "center": [-9.14, 38.72], "radius_m": 0},
        {"type": "circle", "center": [-9.14, 95], "radius_m": 10},
        {"type": "circle", "center": [-9.14], "radius_m": 10},
        {"type": "rectangle", "bounds": [-9.1, 38.7, -9.2, 38.8]},
        {"type": "rectangle", "bounds": [-9.2, 38.8, -9.1, 38.7]},
        {"type": "polygon", "rings": [[[0, 0], [1, 1]]]},
        {"type": "polygon", "rings": []},
        {"type": "multipolygon", "polygons": []},
        "circle",
    ],
)
def test_invalid_shapes_are_rejected(shape):
    with pytest.raises(InvalidShape):
        validate_shape(shape)


def test_shape_bounds():
    assert shape_bounds(RECTANGLE) == (-9.2, 38.7, -9.1, 38.8)
    west, south, east, north = shape_bounds(CIRCLE)
    assert west < -9.14 < east and south < 38.72 < north


def test_is_active_handles_open_ended_and_naive_datetimes():
    now = datetime(2026, 11, 20, 12, tzinfo=UTC)
    hour = timedelta(hours=1)
    assert is_active(None, None, now)
    assert is_active(now - hour, now + hour, now)
    assert not is_active(now + hour, None, now)
    assert not is_active(None, now - hour, now)
    # SQLite hands back naive datetimes: they are UTC.
    assert is_active((now - hour).replace(tzinfo=None), (now + hour).replace(tzinfo=None), now)


SQUARE = {"type": "rectangle", "bounds": [0.0, 0.0, 1.0, 1.0]}
HOLED = {
    "type": "polygon",
    "rings": [
        [[0, 0], [10, 0], [10, 10], [0, 10], [0, 0]],
        [[3, 3], [7, 3], [7, 7], [3, 7], [3, 3]],
    ],
}


def _north_of_circle(metres):
    """West-to-east leg passing `metres` north of CIRCLE's centre."""
    lat = 38.72 + metres / M_PER_DEG_LAT
    return [[-9.2, lat], [-9.08, lat]]


@pytest.mark.parametrize(
    ("shape", "points", "expected"),
    [
        # Both ends outside, the leg goes through: no waypoint needs to be inside.
        (CIRCLE, _north_of_circle(0), True),
        (CIRCLE, _north_of_circle(999), True),
        (CIRCLE, _north_of_circle(1001), False),
        (CIRCLE, [[-9.14, 38.72], [-9.0, 38.72]], True),
        # The infinite line would cross the circle, the leg stops before it.
        (CIRCLE, [[-9.3, 38.72], [-9.2, 38.72]], False),
        (CIRCLE, [[-9.14, 38.72], [-9.14, 38.72]], True),
        (SQUARE, [[-1, 0.5], [2, 0.5]], True),
        (SQUARE, [[0.2, 0.2], [0.8, 0.8]], True),
        (SQUARE, [[-1, 2], [2, 2]], False),
        # Touching the boundary counts: along an edge, or through a corner.
        (SQUARE, [[-1, 1], [2, 1]], True),
        (SQUARE, [[-1, 0], [1, 2]], True),
        # Collinear with an edge but not reaching it.
        (SQUARE, [[-2, 1], [-1, 1]], False),
        (HOLED, [[4, 4], [6, 6]], False),
        (HOLED, [[5, 5], [8, 5]], True),
        (HOLED, [[1, 1], [2, 2]], True),
        (MULTIPOLYGON, [[-8.95, 37.9], [-8.95, 38.2]], True),
        (MULTIPOLYGON, [[-8.5, 37.9], [-8.5, 38.2]], False),
        # Only the second leg crosses.
        (SQUARE, [[-2, 3], [-1, 0.5], [2, 0.5]], True),
        (SQUARE, [[-2, 3], [-1, 2], [2, 2]], False),
    ],
)
def test_route_entry_tells_whether_the_route_passes_the_zone(shape, points, expected):
    assert (route_entry(shape, points) is not None) is expected


@pytest.mark.parametrize(
    ("shape", "points", "entry"),
    [
        # Position along the route: leg number plus the fraction of that leg.
        (SQUARE, [[-1, 0.5], [3, 0.5]], 0.25),
        (SQUARE, [[0.5, 0.5], [3, 0.5]], 0.0),
        (SQUARE, [[-3, 3], [-1, 0.5], [3, 0.5]], 1.25),
        # The first time it gets there, even if it comes back later.
        (SQUARE, [[-1, 0.5], [3, 0.5], [-1, 0.5]], 0.25),
        # Touching an edge it runs along, and a corner.
        (SQUARE, [[-1, 1], [3, 1]], 0.25),
        (SQUARE, [[-1, 0], [1, 2]], 0.5),
        (HOLED, [[5, 5], [9, 5]], 0.5),
        (
            MULTIPOLYGON,
            [[-8.95, 38.2], [-8.95, 37.8]],
            pytest.approx((38.2 - 38.05) / 0.4),
        ),
        (CIRCLE, [[-9.14, 38.72], [-9.0, 38.72]], 0.0),
        (
            CIRCLE,
            [[-9.14, 38.72 - 2000 / M_PER_DEG_LAT], [-9.14, 38.72 + 2000 / M_PER_DEG_LAT]],
            pytest.approx(0.25),
        ),
    ],
)
def test_route_entry_is_where_the_route_first_reaches_the_zone(shape, points, entry):
    assert route_entry(shape, points) == entry


@pytest.fixture()
def engine(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'geozones.db'}")
    Base.metadata.create_all(engine)
    return engine


@pytest.fixture()
def repository(engine):
    repository = SqlAlchemyGeozoneRepository(engine)
    repository.upsert_source(
        "anac",
        name="ANAC",
        url="https://dnt.anac.pt/voa-na-boa/",
        attribution="Fonte: ANAC",
        license_note="Sem licença declarada",
        dataset_version="v1",
    )
    return repository


def _zone(external_id, shape, **extra):
    return {
        "external_id": external_id,
        "name": external_id,
        "restriction": "PROHIBITED",
        "shape": shape,
        **extra,
    }


def test_upsert_zones_is_idempotent_and_updates_in_place(repository):
    repository.upsert_zones("anac", [_zone("A", CIRCLE), _zone("B", RECTANGLE)])
    repository.upsert_zones("anac", [_zone("A", CIRCLE, name="renamed")])
    zones = {z.external_id: z for z in repository.list_zones()}
    assert set(zones) == {"A", "B"}
    assert zones["A"].name == "renamed"


def test_replace_zones_removes_the_ones_no_longer_in_the_source(repository):
    repository.upsert_source("other", name="Other", attribution="Other")
    repository.upsert_zones("other", [_zone("B", CIRCLE)])
    repository.upsert_zones("anac", [_zone("A", CIRCLE), _zone("B", RECTANGLE)])
    removed = repository.replace_zones("anac", [_zone("A", CIRCLE), _zone("C", POLYGON)])
    assert removed == 1
    left = {(z.source_id, z.external_id) for z in repository.list_zones()}
    # Only the imported source is synchronised: "B" of another source stays.
    assert left == {("anac", "A"), ("anac", "C"), ("other", "B")}


def test_replace_zones_keeps_listed_ids_even_when_not_updated(repository):
    repository.upsert_zones("anac", [_zone("A", CIRCLE), _zone("B", RECTANGLE)])
    assert repository.replace_zones("anac", [_zone("A", CIRCLE)], keep={"B"}) == 0
    assert {z.external_id for z in repository.list_zones()} == {"A", "B"}


def test_replace_zones_refuses_to_wipe_a_source_with_an_empty_import(repository):
    repository.upsert_zones("anac", [_zone("A", CIRCLE)])
    with pytest.raises(ValueError):
        repository.replace_zones("anac", [])
    assert len(repository.list_zones()) == 1


def test_replace_zones_changes_nothing_when_a_zone_is_invalid(repository):
    repository.upsert_zones("anac", [_zone("A", CIRCLE)])
    with pytest.raises(InvalidShape):
        repository.replace_zones("anac", [_zone("bad", {"type": "circle"})])
    assert [z.external_id for z in repository.list_zones()] == ["A"]


def test_upsert_zones_rejects_invalid_shape(repository):
    with pytest.raises(InvalidShape):
        repository.upsert_zones("anac", [_zone("bad", {"type": "circle"})])


@pytest.fixture()
def client(engine, repository):
    now = datetime.now(UTC)
    repository.upsert_zones(
        "anac",
        [
            _zone("always", CIRCLE, lower_m=0, upper_m=120, lower_ref="AGL", upper_ref="AGL"),
            _zone("expired", RECTANGLE, valid_to=now - timedelta(days=1)),
            _zone("future", POLYGON, valid_from=now + timedelta(days=1)),
            _zone("far", {"type": "circle", "center": [-25.0, 37.7], "radius_m": 500}),
        ],
    )
    app = FastAPI()
    app.state.geozones = GeozoneRegistry(repository)
    app.include_router(geozones_api.router)
    return TestClient(app)


def test_endpoint_returns_only_active_zones_as_polygons_with_sources(client):
    body = client.get("/geozones").json()
    assert body["type"] == "FeatureCollection"
    ids = {f["properties"]["external_id"] for f in body["features"]}
    assert ids == {"always", "far"}
    feature = next(f for f in body["features"] if f["properties"]["external_id"] == "always")
    assert feature["geometry"]["type"] == "Polygon"
    assert feature["properties"]["source_id"] == "anac"
    assert feature["properties"]["lower_m"] == 0
    assert feature["properties"]["upper_ref"] == "AGL"
    assert [s["id"] for s in body["sources"]] == ["anac"]
    assert body["sources"][0]["license_note"] == "Sem licença declarada"


def test_endpoint_at_param_selects_zones_active_then(client):
    later = (datetime.now(UTC) + timedelta(days=2)).isoformat()
    ids = {
        f["properties"]["external_id"]
        for f in client.get("/geozones", params={"at": later}).json()["features"]
    }
    assert ids == {"always", "future", "far"}


def test_endpoint_bbox_filters_zones(client):
    lisbon = client.get("/geozones", params={"bbox": "-9.5,38.5,-8.5,39.0"}).json()
    assert {f["properties"]["external_id"] for f in lisbon["features"]} == {"always"}


def test_endpoint_rejects_malformed_bbox(client):
    assert client.get("/geozones", params={"bbox": "1,2,3"}).status_code == 422


def test_registry_crossing_ignores_green_and_inactive_zones(repository):
    now = datetime.now(UTC)
    repository.upsert_zones(
        "anac",
        [
            _zone("red", CIRCLE),
            _zone("orange", CIRCLE, restriction="REQUIRES_AUTHORISATION"),
            _zone("yellow", CIRCLE, restriction="CONDITIONAL"),
            _zone("green", CIRCLE, restriction="NO_RESTRICTION"),
            _zone("expired", CIRCLE, valid_to=now - timedelta(days=1)),
            _zone("future", CIRCLE, valid_from=now + timedelta(days=1)),
            _zone("elsewhere", RECTANGLE | {"bounds": [-25.1, 37.6, -25.0, 37.7]}),
        ],
    )
    crossed = GeozoneRegistry(repository).crossing(_north_of_circle(0))
    assert {z.external_id for z in crossed} == {"red", "orange", "yellow"}


def _square(west):
    return {"type": "rectangle", "bounds": [west, 0.0, west + 1.0, 1.0]}


def test_registry_crossing_lists_zones_in_the_order_the_route_reaches_them(repository):
    repository.upsert_zones(
        "anac",
        [
            # Stored in an order that is neither the flight order nor its reverse.
            _zone("second", _square(3.0)),
            _zone("third", _square(6.0), restriction="CONDITIONAL"),
            _zone("first-yellow", _square(0.0), restriction="CONDITIONAL"),
            _zone("first-red", _square(0.0)),
        ],
    )
    registry = GeozoneRegistry(repository)
    eastward = registry.crossing([[-1.0, 0.5], [8.0, 0.5]])
    # Reached at the same point: the most severe first.
    assert [z.external_id for z in eastward] == ["first-red", "first-yellow", "second", "third"]
    westward = registry.crossing([[8.0, 0.5], [-1.0, 0.5]])
    assert [z.external_id for z in westward] == ["third", "second", "first-red", "first-yellow"]


def _points(*pairs):
    return {"points": [{"lon": lon, "lat": lat} for lon, lat in pairs]}


def test_route_check_returns_the_zones_the_route_crosses(client):
    response = client.post("/geozones/route-check", json=_points(*_north_of_circle(0)))
    assert response.status_code == 200
    zones = response.json()["zones"]
    assert [z["external_id"] for z in zones] == ["always"]
    assert zones[0]["restriction"] == "PROHIBITED"
    assert zones[0]["upper_m"] == 120


def test_route_check_returns_no_zones_for_a_clear_route(client):
    response = client.post("/geozones/route-check", json=_points((-8.0, 40.0), (-7.9, 40.0)))
    assert response.json() == {"zones": []}


@pytest.mark.parametrize(
    "body",
    [
        _points((-9.14, 38.72)),
        {"points": []},
        {},
        _points((-9.14, 95), (-9.0, 38.72)),
    ],
)
def test_route_check_rejects_invalid_routes(client, body):
    assert client.post("/geozones/route-check", json=body).status_code == 422


def test_route_check_answers_503_when_the_zones_cannot_be_read(client):
    class Broken:
        def crossing(self, points):
            raise RuntimeError("database down")

    client.app.state.geozones = Broken()
    response = client.post("/geozones/route-check", json=_points(*_north_of_circle(0)))
    assert response.status_code == 503
