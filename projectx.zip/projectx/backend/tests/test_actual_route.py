import itertools
import math

from c2.domain.actual_route import ActualRoute, distance_to_segment_m

M_PER_DEG_LAT = 110_570.0
M_PER_DEG_LON = 111_320.0  # at the equator, where these tests run (lat 0)


def pt(x_m: float, y_m: float) -> list[float]:
    """Local metres (x east, y north) to [lon, lat] around (0, 0)."""
    return [x_m / M_PER_DEG_LON, y_m / M_PER_DEG_LAT]


def feed(route: ActualRoute, points: list[list[float]]) -> None:
    route.reset(points[0])
    for p in points[1:]:
        route.update(p)


def test_inactive_route_has_no_polyline():
    route = ActualRoute()
    assert not route.active
    assert route.polyline() == []


def test_straight_flight_keeps_only_the_origin_as_vertex():
    route = ActualRoute()
    feed(route, [pt(i * 15, 0) for i in range(30)])
    assert route.vertices == [pt(0, 0)]
    assert route.polyline()[0] == pt(0, 0)
    assert route.polyline()[-1] == pt(29 * 15, 0)


def test_corner_creates_a_vertex_at_the_turn():
    route = ActualRoute()
    leg1 = [pt(i * 15, 0) for i in range(11)]  # east to (150, 0)
    leg2 = [pt(150, j * 15) for j in range(1, 11)]  # then north
    feed(route, leg1 + leg2)
    assert len(route.vertices) == 2
    corner = route.vertices[1]
    assert distance_to_segment_m(corner, pt(150, 0), pt(150, 0)) < route.tolerance_m


def test_lateral_deviation_above_tolerance_creates_a_vertex():
    route = ActualRoute(tolerance_m=5)
    path = [pt(i * 15, 0) for i in range(10)] + [pt(150, 20)] + [pt(150 + i * 15, 0) for i in range(1, 10)]
    feed(route, path)
    assert pt(150, 20) in route.vertices


def test_jitter_below_tolerance_creates_no_vertex():
    route = ActualRoute(tolerance_m=5)
    feed(route, [pt(i * 15, 2 if i % 2 else -2) for i in range(40)])
    assert len(route.vertices) == 1


def test_curve_in_a_single_goto_is_followed_within_tolerance():
    route = ActualRoute(tolerance_m=5)
    radius = 100.0
    arc = [pt(radius * math.sin(a), radius * (1 - math.cos(a))) for a in [math.radians(d) for d in range(0, 181, 5)]]
    feed(route, arc)
    line = route.polyline()
    assert len(route.vertices) >= 3  # a half circle cannot be drawn as one straight segment
    for p in arc:
        nearest = min(distance_to_segment_m(p, a, b) for a, b in itertools.pairwise(line))
        assert nearest <= route.tolerance_m + 1e-6


def test_polyline_ends_with_the_unconfirmed_real_points():
    route = ActualRoute()
    feed(route, [pt(0, 0), pt(15, 0), pt(30, 0)])
    assert route.polyline() == [pt(0, 0), pt(15, 0), pt(30, 0)]


def test_tiny_moves_are_ignored():
    route = ActualRoute()
    feed(route, [pt(0, 0), pt(0.2, 0.1), pt(0.1, 0.3)])
    assert route.polyline() == [pt(0, 0)]


def test_reset_starts_a_new_route_and_clear_empties_it():
    route = ActualRoute()
    feed(route, [pt(i * 15, 0) for i in range(5)])
    route.reset(pt(500, 500))
    assert route.polyline() == [pt(500, 500)]
    route.clear()
    assert not route.active
    assert route.polyline() == []


def test_vertex_cap_keeps_the_origin_and_the_newest_vertices():
    route = ActualRoute(tolerance_m=5, max_vertices=5)
    zigzag = [pt(i * 50, 0 if i % 2 == 0 else 50) for i in range(30)]
    feed(route, zigzag)
    assert len(route.vertices) == 5
    assert route.vertices[0] == pt(0, 0)


def test_vertex_cap_drops_the_smallest_wiggle_not_a_real_turn():
    route = ActualRoute(tolerance_m=5, max_vertices=6)
    # 1 km east with 10 m wiggles, then a sharp 1 km turn north, then more wiggles.
    east = [pt(i * 100, 10 if i % 2 else 0) for i in range(11)]
    north = [pt(1000 + (10 if i % 2 else 0), i * 100) for i in range(1, 11)]
    feed(route, east + north)
    assert len(route.vertices) == 6
    assert route.vertices[0] == pt(0, 0)
    corner = min(route.vertices, key=lambda v: math.dist(v, pt(1000, 0)))
    assert math.dist(corner, pt(1000, 0)) * M_PER_DEG_LON < 150  # the real turn survives the cap


def test_moving_again_after_a_stop_starts_a_new_route():
    route = ActualRoute()
    route.observe("M", pt(0, 0))
    route.observe("M", pt(500, 0))
    route.observe("H", pt(500, 0))  # mission done, hovering: route kept
    route.observe("R", pt(500, 0))  # RTB with no goto: the return is a new route from here
    route.observe("R", pt(400, 0))
    assert route.polyline() == [pt(500, 0), pt(400, 0)]


def test_pending_points_are_bounded_on_long_straight_flights():
    route = ActualRoute(max_pending=20)
    feed(route, [pt(i * 15, 0) for i in range(200)])
    assert len(route.polyline()) <= 20 + len(route.vertices)
    assert route.polyline()[-1] == pt(199 * 15, 0)


def test_observe_follows_the_asset_lifecycle():
    route = ActualRoute()
    route.observe("M", pt(0, 0))  # moving without a goto (e.g. RTB) starts the route where it is
    route.observe("M", pt(15, 0))
    assert route.polyline() == [pt(0, 0), pt(15, 0)]
    route.observe("H", pt(15, 0))  # hover after the mission keeps the route
    assert route.active
    route.observe("S", pt(15, 0))  # back on standby at base clears it
    assert not route.active
    route.observe("H", pt(15, 0))  # hovering alone never starts a route
    assert not route.active


def test_snapshot_fields_expose_only_the_polyline():
    route = ActualRoute()
    feed(route, [pt(0, 0), pt(15, 0), pt(30, 0), pt(30, 15), pt(30, 30)])
    assert route.snapshot_fields() == {"track": [pt(0, 0), pt(30, 0), pt(30, 15), pt(30, 30)]}
