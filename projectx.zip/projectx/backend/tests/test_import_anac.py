import importlib.util
from datetime import UTC, datetime
from pathlib import Path

import pytest
from sqlalchemy import create_engine

from c2.models import Base
from c2.repositories.geozones import SqlAlchemyGeozoneRepository

TOOLS = Path(__file__).resolve().parents[2] / "tools"
spec = importlib.util.spec_from_file_location("import_anac_ed318", TOOLS / "import_anac_ed318.py")
anac = importlib.util.module_from_spec(spec)
spec.loader.exec_module(anac)


def _feature(identifier, geometry, kind="PROHIBITED", **props):
    return {
        "type": "Feature",
        "properties": {
            "identifier": identifier,
            "name": [{"text": "Nome", "lang": "PT"}, {"text": "Name", "lang": "EN"}],
            "type": kind,
            "reason": ["AIR_TRAFFIC"],
            "message": [{"text": "Proibido", "lang": "PT"}],
            "limitedApplicability": [
                {"startDateTime": "2016-12-14T00:00:00Z", "endDateTime": "2027-12-31T00:00:00Z"}
            ],
            **props,
        },
        "geometry": geometry,
    }


LAYER = {"lower": 0, "lowerReference": "AGL", "upper": 120, "upperReference": "AGL", "uom": "m"}
POINT = {"type": "Point", "coordinates": [-9.23, 38.72], "layer": LAYER,
         "extent": {"subType": "Circle", "radius": 1000}}  # fmt: skip
POLYGON = {"type": "Polygon", "layer": LAYER,
           "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 0]]]}  # fmt: skip


def test_point_with_radius_becomes_circle_and_fields_are_mapped():
    zone = anac.map_feature(_feature("1001UA", POINT, "REQ_AUTHORIZATION"))
    assert zone["shape"] == {"type": "circle", "center": [-9.23, 38.72], "radius_m": 1000}
    assert zone["restriction"] == "REQUIRES_AUTHORISATION"
    assert (zone["name"], zone["message"], zone["reason"]) == ("Nome", "Proibido", "AIR_TRAFFIC")
    assert (zone["lower_m"], zone["upper_m"], zone["upper_ref"]) == (0, 120, "AGL")
    assert zone["valid_to"] == datetime(2027, 12, 31, tzinfo=UTC)


@pytest.mark.parametrize(("unit", "upper"), [("m", 120), ("M", 120), ("ft", 0)])
def test_altitude_units_are_normalised_to_metres(unit, upper):
    layer = {**LAYER, "uom": unit}
    zone = anac.map_feature(_feature("u", {**POLYGON, "layer": layer}))
    assert zone["upper_m"] == pytest.approx(upper if unit != "ft" else 120 * 0.3048, abs=0.01)


def test_schedule_and_notam_text_are_kept_in_properties():
    window = [{"startDateTime": "2026-11-20T06:00:00Z", "endDateTime": "2026-11-22T22:00:00Z",
               "schedule": [{"day": ["ANY"]}]}]  # fmt: skip
    zone = anac.map_feature(
        _feature("A1", POLYGON, limitedApplicability=window, extendedProperties={"notam_inf": "TXT"})
    )
    assert zone["properties"]["notam"] == "TXT"
    assert zone["properties"]["schedule"] == [{"day": ["ANY"]}]


def test_unusable_features_are_skipped_not_fatal():
    bare_point = {"type": "Point", "coordinates": [0, 0], "layer": LAYER}
    document = {"features": [_feature("ok", POLYGON), _feature("bad", bare_point)]}
    zones, skipped = anac.map_collection(document)
    assert [z["external_id"] for z in zones] == ["ok"]
    assert len(skipped) == 1 and skipped[0].startswith("bad")


def test_committed_dataset_maps_and_loads_idempotently(tmp_path):
    import json

    path = next((TOOLS / "data" / "anac").glob("ed318-*.json"))
    zones, skipped = anac.map_collection(json.loads(path.read_text(encoding="utf-8")))
    assert not skipped and len(zones) > 300
    engine = create_engine(f"sqlite:///{tmp_path / 'z.db'}")
    Base.metadata.create_all(engine)
    repository = SqlAlchemyGeozoneRepository(engine)
    repository.upsert_source("anac", name="ANAC", attribution="Fonte: ANAC")
    repository.upsert_zones("anac", zones)
    repository.upsert_zones("anac", zones)
    assert len(repository.list_zones()) == len(zones)


@pytest.mark.parametrize("kind", ["PROHIBITED", "REQ_AUTHORIZATION", "CONDITIONAL", "NO_RESTRICTION"])
def test_all_anac_restrictions_are_known(kind):
    assert anac.map_feature(_feature("x", POLYGON, kind))["restriction"]
