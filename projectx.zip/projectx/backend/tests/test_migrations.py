from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import Session

from c2.config import settings
from c2.models import RuntimeConfiguration
from c2.repositories.runtime_configuration import SqlAlchemyRuntimeConfigurationRepository

ROOT = Path(__file__).resolve().parents[1]


def _config() -> Config:
    cfg = Config(str(ROOT / "alembic.ini"))
    cfg.set_main_option("script_location", str(ROOT / "alembic"))
    return cfg


def test_migrations_upgrade_and_downgrade(tmp_path, monkeypatch):
    url = f"sqlite:///{tmp_path / 'c2.db'}"
    monkeypatch.setattr(settings, "database_url", url)
    engine = create_engine(url)

    command.upgrade(_config(), "head")
    assert {"uav", "mission_event", "runtime_configuration"} <= set(
        inspect(engine).get_table_names()
    )
    with engine.connect() as conn:
        assert conn.execute(text("select version_num from alembic_version")).scalar() == "0005"
    uav_columns = {c["name"] for c in inspect(engine).get_columns("uav")}
    assert {"affiliation", "platform_type", "callsign", "higher_formation", "echelon"} <= uav_columns

    repository = SqlAlchemyRuntimeConfigurationRepository(engine)
    repository.save_active_driver("zenoh")
    repository.save_active_driver("sim")
    with Session(engine) as session:
        assert session.get(RuntimeConfiguration, 1).active_driver == "sim"

    command.downgrade(_config(), "base")
    assert not {"uav", "mission_event", "runtime_configuration"} & set(
        inspect(engine).get_table_names()
    )
