import pytest
from fastapi.testclient import TestClient

from c2.api import ws
from c2.config import settings
from c2.main import app


def recv_type(sock, type_: str) -> dict:
    """Reads messages until one of the given type arrives (snapshots are interleaved)."""
    for _ in range(10):
        msg = sock.receive_json()
        if msg["type"] == type_:
            return msg
    raise AssertionError(f"no {type_} message received")


def test_ws_hello_snapshot_and_ping():
    with TestClient(app) as client, client.websocket_connect("/ws") as sock:
        hello = sock.receive_json()
        assert hello["type"] == "hello"
        assert hello["payload"]["driver"] == settings.c2_driver
        assert "ts" in hello
        snap = recv_type(sock, "fleet.snapshot")
        assert len(snap["payload"]["drones"]) == 10
        sock.send_json({"type": "ping"})
        recv_type(sock, "pong")


def test_ws_rejects_invalid_json():
    with TestClient(app) as client, client.websocket_connect("/ws") as sock:
        sock.send_text("not json")
        recv_type(sock, "error")


def test_ws_rejects_foreign_origin():
    from starlette.websockets import WebSocketDisconnect

    with (
        TestClient(app) as client,
        pytest.raises(WebSocketDisconnect),
        client.websocket_connect("/ws", headers={"origin": "http://evil.example"}),
    ):
        pass


@pytest.mark.anyio
async def test_broadcast_reaches_clients():
    sent = []

    class Fake:
        async def send_json(self, m):
            sent.append(m)

    ws.manager._clients.add(Fake())
    try:
        await ws.manager.broadcast("uav.position", {"id": "GAMA"})
    finally:
        ws.manager._clients.clear()
    assert sent[0]["type"] == "uav.position" and sent[0]["payload"] == {"id": "GAMA"}
