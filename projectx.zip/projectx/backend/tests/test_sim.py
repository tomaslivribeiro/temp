import pytest
from fastapi.testclient import TestClient

from c2.api.dependencies import get_fleet_service
from c2.drivers import sim
from c2.main import app
from c2.services.fleet import FleetService


@pytest.fixture()
def fleet():
    return sim.SimFleet(deviations=None)  # ideal straight flight; deviations have their own tests below


@pytest.fixture()
def client(fleet):
    app.dependency_overrides[get_fleet_service] = lambda: FleetService(fleet)
    try:
        yield TestClient(app)
    finally:
        app.dependency_overrides.pop(get_fleet_service, None)


def run(f: sim.SimFleet, until, limit=400):
    for _ in range(limit):
        if until():
            return
        f.tick()
    raise AssertionError("condition not reached")


def test_mission_drone_reaches_b_and_hovers(fleet):
    gama = fleet.get("GAMA")
    start = sim.km(gama, gama["b"])
    fleet.tick()
    assert sim.km(gama, gama["b"]) < start
    run(fleet, lambda: gama["state"] == "H")
    assert gama["b"] is None


def test_returning_drone_lands_in_standby_at_base(fleet):
    d = fleet.get("BARTOLOMEU")
    run(fleet, lambda: d["state"] == "S")
    assert sim.km(d, sim.BASES["CHARLIE"]) < 0.1


def test_goto_is_rejected_when_battery_is_low(fleet):
    d = fleet.get("GOMES")
    d["bat"] = 20
    c = fleet.send("GOMES", "goto", {"lon": -8, "lat": 38})
    run(fleet, lambda: c.get("final"))
    assert c["final"] == "rejected"


def test_goto_visits_waypoints_in_order_and_hovers_at_the_last_one(fleet):
    d = fleet.get("GOMES")
    points = [{"lon": -8.61, "lat": 41.17}, {"lon": -8.60, "lat": 41.18}]
    c = fleet.send("GOMES", "goto", None, points)
    run(fleet, lambda: c.get("final"))
    assert c["final"] == "completed"
    assert d["state"] == "H"
    assert (d["lon"], d["lat"]) == (points[-1]["lon"], points[-1]["lat"])


def test_command_pipeline_completes(fleet):
    c = fleet.send("TRISTÃO", "takeoff", None)
    run(fleet, lambda: c.get("final"))
    assert c["final"] == "completed" and len(c["times"]) == 5


def test_commands_api(fleet, client):
    ok = client.post("/uavs/TRISTÃO/commands", json={"action": "takeoff"})
    assert ok.status_code == 202 and ok.json()["key"] == 1
    assert client.post("/uavs/NOPE/commands", json={"action": "hold"}).status_code == 404
    assert client.post("/uavs/EANES/commands", json={"action": "takeoff"}).status_code == 409
    assert client.post("/uavs/GOMES/commands", json={"action": "goto"}).status_code == 422
    assert client.post("/uavs/GOMES/commands", json={"action": "explode"}).status_code == 422


def test_snapshot_seeds_actual_route_from_existing_trail(fleet):
    gama = fleet.get("GAMA")
    assert gama["track"][0] == [-9.1869, 38.7542]
    assert fleet.get("TRISTÃO")["track"] == []


def test_goto_starts_actual_route_at_origin_and_clears_it_after_completion(fleet):
    d = fleet.get("GOMES")
    origin = [d["lon"], d["lat"]]
    c = fleet.send("GOMES", "goto", {"lon": -8.5, "lat": 41.2})
    run(fleet, lambda: d["state"] == "M")
    assert d["track"][0] == origin
    run(fleet, lambda: c.get("final"))
    assert d["state"] == "H"
    assert d["track"] == []


def test_changeb_mid_flight_tracks_the_turn_until_completion(fleet):
    d = fleet.get("GOMES")
    fleet.send("GOMES", "goto", {"lon": -8.62, "lat": 41.5})  # north
    run(fleet, lambda: d["state"] == "M")
    for _ in range(5):
        fleet.tick()
    c = fleet.send("GOMES", "changeb", {"lon": -8.2, "lat": d["lat"] + 0.05})  # then east
    run(fleet, lambda: c["stage"] >= 3)  # the turn happens when the command is applied
    assert d["track"]  # the route is retained while changeb is in progress
    run(fleet, lambda: d["state"] == "H")
    assert d["track"] == []  # final movement completion clears the real route


def test_rtb_after_a_completed_mission_starts_a_new_actual_route(fleet):
    d = fleet.get("TRISTÃO")
    d["state"] = "H"
    fleet.send("TRISTÃO", "goto", {"lon": -9.0, "lat": 38.9})
    run(fleet, lambda: d["state"] == "H" and d["b"] is None)
    assert d["track"] == []
    fleet.send("TRISTÃO", "rtb", None)
    run(fleet, lambda: d["state"] == "R")
    hover = [d["lon"], d["lat"]]
    fleet.tick()
    assert sim.km({"lon": d["track"][0][0], "lat": d["track"][0][1]}, {"lon": hover[0], "lat": hover[1]}) < 2


def test_landing_at_base_clears_actual_route(fleet):
    d = fleet.get("BARTOLOMEU")
    assert d["track"]
    run(fleet, lambda: d["state"] == "S")
    assert d["track"] == []


# ---- Deviations (simulator only) ---------------------------------------------------------------------

ALFA = sim.BASES["ALFA"]
CHARLIE = sim.BASES["CHARLIE"]


def offset_from_line_km(points, a, b):
    bx, by = sim._xy(b["lon"], b["lat"], a)
    n = (bx * bx + by * by) ** 0.5
    worst = 0.0
    for lon, lat in points:
        px, py = sim._xy(lon, lat, a)
        worst = max(worst, abs(px * by - py * bx) / n)
    return worst


def fly(f: sim.SimFleet, drone_id: str, dest, limit=600):
    d = f.get(drone_id)
    f.send(drone_id, "goto", dest)
    pts = []
    for _ in range(limit):
        f.tick()
        pts.append((d["lon"], d["lat"]))
        if d["state"] == "H" and d["b"] is None and len(pts) > 5:
            return d, pts
    raise AssertionError("did not arrive")


def test_default_fleet_follows_the_sim_settings(monkeypatch):
    monkeypatch.setattr(sim.settings, "c2_sim_deviations", False)
    assert sim.SimFleet().deviations is None
    monkeypatch.setattr(sim.settings, "c2_sim_deviations", True)
    monkeypatch.setattr(sim.settings, "c2_sim_wind_km_per_tick", 0.6)
    assert sim.SimFleet().deviations.wind == 0.6


@pytest.mark.parametrize(
    "env",
    [
        {"C2_SIM_WIND_KM_PER_TICK": "0,5"},
        {"C2_SIM_WIND_KM_PER_TICK": "inf"},
        {"C2_SIM_WIND_KM_PER_TICK": "1.6"},  # above half the cruise speed: drones would never arrive
        {"C2_SIM_WIND_FROM_DEG": "nan"},
        {"C2_SIM_DEVIATIONS": "disabled"},
    ],
)
def test_invalid_sim_settings_are_rejected_at_startup(monkeypatch, env):
    from pydantic import ValidationError

    from c2.config import Settings

    for k, v in env.items():
        monkeypatch.setenv(k, v)
    with pytest.raises(ValidationError):
        Settings()


def test_sim_settings_accept_on_off(monkeypatch):
    from c2.config import Settings

    monkeypatch.setenv("C2_SIM_DEVIATIONS", "off")
    assert Settings().c2_sim_deviations is False


def test_deviations_reject_bad_arguments():
    with pytest.raises(TypeError):
        sim.SimFleet(deviations="off")
    with pytest.raises(ValueError):
        sim.Deviations(wind_km_per_tick=float("inf"))


def test_wind_is_capped_so_a_headwind_never_stops_the_drones():
    dev = sim.Deviations(wind_km_per_tick=5.0, wind_from_deg=180, detours=False, seed=1)
    assert dev.wind == sim.MAX_WIND_KM_PER_TICK
    f = sim.SimFleet(deviations=dev)
    f.get("TRISTÃO")["state"] = "H"
    # Wind from the south (180) blows north; flying due south is a full headwind at the strongest allowed wind.
    d, _ = fly(f, "TRISTÃO", {"lon": -9.1869, "lat": 37.6}, limit=1500)
    assert d["state"] == "H"


def test_wind_bows_the_real_route_and_the_drone_still_arrives():
    f = sim.SimFleet(deviations=sim.Deviations(wind_km_per_tick=0.5, wind_from_deg=0, detours=False))
    f.get("TRISTÃO")["state"] = "H"
    d, pts = fly(f, "TRISTÃO", {"lon": CHARLIE["lon"], "lat": CHARLIE["lat"]})
    assert offset_from_line_km(pts, ALFA, CHARLIE) > 1
    assert sim.km(d, CHARLIE) < 0.1


def test_wind_changes_reported_ground_speed():
    f = sim.SimFleet(deviations=sim.Deviations(wind_km_per_tick=0.5, wind_from_deg=90, detours=False))
    f.get("TRISTÃO")["state"] = "H"
    f.send("TRISTÃO", "goto", {"lon": CHARLIE["lon"], "lat": CHARLIE["lat"]})
    speeds = set()
    for _ in range(40):
        f.tick()
        speeds.add(f.get("TRISTÃO")["spd"])
    assert speeds - {0, sim.CRUISE_SPD}


@pytest.mark.parametrize("dest", ["CHARLIE", "DELTA", "BRAVO"])  # east-west, and long diagonals across latitudes
def test_detour_waypoints_sit_at_the_intended_offset(dest):
    import random

    end = sim.BASES[dest]
    for seed in range(20):
        wps = sim.detour_waypoints(ALFA, end, random.Random(seed))
        assert len(wps) in (2, 4)
        bx, by = sim._xy(end["lon"], end["lat"], ALFA)
        n = (bx * bx + by * by) ** 0.5
        for i in range(0, len(wps), 2):  # each manoeuvre: both waypoints at the same lateral offset
            offs = [(px * by - py * bx) / n for px, py in (sim._xy(lon, lat, ALFA) for lon, lat in wps[i : i + 2])]
            assert abs(offs[0] - offs[1]) < 0.01
            assert sim.DETOUR_OFFSET_KM[0] - 0.01 <= abs(offs[0]) <= sim.DETOUR_OFFSET_KM[1] + 0.01


def test_a_new_goto_to_the_same_destination_gets_a_fresh_detour():
    f = sim.SimFleet(deviations=sim.Deviations(wind_km_per_tick=0, seed=3))
    f.get("TRISTÃO")["state"] = "H"
    dest = {"lon": CHARLIE["lon"], "lat": CHARLIE["lat"]}
    for _ in range(3):  # interrupted twice by hold, then sent again to the same B
        f.send("TRISTÃO", "goto", dest)
        for _ in range(8):
            f.tick()
        f.send("TRISTÃO", "hold", None)
        for _ in range(4):
            f.tick()
        assert f.deviations._legs.get("TRISTÃO"), "goto must plan a manoeuvre from where the drone is"
    _, pts = fly(f, "TRISTÃO", dest)
    assert offset_from_line_km(pts, {"lon": pts[0][0], "lat": pts[0][1]}, CHARLIE) > 1.5


def test_one_drone_flight_does_not_depend_on_the_others():
    def flight(others_fly: bool):
        f = sim.SimFleet(deviations=sim.Deviations(seed=7))
        if not others_fly:
            for other in ("GAMA", "CABRAL", "BARTOLOMEU"):
                f.get(other)["state"] = "H"
        f.get("TRISTÃO")["state"] = "H"
        return fly(f, "TRISTÃO", {"lon": CHARLIE["lon"], "lat": CHARLIE["lat"]})[1]

    assert flight(True) == flight(False)


def test_short_legs_get_no_detour():
    import random

    a = {"lon": -9.0, "lat": 38.7}
    b = {"lon": -9.0, "lat": 38.75}  # ~5.5 km
    assert sim.detour_waypoints(a, b, random.Random(1)) == []


def test_drone_flies_a_detour_and_still_arrives():
    f = sim.SimFleet(deviations=sim.Deviations(wind_km_per_tick=0, seed=3))
    f.get("TRISTÃO")["state"] = "H"
    d, pts = fly(f, "TRISTÃO", {"lon": CHARLIE["lon"], "lat": CHARLIE["lat"]})
    assert offset_from_line_km(pts, ALFA, CHARLIE) > 1.5
    assert sim.km(d, CHARLIE) < 0.1


def test_detours_can_be_switched_off_leaving_only_wind():
    f = sim.SimFleet(deviations=sim.Deviations(wind_km_per_tick=0, detours=False))
    f.get("TRISTÃO")["state"] = "H"
    _, pts = fly(f, "TRISTÃO", {"lon": CHARLIE["lon"], "lat": CHARLIE["lat"]})
    assert offset_from_line_km(pts, ALFA, CHARLIE) < 0.5


DRONE_KEYS = {
    "id", "state", "base", "lon", "lat", "alt", "spd", "hdg", "bat", "hb", "flaky", "lost", "gps", "sats",
    "trail", "track", "a", "b", "route", "route_index", "timer", "frame", "horizontal_fov", "visual_los",
}


def test_every_drone_reports_sensor_geometry_for_the_fov_sector():
    for d in sim.SimFleet(deviations=None).snapshot()["drones"]:
        assert d["horizontal_fov"] == sim.HORIZONTAL_FOV_DEG > 0, d["id"]
        assert d["visual_los"] == sim.VISUAL_LOS_M > 0, d["id"]


def test_snapshot_shape_is_unchanged_by_deviations():
    plain = sim.SimFleet(deviations=None)
    dev = sim.SimFleet(deviations=sim.Deviations(seed=1))
    for f in (plain, dev):
        f.get("TRISTÃO")["state"] = "H"
        f.send("TRISTÃO", "goto", {"lon": CHARLIE["lon"], "lat": CHARLIE["lat"]})
    for t in range(120):  # covers flights in progress, a detour, an RTB and a landing
        plain.tick()
        dev.tick()
        for p, d in zip(plain.snapshot()["drones"], dev.snapshot()["drones"], strict=True):
            assert set(d) == set(p) == DRONE_KEYS, (t, d["id"])
    assert plain.snapshot().keys() == dev.snapshot().keys() == {"t", "drones", "cmds"}


def test_flights_already_in_progress_at_startup_are_pushed_by_the_wind_from_the_first_tick():
    f = sim.SimFleet(deviations=sim.Deviations(wind_km_per_tick=1.0, wind_from_deg=0, detours=False))
    ideal = sim.SimFleet(deviations=None)
    for _ in range(5):
        f.tick()
        ideal.tick()
    gama, gama0 = f.get("GAMA"), ideal.get("GAMA")
    assert sim.km(gama, gama0) > 1  # drifted south of the ideal path
    hold = f.get("GOMES")
    assert (hold["lon"], hold["lat"]) == (ideal.get("GOMES")["lon"], ideal.get("GOMES")["lat"])  # hovering: not pushed
