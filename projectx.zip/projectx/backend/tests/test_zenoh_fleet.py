import json
import sys
from pathlib import Path

import pytest
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import Session

from c2 import db
from c2.domain.errors import (
    CommandNotAllowed,
    CommandNotImplemented,
    DestinationRequired,
    FleetUnavailable,
    UavNotFound,
)
from c2.drivers.zenoh.fleet import ZenohFleet
from c2.models import Base, MissionEvent, Uav
from c2.repositories.events import SqlAlchemyFleetEventRepository

NOW = 1_800_000_000.0


def telemetry(asset="UAV-001", state="HOVERING", nav="HOLD", lon=-9.0, lat=39.3):
    return {
        "timestamp_utc": int(NOW), "asset_id": asset, "asset_type": "UAV",
        "position": {"latitude_deg": lat, "longitude_deg": lon, "altitude_m": 420},
        "velocity": {"ground_speed_mps": 15}, "heading_deg": 90, "current_state": state,
        "navigation_mode": nav, "horizontal_fov": 78, "visual_los": 1000,
    }


class Harness:
    def __init__(self):
        self.sent, self.jobs, self.clock = [], [], [NOW]
        self.recorder = Recorder(self.jobs)
        self.fleet = ZenohFleet(
            lambda t, p: self.sent.append((t, p)), self.recorder, clock=lambda: self.clock[0]
        )

    def feed(self, topic, payload):
        self.fleet.on_message(topic, json.dumps(payload).encode())


class Recorder:
    def __init__(self, jobs):
        self.jobs = jobs

    def record_event(self, *args):
        self.jobs.append(("save_event", args))

    def register_asset(self, *args):
        self.jobs.append(("ensure_uav", args))


@pytest.fixture()
def h():
    return Harness()


@pytest.fixture()
def database(tmp_path, monkeypatch):
    engine = create_engine(f"sqlite:///{tmp_path / 'c2.db'}")
    Base.metadata.create_all(engine)
    monkeypatch.setattr(db, "engine", engine)
    return engine


def test_telemetry_discovers_asset_and_maps_to_ui_model(h):
    h.feed("asset/telemetry", telemetry(state="MOVING", nav="RETURN_HOME"))
    d = h.fleet.snapshot()["drones"][0]
    assert (d["id"], d["state"], d["base"], d["spd"], d["alt"]) == ("UAV-001", "R", "ALFA", 54, 420)
    assert (d["horizontal_fov"], d["visual_los"]) == (78, 1000)
    assert len(h.jobs) == 1  # the new asset is registered once
    h.feed("asset/telemetry", telemetry())
    assert len(h.jobs) == 1


def test_geo_positions_have_the_geo_frame(h):
    h.feed("asset/telemetry", telemetry())
    assert h.fleet.snapshot()["drones"][0]["frame"] == "geo"


def test_malformed_messages_are_dropped(h):
    h.fleet.on_message("asset/telemetry", b"not json")
    h.feed("asset/telemetry", {"asset_id": "X"})
    assert h.fleet.snapshot()["drones"] == []


def test_goto_publishes_icd_move_and_status_drives_the_stages(h):
    h.feed("asset/telemetry", telemetry())
    cmd = h.fleet.send("UAV-001", "goto", {"lon": -8.5, "lat": 40.0})
    topic, msg = h.sent[0]
    assert topic == "c2/mission/command"
    assert (msg["command"], msg["asset_id"], msg["destination"]["latitude_deg"]) == ("MOVE", "UAV-001", 40.0)
    for status, stage in [("RECEIVED", 1), ("ACCEPTED", 2), ("IN_PROGRESS", 3), ("COMPLETED", 4)]:
        h.feed("mission/status", {"asset_id": "UAV-001", "mission_id": msg["mission_id"], "status": status})
        assert cmd["stage"] == stage and len(cmd["times"]) == stage + 1
    assert cmd["final"] == "completed"

def test_goto_sends_the_next_waypoint_after_each_leg_completes(h):
    h.feed("asset/telemetry", telemetry())
    points = [{"lon": -8.5, "lat": 40.0}, {"lon": -8.2, "lat": 40.2}]
    cmd = h.fleet.send("UAV-001", "goto", None, points)
    first_mission = h.sent[0][1]["mission_id"]

    for status in ("RECEIVED", "ACCEPTED", "IN_PROGRESS", "COMPLETED"):
        h.feed(
            "mission/status",
            {"asset_id": "UAV-001", "mission_id": first_mission, "status": status},
        )

    assert len(h.sent) == 2
    second_message = h.sent[1][1]
    assert second_message["destination"]["latitude_deg"] == points[1]["lat"]
    assert cmd.get("final") is None
    assert cmd["stage"] == 3

    for status in ("RECEIVED", "ACCEPTED", "IN_PROGRESS", "COMPLETED"):
        h.feed("mission/status", {
            "asset_id": "UAV-001", "mission_id": second_message["mission_id"], "status": status,
        })
    assert cmd["final"] == "completed"


def test_goto_route_progress_survives_intermediate_statuses(h):
    h.feed("asset/telemetry", telemetry())
    points = [{"lon": -8.5, "lat": 40.0}, {"lon": -8.2, "lat": 40.2}]
    cmd = h.fleet.send("UAV-001", "goto", None, points)
    mission_id = h.sent[0][1]["mission_id"]

    for status in ("RECEIVED", "ACCEPTED", "IN_PROGRESS"):
        h.feed("mission/status", {
            "asset_id": "UAV-001", "mission_id": mission_id, "status": status,
        })
        assert cmd["key"] in h.fleet._route_by_command

    h.feed("mission/status", {
        "asset_id": "UAV-001", "mission_id": mission_id, "status": "COMPLETED",
    })
    assert len(h.sent) == 2
    assert cmd.get("final") is None


def test_goto_tracks_each_leg_before_immediate_statuses(h):
    h.feed("asset/telemetry", telemetry())
    points = [{"lon": -8.5, "lat": 40.0}, {"lon": -8.2, "lat": 40.2}]

    def publish(topic, message):
        h.sent.append((topic, message))
        for status in ("RECEIVED", "ACCEPTED", "IN_PROGRESS", "COMPLETED"):
            h.feed(
                "mission/status",
                {"asset_id": message["asset_id"], "mission_id": message["mission_id"], "status": status},
            )

    h.fleet._publish = publish
    cmd = h.fleet.send("UAV-001", "goto", None, points)

    assert len(h.sent) == len(points)
    assert cmd["final"] == "completed"
    assert h.sent[-1][1]["destination"]["latitude_deg"] == points[-1]["lat"]


def test_latest_received_speed_wins_whether_from_status_or_telemetry(h):
    h.feed("asset/telemetry", telemetry(state="MOVING", nav="MISSION"))
    assert h.fleet.snapshot()["drones"][0]["spd"] == 54
    h.feed("mission/status", {"asset_id": "UAV-001", "mission_id": "M", "status": "IN_PROGRESS",
                              "current_speed_mps": 10})
    assert h.fleet.snapshot()["drones"][0]["spd"] == 36
    h.feed("asset/telemetry", telemetry(state="MOVING", nav="MISSION"))
    assert h.fleet.snapshot()["drones"][0]["spd"] == 54


def test_rejected_status_is_final(h):
    h.feed("asset/telemetry", telemetry())
    cmd = h.fleet.send("UAV-001", "rtb", None)
    mid = h.sent[0][1]["mission_id"]
    h.feed("mission/status", {"asset_id": "UAV-001", "mission_id": mid, "status": "REJECTED"})
    assert cmd["final"] == "rejected" and "Rejected" in cmd["reason"]


def test_send_errors(h):
    h.feed("asset/telemetry", telemetry())
    h.feed("asset/telemetry", telemetry("UAV-002", "READY", "HOLD"))
    with pytest.raises(UavNotFound):
        h.fleet.send("NOPE", "hold", None)
    with pytest.raises(CommandNotAllowed):
        h.fleet.send("UAV-001", "takeoff", None)
    with pytest.raises(CommandNotImplemented):
        h.fleet.send("UAV-002", "takeoff", None)  # allowed by the state, but no ICD signal
    with pytest.raises(DestinationRequired):
        h.fleet.send("UAV-001", "goto", None)
    assert h.sent == []


def test_publish_failure_becomes_503(h):
    def down(*_):
        raise RuntimeError("closed")

    h.feed("asset/telemetry", telemetry())
    h.fleet._publish = down
    with pytest.raises(FleetUnavailable):
        h.fleet.send("UAV-001", "land", None)


def test_lost_link_marks_asset_and_pending_command_unknown(h):
    h.feed("asset/telemetry", telemetry())
    cmd = h.fleet.send("UAV-001", "land", None)
    h.feed("mission/status", {"asset_id": "UAV-001", "mission_id": h.sent[0][1]["mission_id"], "status": "RECEIVED"})
    h.clock[0] += 12
    h.fleet.tick()
    assert h.fleet.snapshot()["drones"][0]["lost"] is True
    assert cmd["final"] == "unknown"


def test_events_are_saved_once_and_new_assets_registered(h, database):
    h.feed("asset/telemetry", telemetry())
    h.fleet.send("UAV-001", "land", None)
    mid = h.sent[0][1]["mission_id"]
    status = {"asset_id": "UAV-001", "mission_id": mid, "status": "IN_PROGRESS", "timestamp_utc": int(NOW)}
    h.feed("mission/status", status)
    h.feed("mission/status", status)  # repeated status is not a new event
    repository = SqlAlchemyFleetEventRepository(database)
    for operation, args in h.jobs:
        getattr(repository, operation)(*args)
    with Session(database) as s:
        rows = s.execute(select(MissionEvent.kind, MissionEvent.name)).all()
        assert sorted(rows) == [("command", "LAND"), ("status", "IN_PROGRESS")]
        assert s.scalar(select(func.count()).select_from(Uav)) == 1
    assert repository.ensure_uav("UAV-001", "UAV", "ALFA") is False


def test_duplicate_mission_events_are_ignored_without_integrity_errors(database):
    repository = SqlAlchemyFleetEventRepository(database)
    event = ("MIS-1", "UAV-001", "status", "COMPLETED", {"status": "COMPLETED"}, NOW)

    assert repository.save_event(*event) is True
    assert repository.save_event(*event) is False
    with Session(database) as session:
        assert session.scalar(select(func.count()).select_from(MissionEvent)) == 1


def test_fleet_works_end_to_end_with_the_xverse_mock(h):
    """Contract test: the driver and the mock must agree on the ICD."""
    mock_dir = Path(__file__).resolve().parents[2] / "tools" / "xverse-mock"
    if not mock_dir.exists():
        pytest.skip("xverse-mock not available (running inside the backend image)")
    sys.path.insert(0, str(mock_dir))
    from xverse_mock.world import World

    world, t = World(time_scale=1000), [NOW]

    def pump():
        t[0] += 1
        h.clock[0] = t[0]
        for topic, payload in world.step(1.0, t[0]):
            h.feed(topic, payload)

    pump()
    assert {d["id"] for d in h.fleet.snapshot()["drones"]} == {"UAV-001", "UAV-002", "UAV-003", "UAV-004"}

    ok = h.fleet.send("UAV-002", "goto", {"lon": -9.3, "lat": 38.9})
    low = h.fleet.send("UAV-003", "goto", {"lon": -8.0, "lat": 38.2})
    for _, msg in h.sent:
        for topic, payload in world.handle_command(msg, t[0]):
            h.feed(topic, payload)
    for _ in range(60):
        pump()
        if ok.get("final") and low.get("final"):
            break
    assert (ok["final"], low["final"]) == ("completed", "rejected")
    assert "battery" in low["reason"]
    uav2 = next(d for d in h.fleet.snapshot()["drones"] if d["id"] == "UAV-002")
    assert uav2["state"] == "H" and uav2["b"] is None


def test_carla_positions_are_converted_both_ways():
    h = Harness()
    h.fleet = ZenohFleet(lambda t, p: h.sent.append((t, p)), h.recorder, carla_positions=True, clock=lambda: h.clock[0])
    h.feed("asset/telemetry", telemetry(lat=70.7, lon=133.6))  # latitude_deg = X, longitude_deg = Y
    d = h.fleet.snapshot()["drones"][0]
    assert d["frame"] == "local"
    assert d["lon"] == pytest.approx(0.000635109, abs=1e-8)
    assert d["lat"] == pytest.approx(-0.001200149, abs=1e-8)

    h.fleet.send("UAV-001", "goto", {"lon": d["lon"], "lat": d["lat"]})
    dest = h.sent[-1][1]["destination"]
    assert dest["latitude_deg"] == pytest.approx(70.7, abs=1e-3)
    assert dest["longitude_deg"] == pytest.approx(133.6, abs=1e-3)


def _track(h, asset="UAV-001"):
    return next(d for d in h.fleet.snapshot()["drones"] if d["id"] == asset)["track"]


def test_goto_starts_actual_route_at_origin_and_corner_becomes_vertex(h):
    h.feed("asset/telemetry", telemetry(lon=-9.0, lat=39.3))
    assert _track(h) == []  # hovering without a goto has no actual route
    h.fleet.send("UAV-001", "goto", {"lon": -8.9, "lat": 39.4})
    h.feed("mission/status", {"asset_id": "UAV-001", "mission_id": h.sent[-1][1]["mission_id"], "status": "ACCEPTED"})
    assert _track(h) == [[-9.0, 39.3]]
    for i in range(1, 6):  # east, then north: a corner at (-8.95, 39.3)
        h.feed("asset/telemetry", telemetry(state="MOVING", nav="GOTO", lon=-9.0 + i * 0.01, lat=39.3))
    for i in range(1, 6):
        h.feed("asset/telemetry", telemetry(state="MOVING", nav="GOTO", lon=-8.95, lat=39.3 + i * 0.01))
    track = _track(h)
    assert track[0] == [-9.0, 39.3]
    assert [-8.95, 39.3] in track[1:-1]
    assert track[-1] == pytest.approx([-8.95, 39.35])


def test_actual_route_survives_hover_and_resets_on_new_goto(h):
    h.feed("asset/telemetry", telemetry(lon=-9.0, lat=39.3))
    h.fleet.send("UAV-001", "goto", {"lon": -8.9, "lat": 39.3})
    h.feed("mission/status", {"asset_id": "UAV-001", "mission_id": h.sent[-1][1]["mission_id"], "status": "ACCEPTED"})
    h.feed("asset/telemetry", telemetry(state="MOVING", nav="GOTO", lon=-8.95, lat=39.3))
    h.feed("asset/telemetry", telemetry(lon=-8.9, lat=39.3))  # mission done, hovering
    assert _track(h) == [[-9.0, 39.3], [-8.95, 39.3], [-8.9, 39.3]]
    h.fleet.send("UAV-001", "goto", {"lon": -8.8, "lat": 39.3})
    assert _track(h) == [[-9.0, 39.3], [-8.95, 39.3], [-8.9, 39.3]]  # not reset until the asset accepts
    h.feed("mission/status", {"asset_id": "UAV-001", "mission_id": h.sent[-1][1]["mission_id"], "status": "IN_PROGRESS"})
    assert _track(h) == [[-8.9, 39.3]]


def test_actual_route_is_cleared_when_parked(h):
    h.feed("asset/telemetry", telemetry(state="MOVING", nav="RETURN_HOME", lon=-9.0, lat=39.3))
    h.feed("asset/telemetry", telemetry(state="MOVING", nav="RETURN_HOME", lon=-9.1, lat=39.3))
    assert len(_track(h)) == 2
    h.feed("asset/telemetry", telemetry(state="PARKED", lon=-9.1, lat=39.3))
    assert _track(h) == []


def test_rejected_goto_keeps_the_previous_actual_route(h):
    h.feed("asset/telemetry", telemetry(lon=-9.0, lat=39.3))
    h.fleet.send("UAV-001", "goto", {"lon": -8.9, "lat": 39.3})
    h.feed("mission/status", {"asset_id": "UAV-001", "mission_id": h.sent[-1][1]["mission_id"], "status": "ACCEPTED"})
    h.feed("asset/telemetry", telemetry(state="MOVING", nav="GOTO", lon=-8.9, lat=39.3))
    h.feed("asset/telemetry", telemetry(lon=-8.9, lat=39.3))
    before = _track(h)
    h.fleet.send("UAV-001", "goto", {"lon": -8.0, "lat": 39.3})
    h.feed("mission/status", {"asset_id": "UAV-001", "mission_id": h.sent[-1][1]["mission_id"], "status": "REJECTED"})
    assert _track(h) == before
