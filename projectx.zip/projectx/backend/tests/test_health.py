import asyncio

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from c2 import db
from c2.config import settings
from c2.drivers.sim import SimFleet
from c2.main import app
from c2.models import Base, RuntimeConfiguration
from c2.runtime import Runtime, RuntimeSettings

client = TestClient(app)


def test_health():
    assert client.get("/health").json() == {"status": "ok"}


def test_version_reports_driver():
    assert client.get("/version").json()["driver"] == settings.c2_driver


def test_openapi_documents_http_endpoints_and_errors():
    schema = client.get("/openapi.json").json()

    assert schema["openapi"].startswith("3.")
    assert {"/health", "/version", "/db/version", "/uavs/{uav_id}/commands"} <= set(
        schema["paths"]
    )
    command = schema["paths"]["/uavs/{uav_id}/commands"]["post"]
    assert command["responses"]["202"]["content"]["application/json"]["schema"]["$ref"].endswith(
        "/CommandAcceptedResponse"
    )
    assert {"404", "409", "422", "501", "503"} <= set(command["responses"])
    assert "WebSocket" in schema["info"]["description"]


def test_c2_driver_selects_simulator(monkeypatch):
    monkeypatch.setattr(settings, "c2_driver", "sim")
    runtime = Runtime(RuntimeSettings.from_env(settings))

    asyncio.run(runtime.start())

    assert runtime.settings.driver == "sim"
    assert isinstance(runtime._source, SimFleet)


def test_lifespan_persists_active_driver(monkeypatch, tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'runtime.db'}")
    Base.metadata.create_all(engine)
    monkeypatch.setattr(db, "engine", engine)
    monkeypatch.setattr(settings, "c2_driver", "sim")

    with TestClient(app):
        pass

    with Session(engine) as session:
        configuration = session.get(RuntimeConfiguration, 1)
        assert configuration.active_driver == "sim"


def test_driver_is_inferred_from_the_zenoh_endpoint():
    from c2.config import Settings

    assert Settings(_env_file=None, c2_driver="", zenoh_connect="").c2_driver == "sim"
    assert Settings(_env_file=None, c2_driver="", zenoh_connect="tcp/10.0.0.5:7447").c2_driver == "zenoh"
    assert Settings(_env_file=None, c2_driver="sim", zenoh_connect="tcp/10.0.0.5:7447").c2_driver == "sim"
