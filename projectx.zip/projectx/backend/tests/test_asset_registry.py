import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from c2.models import Base, Uav
from c2.services.asset_registry import DEFAULT, AssetMetadata, AssetRegistry


@pytest.fixture()
def engine(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'registry.db'}")
    Base.metadata.create_all(engine)
    return engine


@pytest.fixture()
def registry(engine):
    return AssetRegistry(engine)


def _row(engine, **extra):
    base = {
        "id": "UAV-01", "name": "UAV-01", "domain": "air",
        "affiliation": "FRIEND", "platform_type": "ROTARY_UAV",
    }
    base.update(extra)
    with Session(engine) as s:
        s.add(Uav(**base))
        s.commit()


def test_get_returns_default_for_unknown_asset_without_caching_it(registry):
    assert registry.get("ghost") == DEFAULT
    assert registry.get("ghost") == DEFAULT  # still default; not pinned in cache
    assert "ghost" not in registry._cache  # private peek: new row later would be picked up


def test_get_reads_row_and_caches_it(registry, engine):
    _row(engine, callsign="ALPHA-1", higher_formation="1 ESQAV", echelon="SECTION")
    meta = registry.get("UAV-01")
    assert meta.callsign == "ALPHA-1"
    assert meta.higher_formation == "1 ESQAV"
    assert meta.echelon == "SECTION"
    assert "UAV-01" in registry._cache


def test_preload_populates_cache_without_touching_db(registry, engine):
    registry.preload({"SIM-01": AssetMetadata("FRIEND", "ROTARY_UAV", "BRAVO-2", None, None)})
    assert registry.get("SIM-01").callsign == "BRAVO-2"
    with Session(engine) as s:
        assert s.get(Uav, "SIM-01") is None  # preload does not create rows


def test_upsert_updates_existing_row_and_invalidates_cache(registry, engine):
    _row(engine, callsign="OLD")
    registry.get("UAV-01")  # warm cache
    registry.upsert("UAV-01", callsign="NEW", echelon="PLATOON")
    assert registry.get("UAV-01").callsign == "NEW"
    assert registry.get("UAV-01").echelon == "PLATOON"


def test_upsert_creates_row_for_cached_only_asset_so_sim_edits_persist(registry, engine):
    registry.preload({"SIM-01": AssetMetadata("FRIEND", "ROTARY_UAV", "LEGACY", None, None)})
    registry.upsert("SIM-01", callsign="ALPHA-1")
    with Session(engine) as s:
        row = s.get(Uav, "SIM-01")
        assert row is not None
        assert row.callsign == "ALPHA-1"
        assert row.platform_type == "ROTARY_UAV"  # inherited from cache


def test_upsert_rejects_unknown_fields_silently(registry, engine):
    _row(engine)
    registry.upsert("UAV-01", callsign="X", secret="ignored")  # type: ignore[arg-type]
    assert registry.get("UAV-01").callsign == "X"


def test_all_merges_db_rows_with_cached_only_entries(registry, engine):
    _row(engine, id="UAV-01", callsign="DB")
    registry.preload({"SIM-01": AssetMetadata("FRIEND", "ROTARY_UAV", "CACHE", None, None)})
    records = {r["id"]: r for r in registry.all()}
    assert records["UAV-01"]["callsign"] == "DB"
    assert records["SIM-01"]["callsign"] == "CACHE"


def test_in_memory_only_registry_works_without_engine():
    registry = AssetRegistry(engine=None)
    registry.preload({"SIM-01": AssetMetadata("FRIEND", "ROTARY_UAV", "A", None, None)})
    assert registry.get("SIM-01").callsign == "A"
    registry.upsert("SIM-01", callsign="B")
    assert registry.get("SIM-01").callsign == "B"


def test_fleet_service_enriches_snapshot_with_military_metadata(registry, engine):
    from c2.services.fleet import FleetService

    _row(
        engine,
        id="UAV-01",
        callsign="ALPHA-1",
        platform_type="FIXED_WING_UAV",
        higher_formation="1 ESQAV",
        echelon="PLATOON",
    )

    class FakeFleet:
        def snapshot(self):
            return {"t": 0, "drones": [{"id": "UAV-01", "state": "H"}], "cmds": []}

        def tick(self):
            pass

        def send(self, *a, **k):
            raise NotImplementedError

    service = FleetService(FakeFleet(), registry)
    snap = service.snapshot()
    drone = snap["drones"][0]
    assert drone["affiliation"] == "FRIEND"
    assert drone["platformType"] == "FIXED_WING_UAV"
    assert drone["callsign"] == "ALPHA-1"
    assert drone["higherFormation"] == "1 ESQAV"
    assert drone["echelon"] == "PLATOON"


def test_fleet_service_returns_defaults_when_asset_is_not_yet_registered(registry):
    from c2.services.fleet import FleetService

    class FakeFleet:
        def snapshot(self):
            return {"t": 0, "drones": [{"id": "ghost", "state": "H"}], "cmds": []}

        def tick(self):
            pass

        def send(self, *a, **k):
            raise NotImplementedError

    service = FleetService(FakeFleet(), registry)
    drone = service.snapshot()["drones"][0]
    assert drone["affiliation"] == "FRIEND"
    assert drone["platformType"] == "ROTARY_UAV"
    assert drone["callsign"] is None
