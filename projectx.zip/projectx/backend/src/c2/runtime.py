"""Runtime-editable settings and the owner of the active fleet source.

Settings start from the environment; values saved from the configuration screen are persisted and
override the environment at the next startup until they are reset.
"""

import asyncio
import logging
import re
import time
from typing import Any, Literal, Protocol

from pydantic import BaseModel, Field, ValidationError, field_validator

from c2.config import Settings
from c2.config import settings as env_settings
from c2.drivers import sim
from c2.ports.fleet import FleetPort
from c2.services.asset_registry import AssetRegistry
from c2.services.fleet import FleetService

log = logging.getLogger(__name__)

ENDPOINT = re.compile(r"^(tcp|udp|tls|quic|ws)/[\w.\-:\[\]]+$")


def check_endpoints(value: str) -> str:
    parts = [p.strip() for p in value.split(",") if p.strip()]
    for part in parts:
        if not ENDPOINT.match(part):
            raise ValueError(f"invalid Zenoh endpoint {part!r} (expected e.g. tcp/host:7447)")
    return ",".join(parts)


class RuntimeSettings(BaseModel):
    driver: Literal["sim", "zenoh", "nato"] = Field(description="Fleet source. NATO is reserved.")
    zenoh_connect: str = Field(default="", description="Comma-separated Zenoh endpoints, e.g. tcp/10.0.0.5:7447.")
    operator_id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9._-]+$")
    default_speed_mps: float = Field(gt=0, le=100)
    lost_after_s: int = Field(ge=3, le=300, description="Seconds without a signal before an asset is shown as lost.")

    @field_validator("zenoh_connect")
    @classmethod
    def _endpoints(cls, value: str) -> str:
        return check_endpoints(value)
    @classmethod
    def from_env(cls, env: Settings) -> "RuntimeSettings":
        return cls(
            driver=env.c2_driver,
            zenoh_connect=env.zenoh_connect,
            operator_id=env.c2_operator_id,
            default_speed_mps=env.c2_default_speed_mps,
            lost_after_s=env.c2_lost_after_s,
        )


class SettingsStore(Protocol):
    def load_settings(self) -> dict[str, Any] | None: ...
    def save_settings(self, settings: dict[str, Any]) -> None: ...
    def clear_settings(self) -> None: ...


class DriverNotImplemented(RuntimeError):
    pass


class Runtime:
    def __init__(
        self,
        defaults: RuntimeSettings,
        store: SettingsStore | None = None,
        registry: AssetRegistry | None = None,
    ) -> None:
        self.defaults = defaults
        self.settings = defaults
        self.origin: Literal["environment", "saved"] = "environment"
        self.service: FleetService
        self._store = store
        self._registry = registry if registry is not None else AssetRegistry()
        self._lock = asyncio.Lock()
        self._source: FleetPort | None = None
        self._transport: Any = None
        self._tasks: list[asyncio.Task[None]] = []

    async def start(self) -> None:
        if self._store is not None:
            try:
                stored = await asyncio.to_thread(self._store.load_settings)
                if stored:
                    self.settings = RuntimeSettings(**stored)
                    self.origin = "saved"
            except (ValidationError, TypeError):
                log.warning("ignoring invalid saved settings", exc_info=True)
            except Exception:
                log.warning("could not load saved settings", exc_info=True)
        self._build()

    async def stop(self) -> None:
        await self._cancel()

    async def apply(self, new: RuntimeSettings) -> bool:
        """Switches to the new settings and saves them. Returns False when saving failed."""
        if new.driver == "nato":
            raise DriverNotImplemented("the NATO driver is not implemented yet")
        async with self._lock:
            await self._cancel()
            self.settings = new
            self.origin = "saved"
            self._build()
        return await self._persist(lambda: self._store.save_settings(new.model_dump()) if self._store else None)

    async def reset(self) -> bool:
        async with self._lock:
            await self._cancel()
            self.settings = self.defaults
            self.origin = "environment"
            self._build()
        return await self._persist(lambda: self._store.clear_settings() if self._store else None)

    @property
    def registry(self) -> AssetRegistry:
        return self._registry

    def status(self) -> dict[str, Any]:
        connected, peers = True, None
        if self._transport is not None:
            connected, peers = self._transport.connected, self._transport.peers()
        last = getattr(self._source, "last_message_at", None)
        return {
            "driver": self.settings.driver,
            "connected": connected,
            "peers": peers,
            "assets": len(self.service.snapshot()["drones"]),
            "last_message_s": None if last is None else round(time.time() - last, 1),
        }

    async def _persist(self, op: Any) -> bool:
        try:
            await asyncio.to_thread(op)
            return True
        except Exception:
            log.warning("could not persist runtime settings", exc_info=True)
            return False

    async def _cancel(self) -> None:
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks, self._transport = [], None

    def _log_choice(self, cfg: RuntimeSettings) -> None:
        log.info(
            "fleet driver=%s zenoh_connect=%r position_format=%s settings_from=%s",
            cfg.driver, cfg.zenoh_connect, env_settings.c2_position_format, self.origin,
        )
        if cfg.driver == "sim" and cfg.zenoh_connect:
            log.warning("ZENOH_CONNECT is set but the driver is 'sim', so Zenoh is not used")
        if cfg.driver == "sim" and self.origin == "saved":
            log.warning("driver 'sim' comes from settings saved in the database; reset them in Settings to follow the environment")
        if cfg.driver == "zenoh" and not cfg.zenoh_connect:
            log.warning("no Zenoh endpoint set: the session will discover any Zenoh node on the network by multicast")

    def _build(self) -> None:
        cfg = self.settings
        self._log_choice(cfg)
        if cfg.driver == "sim":
            source: FleetPort = sim.SimFleet()
            self._registry.preload(sim.initial_metadata())
        else:
            from c2 import db
            from c2.drivers.zenoh.fleet import ZenohFleet
            from c2.drivers.zenoh.transport import ZenohTransport
            from c2.repositories.events import SqlAlchemyFleetEventRepository
            from c2.services.event_recorder import QueuedFleetEventRecorder

            recorder = QueuedFleetEventRecorder(SqlAlchemyFleetEventRepository(db.engine))
            self._transport = ZenohTransport(cfg.zenoh_connect)
            source = ZenohFleet(
                self._transport.publish, recorder, operator_id=cfg.operator_id,
                speed_mps=cfg.default_speed_mps, lost_after_s=cfg.lost_after_s,
                carla_positions=env_settings.c2_position_format == "carla",
            )
            self._tasks = [
                asyncio.create_task(self._transport.run(source.on_message)),
                asyncio.create_task(recorder.run()),
            ]
        self._source = source
        if hasattr(self, "service"):
            self.service.replace(source)
        else:
            self.service = FleetService(source, self._registry)
