"""Port every fleet data source implements (server simulator, Zenoh driver, a future NATO driver)."""

from typing import Any, Protocol

Command = dict[str, Any]


class FleetPort(Protocol):
    def snapshot(self) -> dict[str, Any]:
        """JSON-ready {t, drones, cmds}: the shape the frontend consumes."""
        ...

    def tick(self) -> None:
        """Called once per second before the snapshot is broadcast."""
        ...

    def send(self, drone_id: str, action: str, b: dict[str, float] | None) -> Command: ...
