from typing import Any, Protocol


class FleetEventRepository(Protocol):
    def save_event(
        self,
        mission_id: str,
        asset_id: str,
        kind: str,
        name: str,
        payload: dict[str, Any],
        occurred_at: float,
    ) -> bool: ...

    def ensure_uav(self, asset_id: str, asset_type: str, base_id: str | None) -> bool: ...