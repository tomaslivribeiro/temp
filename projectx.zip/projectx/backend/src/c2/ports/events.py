from typing import Any, Protocol


class FleetEventRecorderPort(Protocol):
    def record_event(
        self,
        mission_id: str,
        asset_id: str,
        kind: str,
        name: str,
        payload: dict[str, Any],
        occurred_at: float,
    ) -> None: ...

    def register_asset(self, asset_id: str, asset_type: str, base_id: str | None) -> None: ...