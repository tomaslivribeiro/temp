"""Actual route flown by an asset, built only from its reported positions.

The route is a polyline that starts at the asset's origin and keeps a vertex wherever the path stops being
straight. Visited waypoints (the asset turns there), deviations and curves inside a single goto all become
vertices the same way, so this does not depend on how the movement was commanded.

Simplification is an online "opening window": points accumulate while all of them stay within
`tolerance_m` of the line from the last vertex to the newest point. When a new point breaks that, the
previous point becomes a vertex. Every reported point therefore stays within `tolerance_m` of the drawn line,
as long as the route has at most `max_vertices` vertices. Past that, the vertex whose removal changes the line
least is merged into its neighbours (the origin and the latest vertex are always kept), so a very long route
loses its smallest wiggles first instead of a whole stretch near the origin.

Points are `[lon, lat]` lists, the same shape as `trail` in the snapshot. Distances use a local
equirectangular projection, which also holds for CARLA positions (metres projected near lon/lat 0).
"""

import math
from typing import Any

TOLERANCE_M = 5.0
MIN_STEP_M = 1.0  # ignore GPS jitter while hovering
MAX_VERTICES = 500
MAX_PENDING = 200

Point = list[float]

M_PER_DEG_LAT = 110_570.0
M_PER_DEG_LON = 111_320.0

# UI states (see c2.domain.commands): S standby, O off, M mission, R return to base.
CLEARS_ROUTE = {"S", "O"}
STARTS_ROUTE = {"M", "R"}


def _to_xy(p: Point, origin: Point) -> tuple[float, float]:
    cos_lat = math.cos(math.radians(origin[1]))
    return (p[0] - origin[0]) * M_PER_DEG_LON * cos_lat, (p[1] - origin[1]) * M_PER_DEG_LAT


def distance_m(a: Point, b: Point) -> float:
    return math.hypot(*_to_xy(b, a))


def distance_to_segment_m(p: Point, a: Point, b: Point) -> float:
    """Distance in metres from `p` to the segment `a`-`b`."""
    px, py = _to_xy(p, a)
    bx, by = _to_xy(b, a)
    length2 = bx * bx + by * by
    t = 0.0 if length2 == 0 else max(0.0, min(1.0, (px * bx + py * by) / length2))
    return math.hypot(px - t * bx, py - t * by)


class ActualRoute:
    def __init__(
        self,
        *,
        tolerance_m: float = TOLERANCE_M,
        min_step_m: float = MIN_STEP_M,
        max_vertices: int = MAX_VERTICES,
        max_pending: int = MAX_PENDING,
    ) -> None:
        self.tolerance_m = tolerance_m
        self.min_step_m = min_step_m
        self.max_vertices = max_vertices
        self.max_pending = max_pending
        self.vertices: list[Point] = []
        self._pending: list[Point] = []
        self._last_state: str | None = None
        self._fresh = False  # reset() since the asset last moved (a goto already set the new origin)

    @property
    def active(self) -> bool:
        return bool(self.vertices)

    def reset(self, origin: Point) -> None:
        self.vertices = [list(origin)]
        self._pending = []
        self._fresh = True

    def clear(self) -> None:
        self.vertices = []
        self._pending = []

    def update(self, p: Point) -> None:
        if not self.vertices:
            self.reset(p)
            return
        last = self._pending[-1] if self._pending else self.vertices[-1]
        if distance_m(last, p) < self.min_step_m:
            return
        p = list(p)
        anchor = self.vertices[-1]
        if any(distance_to_segment_m(q, anchor, p) > self.tolerance_m for q in self._pending):
            # Every pending point fitted the line to the previous point, so that point is the vertex.
            self._add_vertex(self._pending[-1])
            self._pending = []
        self._pending.append(p)
        if len(self._pending) > self.max_pending:
            self._add_vertex(self._pending[-1])
            self._pending = []

    def observe(self, state: str, p: Point) -> None:
        """Applies the lifecycle for one position report in UI state `state`."""
        previous, self._last_state = self._last_state, state
        if state in CLEARS_ROUTE:
            self.clear()
            return
        restart = previous is not None and previous not in STARTS_ROUTE and self.active and not self._fresh
        if state in STARTS_ROUTE and restart:
            # Moving again after a stop without a goto (for example RTB after the mission): a new route from here.
            self.reset(p)
        elif self.active or state in STARTS_ROUTE:
            self.update(p)
        if state in STARTS_ROUTE:
            self._fresh = False

    def polyline(self) -> list[Point]:
        """Vertices plus the real points not yet confirmed as a vertex; the last one is the latest position."""
        return [*self.vertices, *self._pending]

    def snapshot_fields(self) -> dict[str, Any]:
        """Drone fields for the snapshot: the polyline (origin first, latest position last)."""
        return {"track": self.polyline()}

    def _add_vertex(self, p: Point) -> None:
        self.vertices.append(p)
        if len(self.vertices) > self.max_vertices:
            # Merge the least significant interior vertex (smallest distance to the line between its neighbours).
            v = self.vertices
            i = min(range(1, len(v) - 1), key=lambda k: distance_to_segment_m(v[k], v[k - 1], v[k + 1]))
            del v[i]
