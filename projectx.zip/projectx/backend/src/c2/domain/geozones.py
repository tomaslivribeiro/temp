"""No-fly zones: a source-independent shape vocabulary and its GeoJSON rendering.

Zones are stored with the shape they were defined with (circle, rectangle, polygon, multipolygon)
so geometric tests stay exact, e.g. "is this point inside a circle" is `distance <= radius`, not a
test against a 64-sided approximation. `to_geojson_geometry` is only for drawing.

Shape vocabulary (WGS 84, coordinates are `[lon, lat]`):

    {"type": "circle", "center": [lon, lat], "radius_m": n}
    {"type": "rectangle", "bounds": [west, south, east, north]}      # axis-aligned
    {"type": "polygon", "rings": [[[lon, lat], ...], ...]}           # outer ring, then holes
    {"type": "multipolygon", "polygons": [<rings>, ...]}
"""

import math
from dataclasses import dataclass
from datetime import UTC, datetime
from itertools import pairwise
from typing import Any

# Same flat-earth constants as frontend/src/domain/geo.ts: fine at the scale of one zone.
M_PER_DEG_LAT = 110_570.0
M_PER_DEG_LON = 111_320.0
CIRCLE_SEGMENTS = 64

Restriction = str  # PROHIBITED | REQUIRES_AUTHORISATION | CONDITIONAL | NO_RESTRICTION
RESTRICTIONS = ("PROHIBITED", "REQUIRES_AUTHORISATION", "CONDITIONAL", "NO_RESTRICTION")
ALTITUDE_REFERENCES = ("AGL", "AMSL")


class InvalidShape(ValueError):
    """The shape does not follow the vocabulary above."""


@dataclass(frozen=True, slots=True)
class GeozoneSource:
    """Where a set of zones came from: the attribution (and licence note) shown to operators."""

    id: str
    name: str
    url: str | None
    attribution: str
    license_note: str | None
    dataset_version: str | None
    retrieved_at: datetime | None


@dataclass(frozen=True, slots=True)
class Geozone:
    id: int
    source_id: str
    external_id: str
    name: str
    restriction: Restriction
    reason: str | None
    message: str | None
    shape: dict[str, Any]
    lower_m: float | None
    upper_m: float | None
    lower_ref: str | None
    upper_ref: str | None
    valid_from: datetime | None
    valid_to: datetime | None
    properties: dict[str, Any]


def _position(value: Any) -> list[float]:
    if (
        not isinstance(value, (list, tuple))
        or len(value) < 2
        or not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in value[:2])
    ):
        raise InvalidShape(f"invalid position: {value!r}")
    lon, lat = float(value[0]), float(value[1])
    if not (-180 <= lon <= 180 and -90 <= lat <= 90):
        raise InvalidShape(f"position out of range: {value!r}")
    return [lon, lat]


def _ring(value: Any) -> list[list[float]]:
    if not isinstance(value, (list, tuple)):
        raise InvalidShape("a ring must be a list of positions")
    ring = [_position(p) for p in value]
    if len(ring) < 3:
        raise InvalidShape("a ring needs at least 3 distinct positions")
    if ring[0] != ring[-1]:
        ring.append(list(ring[0]))
    if len(ring) < 4:
        raise InvalidShape("a ring needs at least 3 distinct positions")
    return ring


def _rings(value: Any) -> list[list[list[float]]]:
    if not isinstance(value, (list, tuple)) or not value:
        raise InvalidShape("a polygon needs at least one ring")
    return [_ring(r) for r in value]


def validate_shape(shape: Any) -> dict[str, Any]:
    """Returns the normalised shape (floats, closed rings) or raises InvalidShape."""
    if not isinstance(shape, dict):
        raise InvalidShape("shape must be an object")
    kind = shape.get("type")
    if kind == "circle":
        radius = shape.get("radius_m")
        if not isinstance(radius, (int, float)) or isinstance(radius, bool) or radius <= 0:
            raise InvalidShape("circle radius_m must be a positive number")
        return {"type": "circle", "center": _position(shape.get("center")), "radius_m": float(radius)}
    if kind == "rectangle":
        bounds = shape.get("bounds")
        if not isinstance(bounds, (list, tuple)) or len(bounds) != 4:
            raise InvalidShape("rectangle bounds must be [west, south, east, north]")
        west, south = _position(bounds[:2])
        east, north = _position(bounds[2:])
        if west >= east or south >= north:
            raise InvalidShape("rectangle needs west < east and south < north")
        return {"type": "rectangle", "bounds": [west, south, east, north]}
    if kind == "polygon":
        return {"type": "polygon", "rings": _rings(shape.get("rings"))}
    if kind == "multipolygon":
        polygons = shape.get("polygons")
        if not isinstance(polygons, (list, tuple)) or not polygons:
            raise InvalidShape("multipolygon needs at least one polygon")
        return {"type": "multipolygon", "polygons": [_rings(p) for p in polygons]}
    raise InvalidShape(f"unknown shape type: {kind!r}")


def _circle_ring(center: list[float], radius_m: float) -> list[list[float]]:
    lon0, lat0 = center
    m_per_deg_lon = M_PER_DEG_LON * max(math.cos(math.radians(lat0)), 1e-6)
    ring = []
    for i in range(CIRCLE_SEGMENTS):
        theta = 2 * math.pi * i / CIRCLE_SEGMENTS
        ring.append(
            [
                lon0 + radius_m * math.sin(theta) / m_per_deg_lon,
                lat0 + radius_m * math.cos(theta) / M_PER_DEG_LAT,
            ]
        )
    ring.append(list(ring[0]))
    return ring


def to_geojson_geometry(shape: dict[str, Any]) -> dict[str, Any]:
    """GeoJSON geometry used to draw the zone. Circles are approximated, the stored shape is not."""
    shape = validate_shape(shape)
    kind = shape["type"]
    if kind == "circle":
        return {"type": "Polygon", "coordinates": [_circle_ring(shape["center"], shape["radius_m"])]}
    if kind == "rectangle":
        west, south, east, north = shape["bounds"]
        ring = [[west, south], [east, south], [east, north], [west, north], [west, south]]
        return {"type": "Polygon", "coordinates": [ring]}
    if kind == "polygon":
        return {"type": "Polygon", "coordinates": shape["rings"]}
    return {"type": "MultiPolygon", "coordinates": shape["polygons"]}


def shape_bounds(shape: dict[str, Any]) -> tuple[float, float, float, float]:
    """(west, south, east, north) of the drawn geometry."""
    geometry = to_geojson_geometry(shape)
    polygons = [geometry["coordinates"]] if geometry["type"] == "Polygon" else geometry["coordinates"]
    points = [p for rings in polygons for ring in rings for p in ring]
    lons = [p[0] for p in points]
    lats = [p[1] for p in points]
    return min(lons), min(lats), max(lons), max(lats)


Point = list[float]  # [lon, lat]


def _in_ring(point: Point, ring: list[Point]) -> bool:
    """Ray casting. Points exactly on the boundary are caught by the edge test instead."""
    x, y = point
    inside = False
    for (x1, y1), (x2, y2) in pairwise(ring):
        if (y1 > y) != (y2 > y) and x < x1 + (y - y1) * (x2 - x1) / (y2 - y1):
            inside = not inside
    return inside


def _cross(o: Point, a: Point, b: Point) -> float:
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _within_box(p: Point, a: Point, b: Point) -> bool:
    return min(a[0], b[0]) <= p[0] <= max(a[0], b[0]) and min(a[1], b[1]) <= p[1] <= max(a[1], b[1])


def _touches(a: Point, b: Point, c: Point, d: Point) -> list[float]:
    """Fractions of leg ab at which it crosses or touches the edge cd (empty when it does not)."""
    d1, d2 = _cross(c, d, a), _cross(c, d, b)
    d3, d4 = _cross(a, b, c), _cross(a, b, d)
    if d1 * d2 < 0 and d3 * d4 < 0:
        return [d1 / (d1 - d2)]
    found = []
    if d1 == 0 and _within_box(a, c, d):
        found.append(0.0)
    if d2 == 0 and _within_box(b, c, d):
        found.append(1.0)
    # An end of the edge lying on the leg: measured along the leg's longer axis.
    axis = 0 if abs(b[0] - a[0]) >= abs(b[1] - a[1]) else 1
    for side, end in ((d3, c), (d4, d)):
        if side == 0 and _within_box(end, a, b):
            length = b[axis] - a[axis]
            found.append(0.0 if length == 0 else (end[axis] - a[axis]) / length)
    return found


def _polygon_entry(a: Point, b: Point, rings: list[list[Point]]) -> float | None:
    outer, holes = rings[0], rings[1:]
    if _in_ring(a, outer) and not any(_in_ring(a, hole) for hole in holes):
        return 0.0
    # Starting outside (or in a hole), the leg can only get in across an edge.
    hits = (t for ring in rings for c, d in pairwise(ring) for t in _touches(a, b, c, d))
    return min(hits, default=None)


def _circle_entry(a: Point, b: Point, center: Point, radius_m: float) -> float | None:
    """Worked in metres on the same flat plane the circle is drawn on."""
    m_per_deg_lon = M_PER_DEG_LON * max(math.cos(math.radians(center[1])), 1e-6)
    ax, ay = (a[0] - center[0]) * m_per_deg_lon, (a[1] - center[1]) * M_PER_DEG_LAT
    dx, dy = (b[0] - a[0]) * m_per_deg_lon, (b[1] - a[1]) * M_PER_DEG_LAT
    if math.hypot(ax, ay) <= radius_m:
        return 0.0
    length = math.hypot(dx, dy)
    if length == 0:
        return None
    # `foot`: fraction along the leg where the perpendicular from the centre meets it.
    foot = -(ax * dx + ay * dy) / length**2
    closest = max(0.0, min(1.0, foot))
    if math.hypot(ax + closest * dx, ay + closest * dy) > radius_m:
        return None
    # The boundary lies half a chord before the foot.
    offset = abs(ax * dy - ay * dx) / length
    return max(0.0, foot - math.sqrt(max(radius_m**2 - offset**2, 0.0)) / length)


def route_entry(shape: dict[str, Any], points: list[Point]) -> float | None:
    """Where the route first passes over (or touches) the zone, ignoring altitude.

    The result is the leg number plus the fraction of that leg, so it orders zones by when the
    route reaches them; None when it never does. Legs are straight in lon/lat, as drawn on the map.
    """
    shape = validate_shape(shape)
    if shape["type"] == "circle":
        polygons = None
    else:
        geometry = to_geojson_geometry(shape)
        polygons = (
            [geometry["coordinates"]] if geometry["type"] == "Polygon" else geometry["coordinates"]
        )
    for leg, (a, b) in enumerate(pairwise(points)):
        if polygons is None:
            entry = _circle_entry(a, b, shape["center"], shape["radius_m"])
        else:
            hits = (_polygon_entry(a, b, rings) for rings in polygons)
            entry = min((t for t in hits if t is not None), default=None)
        if entry is not None:
            return leg + entry
    return None


def _utc(value: datetime) -> datetime:
    return value if value.tzinfo else value.replace(tzinfo=UTC)


def is_active(valid_from: datetime | None, valid_to: datetime | None, at: datetime) -> bool:
    """A zone with no validity window is permanent. Naive datetimes (SQLite) are UTC."""
    at = _utc(at)
    if valid_from is not None and _utc(valid_from) > at:
        return False
    return valid_to is None or _utc(valid_to) >= at
