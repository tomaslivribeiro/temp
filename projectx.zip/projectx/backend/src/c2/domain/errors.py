class FleetError(Exception):
    """Base class for fleet-domain failures."""


class UavNotFound(FleetError):
    pass


class CommandNotAllowed(FleetError):
    pass


class CommandNotImplemented(FleetError):
    pass


class DestinationRequired(FleetError):
    pass


class FleetUnavailable(FleetError):
    pass