from c2.domain.errors import CommandNotAllowed, DestinationRequired

MIN_MISSION_BATTERY = 30
KEEP_COMMANDS = 30

COMMAND_MATRIX: dict[str, set[str]] = {
    "O": {"poweron"},
    "S": {"takeoff", "goto", "poweroff"},
    "T": {"hold"},
    "H": {"goto", "rtb", "land"},
    "M": {"hold", "changeb", "rtb", "land"},
    "R": {"hold", "goto"},
    "L": {"hold"},
    "G": {"takeoff"},
}


def validate_command(
    state: str,
    action: str,
    destination: dict[str, float] | None,
    waypoints: list[dict[str, float]] | None = None,
) -> None:
    # Goto may be supplied as a waypoint array or retain the legacy destination fallback.
    if action not in COMMAND_MATRIX.get(state, set()):
        raise CommandNotAllowed(f"{action} is not allowed while the UAV is in state {state}")
    if action == "goto" and not (waypoints or destination):
        raise DestinationRequired("goto needs at least one waypoint")
    if action == "changeb" and destination is None:
        raise DestinationRequired("changeb needs a point B")