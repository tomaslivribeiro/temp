from c2.domain.errors import CommandNotAllowed, DestinationRequired

MIN_MISSION_BATTERY = 30
KEEP_COMMANDS = 30

COMMAND_MATRIX: dict[str, set[str]] = {
    "O": {"poweron"},
    "S": {"takeoff", "goto", "poweroff"},
    "T": {"hold"},
    "H": {"goto", "rtb", "land"},
    "M": {"hold", "changeb", "rtb", "land"},
    "R": {"hold", "goto"},
    "L": {"hold"},
    "G": {"takeoff"},
}


def validate_command(state: str, action: str, destination: dict[str, float] | None) -> None:
    if action not in COMMAND_MATRIX.get(state, set()):
        raise CommandNotAllowed(f"{action} is not allowed while the UAV is in state {state}")
    if action in ("goto", "changeb") and destination is None:
        raise DestinationRequired(f"{action} needs a point B")