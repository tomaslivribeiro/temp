from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase

from c2.config import settings


class Base(DeclarativeBase):
    """Declarative base: Alembic reads Base.metadata to know the schema."""


# Connects lazily: importing this module never needs a running database.
engine = create_engine(
    settings.database_url,
    pool_pre_ping=True,
    connect_args={"connect_timeout": 2} if settings.database_url.startswith("postgresql") else {},
)


def current_revision() -> str | None:
    """Alembic revision applied to the database (None if never migrated). Raises if the DB is down."""
    with engine.connect() as conn:
        exists = conn.execute(text("select to_regclass('alembic_version')")).scalar()
        if exists is None:
            return None
        return conn.execute(text("select version_num from alembic_version")).scalar()
