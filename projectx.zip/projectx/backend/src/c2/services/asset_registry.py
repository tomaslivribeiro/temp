"""Military metadata registry: affiliation, platform type, callsign, higher formation, echelon.

Read-through cache over the `uav` table. Snapshots are enriched on every tick so this is on the
hot path; cache invalidation happens on `upsert`. When no engine is attached (e.g. the simulator
runs without a database), the registry is pure in-memory.
"""

import logging
from dataclasses import dataclass
from typing import Any, Literal

from sqlalchemy import select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from c2.models import Uav

log = logging.getLogger(__name__)

Affiliation = Literal["FRIEND", "HOSTILE", "NEUTRAL", "UNKNOWN"]
PlatformType = Literal[
    "ROTARY_UAV", "FIXED_WING_UAV", "WHEELED_UGV", "TRACKED_UGV", "USV", "FOOT"
]
Echelon = Literal[
    "TEAM", "SQUAD", "SECTION", "PLATOON", "COMPANY",
    "BATTALION", "REGIMENT", "BRIGADE", "DIVISION", "CORPS",
]

AFFILIATIONS: tuple[Affiliation, ...] = ("FRIEND", "HOSTILE", "NEUTRAL", "UNKNOWN")
PLATFORMS: tuple[PlatformType, ...] = (
    "ROTARY_UAV", "FIXED_WING_UAV", "WHEELED_UGV", "TRACKED_UGV", "USV", "FOOT",
)
ECHELONS: tuple[Echelon, ...] = (
    "TEAM", "SQUAD", "SECTION", "PLATOON", "COMPANY",
    "BATTALION", "REGIMENT", "BRIGADE", "DIVISION", "CORPS",
)

# ICD asset_type (from the X-Verse telemetry payload) -> default platform category on first sighting.
ASSET_TYPE_TO_PLATFORM: dict[str, PlatformType] = {
    "UAV": "ROTARY_UAV",
    "UGV": "WHEELED_UGV",
    "USV": "USV",
    "DIGITAL_TWIN": "ROTARY_UAV",
}


@dataclass(frozen=True, slots=True)
class AssetMetadata:
    affiliation: Affiliation
    platform_type: PlatformType
    callsign: str | None
    higher_formation: str | None
    echelon: Echelon | None

    def to_snapshot(self) -> dict[str, Any]:
        return {
            "affiliation": self.affiliation,
            "platformType": self.platform_type,
            "callsign": self.callsign,
            "higherFormation": self.higher_formation,
            "echelon": self.echelon,
        }


DEFAULT = AssetMetadata(
    affiliation="FRIEND",
    platform_type="ROTARY_UAV",
    callsign=None,
    higher_formation=None,
    echelon=None,
)


_WRITABLE_FIELDS = {"affiliation", "platform_type", "callsign", "higher_formation", "echelon"}


class AssetRegistry:
    """Read-through cache; writes go to the DB and invalidate the entry.

    When `engine` is None the registry is purely in-memory, used by the simulator in environments
    without Postgres (host unit tests).
    """

    def __init__(self, engine: Engine | None = None) -> None:
        self._engine = engine
        self._cache: dict[str, AssetMetadata] = {}

    def get(self, asset_id: str) -> AssetMetadata:
        if asset_id in self._cache:
            return self._cache[asset_id]
        if self._engine is None:
            return DEFAULT
        row = self._load(asset_id)
        if row is None:  # DB row not yet created (zenoh ensure_uav is async-queued); try again later
            return DEFAULT
        self._cache[asset_id] = row
        return row

    def preload(self, entries: dict[str, AssetMetadata]) -> None:
        """Seeds the in-memory cache; useful for the simulator which has no DB rows."""
        self._cache.update(entries)

    def upsert(self, asset_id: str, **fields: Any) -> AssetMetadata:
        clean = {k: v for k, v in fields.items() if k in _WRITABLE_FIELDS}
        if self._engine is None:
            self._cache[asset_id] = _replace(self.get(asset_id), **clean)
            return self._cache[asset_id]
        with Session(self._engine) as session:
            row = session.get(Uav, asset_id)
            if row is None:
                # Sim mode: the asset lives only in the preloaded cache. Create its DB row so edits
                # persist (and so admin UI reads consistently). The Zenoh path registers rows
                # earlier via ensure_uav so this branch is cold for real assets.
                cached = self._cache.get(asset_id, DEFAULT)
                row = Uav(
                    id=asset_id, name=asset_id, domain="air",
                    affiliation=cached.affiliation, platform_type=cached.platform_type,
                    callsign=cached.callsign, higher_formation=cached.higher_formation,
                    echelon=cached.echelon,
                )
                session.add(row)
            for key, value in clean.items():
                setattr(row, key, value)
            session.commit()
        self._cache.pop(asset_id, None)
        return self.get(asset_id)

    def all(self) -> list[dict[str, Any]]:
        """Returns a list of full asset records (id, name, domain, base_id, metadata fields).

        Merges DB rows with any entries that only live in the in-memory cache (sim-mode assets
        whose metadata has never been edited yet).
        """
        records: dict[str, dict[str, Any]] = {}
        if self._engine is not None:
            with Session(self._engine) as session:
                for r in session.execute(select(Uav)).scalars().all():
                    records[r.id] = {
                        "id": r.id, "name": r.name, "domain": r.domain, "baseId": r.base_id,
                        **AssetMetadata(
                            affiliation=_cast_affiliation(r.affiliation),
                            platform_type=_cast_platform(r.platform_type),
                            callsign=r.callsign,
                            higher_formation=r.higher_formation,
                            echelon=_cast_echelon(r.echelon),
                        ).to_snapshot(),
                    }
        for asset_id, meta in self._cache.items():
            if asset_id not in records:
                records[asset_id] = {
                    "id": asset_id, "name": asset_id, "domain": None, "baseId": None,
                    **meta.to_snapshot(),
                }
        return list(records.values())

    def _load(self, asset_id: str) -> AssetMetadata | None:
        with Session(self._engine) as session:  # type: ignore[arg-type]
            row = session.get(Uav, asset_id)
            if row is None:
                return None
            return AssetMetadata(
                affiliation=_cast_affiliation(row.affiliation),
                platform_type=_cast_platform(row.platform_type),
                callsign=row.callsign,
                higher_formation=row.higher_formation,
                echelon=_cast_echelon(row.echelon),
            )


def _replace(meta: AssetMetadata, **fields: Any) -> AssetMetadata:
    return AssetMetadata(
        affiliation=_cast_affiliation(fields.get("affiliation", meta.affiliation)),
        platform_type=_cast_platform(fields.get("platform_type", meta.platform_type)),
        callsign=fields.get("callsign", meta.callsign),
        higher_formation=fields.get("higher_formation", meta.higher_formation),
        echelon=_cast_echelon(fields.get("echelon", meta.echelon)),
    )


def _cast_affiliation(value: str | None) -> Affiliation:
    return value if value in AFFILIATIONS else "FRIEND"  # type: ignore[return-value]


def _cast_platform(value: str | None) -> PlatformType:
    return value if value in PLATFORMS else "ROTARY_UAV"  # type: ignore[return-value]


def _cast_echelon(value: str | None) -> Echelon | None:
    return value if value in ECHELONS else None  # type: ignore[return-value]
