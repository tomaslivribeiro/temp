"""In-memory view of the no-fly zones, refreshed from the database every `ttl_s` seconds.

Read-through cache like `AssetRegistry`: zones change rarely (an import, not a tick) but the
fleet loop will want to test positions against them every second without touching the database.
The TTL also lets the API pick up an import done by a separate process.
"""

import threading
import time
from datetime import UTC, datetime

from c2.domain.geozones import (
    RESTRICTIONS,
    Geozone,
    GeozoneSource,
    is_active,
    route_entry,
    shape_bounds,
)
from c2.repositories.geozones import SqlAlchemyGeozoneRepository

BBox = tuple[float, float, float, float]  # west, south, east, north


class GeozoneRegistry:
    def __init__(self, repository: SqlAlchemyGeozoneRepository, ttl_s: float = 60.0) -> None:
        self._repository = repository
        self._ttl_s = ttl_s
        self._lock = threading.Lock()
        self._loaded_at: float | None = None
        self._zones: list[tuple[Geozone, BBox]] = []
        self._sources: dict[str, GeozoneSource] = {}

    def reload(self) -> None:
        zones = [(z, shape_bounds(z.shape)) for z in self._repository.list_zones()]
        sources = {s.id: s for s in self._repository.list_sources()}
        with self._lock:
            self._zones, self._sources = zones, sources
            self._loaded_at = time.monotonic()

    def _fresh(self) -> None:
        loaded_at = self._loaded_at
        if loaded_at is None or time.monotonic() - loaded_at > self._ttl_s:
            self.reload()

    def zones(self, at: datetime | None = None, bbox: BBox | None = None) -> list[Geozone]:
        """Zones active at `at` (default now), optionally overlapping `bbox`."""
        self._fresh()
        at = at or datetime.now(UTC)
        found = []
        for zone, (w, s, e, n) in self._zones:
            if not is_active(zone.valid_from, zone.valid_to, at):
                continue
            if bbox and (e < bbox[0] or w > bbox[2] or n < bbox[1] or s > bbox[3]):
                continue
            found.append(zone)
        return found

    def crossing(self, points: list[list[float]], at: datetime | None = None) -> list[Geozone]:
        """Restricted zones active at `at` that the route of `[lon, lat]` points passes over.

        Listed in the order the route reaches them; zones reached together, most severe first.
        """
        lons, lats = [p[0] for p in points], [p[1] for p in points]
        nearby = self.zones(at=at, bbox=(min(lons), min(lats), max(lons), max(lats)))
        crossed = [
            (entry, RESTRICTIONS.index(z.restriction), z)
            for z in nearby
            if z.restriction != "NO_RESTRICTION"
            and (entry := route_entry(z.shape, points)) is not None
        ]
        return [z for _, _, z in sorted(crossed, key=lambda found: found[:2])]

    def sources(self, ids: set[str] | None = None) -> list[GeozoneSource]:
        self._fresh()
        return [s for s in self._sources.values() if ids is None or s.id in ids]
