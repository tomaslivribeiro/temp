from typing import Any

from c2.ports.fleet import Command, FleetPort
from c2.services.asset_registry import AssetRegistry


class FleetService:
    """Application use cases for querying and commanding the active fleet."""

    def __init__(self, fleet: FleetPort, registry: AssetRegistry | None = None) -> None:
        self._fleet = fleet
        self._registry = registry

    def snapshot(self) -> dict[str, Any]:
        snap = self._fleet.snapshot()
        if self._registry is not None:
            for drone in snap["drones"]:
                meta = self._registry.get(drone["id"])
                drone.update(meta.to_snapshot())
        return snap

    def advance(self) -> dict[str, Any]:
        self._fleet.tick()
        return self.snapshot()

    def replace(self, fleet: FleetPort) -> None:
        """Swaps the active fleet source (runtime reconfiguration)."""
        self._fleet = fleet

    def send_command(
        self, uav_id: str, action: str, destination: dict[str, float] | None
    ) -> Command:
        return self._fleet.send(uav_id, action, destination)

    @property
    def registry(self) -> AssetRegistry | None:
        return self._registry
