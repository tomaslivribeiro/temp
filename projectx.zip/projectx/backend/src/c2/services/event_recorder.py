"""Ordered asynchronous persistence queue for fleet events."""

import asyncio
import logging
from typing import Any, Literal

from c2.ports.repositories import FleetEventRepository

log = logging.getLogger(__name__)

Job = tuple[Literal["save_event", "ensure_uav"], tuple[Any, ...]]


class QueuedFleetEventRecorder:
    def __init__(self, repository: FleetEventRepository) -> None:
        self._repository = repository
        self._queue: asyncio.Queue[Job] = asyncio.Queue()

    def record_event(
        self,
        mission_id: str,
        asset_id: str,
        kind: str,
        name: str,
        payload: dict[str, Any],
        occurred_at: float,
    ) -> None:
        self._queue.put_nowait(
            ("save_event", (mission_id, asset_id, kind, name, payload, occurred_at))
        )

    def register_asset(self, asset_id: str, asset_type: str, base_id: str | None) -> None:
        self._queue.put_nowait(("ensure_uav", (asset_id, asset_type, base_id)))

    async def run(self) -> None:
        while True:
            operation, args = await self._queue.get()
            try:
                method = getattr(self._repository, operation)
                await asyncio.to_thread(method, *args)
            except Exception:
                log.warning("could not persist fleet data", exc_info=True)
            finally:
                self._queue.task_done()