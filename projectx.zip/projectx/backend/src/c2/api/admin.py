import asyncio
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, field_validator

from c2.api import ws
from c2.api.dependencies import AdminRuntime, require_admin
from c2.runtime import DriverNotImplemented, RuntimeSettings, check_endpoints
from c2.services.asset_registry import AFFILIATIONS, ECHELONS, PLATFORMS

router = APIRouter(prefix="/admin", tags=["Admin"], dependencies=[Depends(require_admin)])

RESPONSES: dict[int | str, dict[str, Any]] = {
    401: {"description": "Missing or invalid X-Admin-Token."},
    503: {"description": "Admin API disabled (C2_ADMIN_TOKEN is not set)."},
}


class ZenohProbeIn(BaseModel):
    zenoh_connect: str = ""

    @field_validator("zenoh_connect")
    @classmethod
    def _endpoints(cls, value: str) -> str:
        return check_endpoints(value)


def _view(runtime: AdminRuntime, **extra: Any) -> dict[str, Any]:
    return {
        "settings": runtime.settings.model_dump(),
        "defaults": runtime.defaults.model_dump(),
        "origin": runtime.origin,
        "status": runtime.status(),
        **extra,
    }


async def _announce(runtime: AdminRuntime) -> None:
    await ws.manager.broadcast("hello", {"driver": runtime.settings.driver})


@router.get("/config", summary="Read runtime settings and connection status", responses=RESPONSES)
def get_config(runtime: AdminRuntime) -> dict[str, Any]:
    return _view(runtime)


@router.put(
    "/config",
    summary="Save runtime settings and apply them without restarting",
    description="Switching driver or Zenoh endpoints reconnects the fleet source; known assets are rediscovered.",
    responses=RESPONSES,
)
async def put_config(body: RuntimeSettings, runtime: AdminRuntime) -> dict[str, Any]:
    try:
        persisted = await runtime.apply(body)
    except DriverNotImplemented as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    await _announce(runtime)
    return _view(runtime, persisted=persisted)


@router.delete("/config", summary="Discard saved settings and go back to the environment", responses=RESPONSES)
async def delete_config(runtime: AdminRuntime) -> dict[str, Any]:
    persisted = await runtime.reset()
    await _announce(runtime)
    return _view(runtime, persisted=persisted)


@router.post("/config/test-zenoh", summary="Check that Zenoh endpoints are reachable", responses=RESPONSES)
async def test_zenoh(body: ZenohProbeIn) -> dict[str, Any]:
    from c2.drivers.zenoh.transport import probe

    try:
        peers = await asyncio.to_thread(probe, body.zenoh_connect)
    except Exception as exc:  # noqa: BLE001 - any zenoh failure is a test result, not a server error
        return {"ok": False, "peers": 0, "detail": f"could not open a Zenoh session: {exc}"}
    if peers:
        return {"ok": True, "peers": peers, "detail": f"reached {peers} Zenoh node(s)"}
    return {"ok": False, "peers": 0, "detail": "no Zenoh node answered within 4 s"}


class UavMetadataPatch(BaseModel):
    affiliation: str | None = Field(default=None, description="NATO standard identity.")
    platform_type: str | None = Field(default=None, description="APP-6 platform category.")
    callsign: str | None = Field(default=None, max_length=64)
    higher_formation: str | None = Field(default=None, max_length=64)
    echelon: str | None = Field(default=None)

    @field_validator("affiliation")
    @classmethod
    def _affiliation(cls, value: str | None) -> str | None:
        if value is not None and value not in AFFILIATIONS:
            raise ValueError(f"affiliation must be one of {AFFILIATIONS}")
        return value

    @field_validator("platform_type")
    @classmethod
    def _platform(cls, value: str | None) -> str | None:
        if value is not None and value not in PLATFORMS:
            raise ValueError(f"platform_type must be one of {PLATFORMS}")
        return value

    @field_validator("echelon")
    @classmethod
    def _echelon(cls, value: str | None) -> str | None:
        if value is not None and value != "" and value not in ECHELONS:
            raise ValueError(f"echelon must be one of {ECHELONS} or null")
        return value or None


@router.get(
    "/uavs",
    summary="List registered assets with their APP-6 metadata",
    responses=RESPONSES,
)
def list_uavs(runtime: AdminRuntime) -> dict[str, Any]:
    return {"uavs": runtime.registry.all()}


@router.patch(
    "/uavs/{asset_id}",
    summary="Update the APP-6 metadata of a registered asset",
    responses={**RESPONSES, 404: {"description": "Asset is not registered."}},
)
def patch_uav(asset_id: str, body: UavMetadataPatch, runtime: AdminRuntime) -> dict[str, Any]:
    updates = {k: v for k, v in body.model_dump(exclude_unset=True).items() if v is not None}
    try:
        meta = runtime.registry.upsert(asset_id, **updates)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"unknown asset {asset_id}") from exc
    return {"id": asset_id, **meta.to_snapshot()}
