from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query
from starlette.requests import HTTPConnection

from c2.api.schemas import (
    ErrorResponse,
    GeozoneCollection,
    GeozoneFeature,
    GeozoneProperties,
    GeozoneSourceOut,
    RouteCheckRequest,
    RouteCheckResponse,
)
from c2.domain.geozones import Geozone, GeozoneSource, to_geojson_geometry
from c2.services.geozone_registry import GeozoneRegistry

router = APIRouter()


def get_geozones(connection: HTTPConnection) -> GeozoneRegistry:
    return connection.app.state.geozones


def _iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return (value if value.tzinfo else value.replace(tzinfo=UTC)).astimezone(UTC).isoformat()


def _properties(zone: Geozone) -> GeozoneProperties:
    return GeozoneProperties(
        id=zone.id, external_id=zone.external_id, source_id=zone.source_id, name=zone.name,
        restriction=zone.restriction, reason=zone.reason, message=zone.message,
        lower_m=zone.lower_m, upper_m=zone.upper_m,
        lower_ref=zone.lower_ref, upper_ref=zone.upper_ref,
        valid_from=_iso(zone.valid_from), valid_to=_iso(zone.valid_to),
        shape_type=zone.shape["type"],
    )  # fmt: skip


def _feature(zone: Geozone) -> GeozoneFeature:
    return GeozoneFeature(
        id=zone.id, geometry=to_geojson_geometry(zone.shape), properties=_properties(zone)
    )


def _source(source: GeozoneSource) -> GeozoneSourceOut:
    return GeozoneSourceOut(
        id=source.id, name=source.name, url=source.url, attribution=source.attribution,
        license_note=source.license_note, dataset_version=source.dataset_version,
        retrieved_at=_iso(source.retrieved_at),
    )  # fmt: skip


def _parse_bbox(bbox: str | None) -> tuple[float, float, float, float] | None:
    if bbox is None:
        return None
    try:
        west, south, east, north = (float(v) for v in bbox.split(","))
    except ValueError:
        raise HTTPException(status_code=422, detail="bbox must be west,south,east,north") from None
    return west, south, east, north


@router.get(
    "/geozones",
    response_model=GeozoneCollection,
    tags=["Geozones"],
    summary="List no-fly zones",
    description=(
        "Zones active at `at` (default: now) as a GeoJSON FeatureCollection of polygons, plus the "
        "sources they come from. Circles are returned as polygons for drawing. Decision support "
        "only: it does not replace the official source."
    ),
    responses={
        422: {"model": ErrorResponse, "description": "Malformed `bbox`."},
        503: {"model": ErrorResponse, "description": "The database is unavailable."},
    },
)
def list_geozones(
    registry: Annotated[GeozoneRegistry, Depends(get_geozones)],
    at: Annotated[datetime | None, Query(description="ISO 8601 instant; default now.")] = None,
    bbox: Annotated[
        str | None, Query(description="Only zones overlapping west,south,east,north.")
    ] = None,
) -> GeozoneCollection:
    box = _parse_bbox(bbox)
    try:
        zones = registry.zones(at=at, bbox=box)
        sources = registry.sources({z.source_id for z in zones})
    except Exception as exc:
        raise HTTPException(status_code=503, detail="geozones unavailable") from exc
    return GeozoneCollection(features=[_feature(z) for z in zones], sources=[_source(s) for s in sources])


@router.post(
    "/geozones/route-check",
    response_model=RouteCheckResponse,
    tags=["Geozones"],
    summary="Check a route against the no-fly zones",
    description=(
        "Restricted zones (everything but `NO_RESTRICTION`) active now that the route passes over "
        "or touches. The check is two-dimensional: altitude limits are returned but not applied. "
        "It does not block any command."
    ),
    responses={503: {"model": ErrorResponse, "description": "The database is unavailable."}},
)
def check_route(
    route: RouteCheckRequest,
    registry: Annotated[GeozoneRegistry, Depends(get_geozones)],
) -> RouteCheckResponse:
    try:
        zones = registry.crossing([[p.lon, p.lat] for p in route.points])
    except Exception as exc:
        raise HTTPException(status_code=503, detail="geozones unavailable") from exc
    return RouteCheckResponse(zones=[_properties(z) for z in zones])
