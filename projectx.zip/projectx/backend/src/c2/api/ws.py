import json
from datetime import UTC, datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect

from c2.api.dependencies import get_fleet_service
from c2.config import settings
from c2.services.fleet import FleetService

router = APIRouter()


def envelope(type_: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Every WebSocket message has the same shape: {type, payload, ts}."""
    return {"type": type_, "payload": payload or {}, "ts": datetime.now(UTC).isoformat()}


class ConnectionManager:
    def __init__(self) -> None:
        self._clients: set[WebSocket] = set()

    @property
    def count(self) -> int:
        return len(self._clients)

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        self._clients.add(ws)

    def disconnect(self, ws: WebSocket) -> None:
        self._clients.discard(ws)

    async def broadcast(self, type_: str, payload: dict[str, Any] | None = None) -> None:
        message = envelope(type_, payload)
        for ws in list(self._clients):
            try:
                await ws.send_json(message)
            except (RuntimeError, WebSocketDisconnect):
                self.disconnect(ws)


manager = ConnectionManager()


def origin_allowed(origin: str | None) -> bool:
    # Browsers do not apply CORS to WebSockets, so the Origin is checked here.
    if origin is None:
        return True
    return origin in {o.strip() for o in settings.c2_cors_origins.split(",") if o.strip()}


@router.websocket("/ws")
async def ws_endpoint(
    ws: WebSocket,
    service: Annotated[FleetService, Depends(get_fleet_service)],
) -> None:
    if not origin_allowed(ws.headers.get("origin")):
        await ws.close(code=1008)
        return
    await manager.connect(ws)
    await ws.send_json(envelope("hello", {"driver": ws.app.state.runtime.settings.driver}))
    await ws.send_json(envelope("fleet.snapshot", service.snapshot()))
    try:
        while True:
            try:
                msg = json.loads(await ws.receive_text())
            except json.JSONDecodeError:
                await ws.send_json(envelope("error", {"detail": "invalid JSON"}))
                continue
            if isinstance(msg, dict) and msg.get("type") == "ping":
                await ws.send_json(envelope("pong"))
    except WebSocketDisconnect:
        pass
    finally:
        manager.disconnect(ws)
