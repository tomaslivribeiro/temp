import secrets
from typing import Annotated

from fastapi import Depends, Header, HTTPException
from starlette.requests import HTTPConnection

from c2 import config
from c2.runtime import Runtime
from c2.services.fleet import FleetService


def get_fleet_service(connection: HTTPConnection) -> FleetService:
    return connection.app.state.runtime.service


def get_runtime(connection: HTTPConnection) -> Runtime:
    return connection.app.state.runtime


def require_admin(x_admin_token: Annotated[str | None, Header()] = None) -> None:
    expected = config.settings.c2_admin_token
    if not expected:
        raise HTTPException(status_code=503, detail="admin API disabled: set C2_ADMIN_TOKEN")
    if not x_admin_token or not secrets.compare_digest(x_admin_token, expected):
        raise HTTPException(status_code=401, detail="invalid admin token")


AdminRuntime = Annotated[Runtime, Depends(get_runtime)]