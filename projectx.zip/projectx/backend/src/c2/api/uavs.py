from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field

from c2.api.dependencies import get_fleet_service
from c2.api.schemas import CommandAcceptedResponse, ErrorResponse
from c2.domain.errors import (
    CommandNotAllowed,
    CommandNotImplemented,
    DestinationRequired,
    FleetError,
    FleetUnavailable,
    UavNotFound,
)
from c2.services.fleet import FleetService

router = APIRouter()


class LonLatIn(BaseModel):
    model_config = ConfigDict(json_schema_extra={"examples": [{"lon": -9.14, "lat": 38.72}]})

    lon: float = Field(description="Longitude in decimal degrees, WGS 84.")
    lat: float = Field(description="Latitude in decimal degrees, WGS 84.")


class CommandIn(BaseModel):
    action: Literal["poweron", "takeoff", "goto", "changeb", "hold", "rtb", "land", "poweroff"] = Field(
        description="Requested UAV action. Availability depends on the UAV state and active driver.",
        examples=["goto"],
    )
    b: LonLatIn | None = Field(
        default=None,
        description="Destination point. Required for changeb; retained as a single-point goto fallback.",
    )
    # Ordered goto destinations are kept separate from the legacy single `b` field.
    waypoints: list[LonLatIn] | None = Field(
        default=None,
        description="Ordered route destinations for goto. The UAV starts at its current position.",
    )


ERROR_STATUS = {
    UavNotFound: 404,
    CommandNotAllowed: 409,
    CommandNotImplemented: 501,
    DestinationRequired: 422,
    FleetUnavailable: 503,
}


@router.post(
    "/uavs/{uav_id}/commands",
    status_code=202,
    response_model=CommandAcceptedResponse,
    tags=["UAV commands"],
    summary="Send a command to a UAV",
    description=(
        "Accepts a command for a known UAV. This response acknowledges submission, not completion. "
        "Command progress and final status are published through the `/ws` WebSocket as "
        "`fleet.snapshot` messages."
    ),
    responses={
        404: {"model": ErrorResponse, "description": "The UAV identifier is unknown."},
        409: {"model": ErrorResponse, "description": "The command is not valid in the UAV's current state."},
        422: {"model": ErrorResponse, "description": "The request is invalid or a destination is required."},
        501: {"model": ErrorResponse, "description": "The active driver does not implement this command."},
        503: {"model": ErrorResponse, "description": "The active fleet transport is unavailable."},
    },
)
async def send_command(
    uav_id: str,
    body: CommandIn,
    service: Annotated[FleetService, Depends(get_fleet_service)],
) -> CommandAcceptedResponse:
    try:
        command = service.send_command(
            uav_id,
            body.action,
            body.b.model_dump() if body.b else None,
            [point.model_dump() for point in body.waypoints] if body.waypoints else None,
        )
    except FleetError as exc:
        raise HTTPException(
            status_code=ERROR_STATUS[type(exc)], detail=str(exc)
        ) from exc
    return CommandAcceptedResponse(key=command["key"])
