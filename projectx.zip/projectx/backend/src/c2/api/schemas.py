from typing import Literal

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: Literal["ok"] = Field(description="Indicates that the API process is responding.")


class VersionResponse(BaseModel):
    version: str = Field(description="Backend API version.", examples=["0.1.0"])
    driver: Literal["sim", "zenoh", "nato"] = Field(
        description="Active fleet source. NATO is reserved and is not currently implemented."
    )


class DatabaseVersionResponse(BaseModel):
    revision: str | None = Field(
        description="Alembic revision applied to the database; null means migrations have not run.",
        examples=["0002"],
    )


class ErrorResponse(BaseModel):
    detail: str = Field(description="Human-readable error detail.")


class CommandAcceptedResponse(BaseModel):
    key: int = Field(description="Identifier of the accepted command in the current fleet session.")

class GeozoneSourceOut(BaseModel):
    id: str = Field(description="Source slug.", examples=["anac"])
    name: str
    url: str | None = None
    attribution: str = Field(description="Credit line to show next to the zones.")
    license_note: str | None = Field(
        default=None, description="Licence or terms-of-use note recorded for this source."
    )
    dataset_version: str | None = None
    retrieved_at: str | None = Field(default=None, description="ISO 8601 UTC.")


class GeozoneProperties(BaseModel):
    id: int
    external_id: str = Field(description="Identifier of the zone in its source.")
    source_id: str
    name: str
    restriction: Literal["PROHIBITED", "REQUIRES_AUTHORISATION", "CONDITIONAL", "NO_RESTRICTION"]
    reason: str | None = None
    message: str | None = None
    lower_m: float | None = None
    upper_m: float | None = None
    lower_ref: Literal["AGL", "AMSL"] | None = None
    upper_ref: Literal["AGL", "AMSL"] | None = None
    valid_from: str | None = Field(default=None, description="ISO 8601 UTC; null = no start.")
    valid_to: str | None = Field(default=None, description="ISO 8601 UTC; null = no end.")
    shape_type: Literal["circle", "rectangle", "polygon", "multipolygon"]


class GeozoneFeature(BaseModel):
    type: Literal["Feature"] = "Feature"
    id: int
    geometry: dict = Field(description="GeoJSON Polygon or MultiPolygon, WGS 84 [lon, lat].")
    properties: GeozoneProperties


class RoutePoint(BaseModel):
    lon: float = Field(ge=-180, le=180, description="Longitude in decimal degrees, WGS 84.")
    lat: float = Field(ge=-90, le=90, description="Latitude in decimal degrees, WGS 84.")


class RouteCheckRequest(BaseModel):
    points: list[RoutePoint] = Field(
        min_length=2,
        description="Route to check, in order, starting at the UAV's current position.",
        examples=[[{"lon": -9.2, "lat": 38.77}, {"lon": -9.1, "lat": 38.77}]],
    )


class RouteCheckResponse(BaseModel):
    zones: list[GeozoneProperties] = Field(
        description=(
            "Restricted zones the route passes over, in the order it reaches them; "
            "empty when it crosses none."
        )
    )


class GeozoneCollection(BaseModel):
    type: Literal["FeatureCollection"] = "FeatureCollection"
    features: list[GeozoneFeature]
    sources: list[GeozoneSourceOut] = Field(description="Sources of the zones returned.")
