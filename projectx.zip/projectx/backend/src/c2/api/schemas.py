from typing import Literal

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: Literal["ok"] = Field(description="Indicates that the API process is responding.")


class VersionResponse(BaseModel):
    version: str = Field(description="Backend API version.", examples=["0.1.0"])
    driver: Literal["sim", "zenoh", "nato"] = Field(
        description="Active fleet source. NATO is reserved and is not currently implemented."
    )


class DatabaseVersionResponse(BaseModel):
    revision: str | None = Field(
        description="Alembic revision applied to the database; null means migrations have not run.",
        examples=["0002"],
    )


class ErrorResponse(BaseModel):
    detail: str = Field(description="Human-readable error detail.")


class CommandAcceptedResponse(BaseModel):
    key: int = Field(description="Identifier of the accepted command in the current fleet session.")