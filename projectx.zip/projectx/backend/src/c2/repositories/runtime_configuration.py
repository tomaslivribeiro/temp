from typing import Any

from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from c2.models import RuntimeConfiguration


class SqlAlchemyRuntimeConfigurationRepository:
    """Stores the active driver and the settings saved from the UI as a singleton row."""

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    def _row(self, session: Session, driver: str) -> RuntimeConfiguration:
        configuration = session.get(RuntimeConfiguration, 1)
        if configuration is None:
            configuration = RuntimeConfiguration(id=1, active_driver=driver)
            session.add(configuration)
        return configuration

    def save_active_driver(self, driver: str) -> None:
        with Session(self._engine) as session:
            self._row(session, driver).active_driver = driver
            session.commit()

    def load_settings(self) -> dict[str, Any] | None:
        with Session(self._engine) as session:
            configuration = session.get(RuntimeConfiguration, 1)
            return configuration.settings if configuration else None

    def save_settings(self, settings: dict[str, Any]) -> None:
        with Session(self._engine) as session:
            configuration = self._row(session, settings["driver"])
            configuration.active_driver = settings["driver"]
            configuration.settings = settings
            session.commit()

    def clear_settings(self) -> None:
        with Session(self._engine) as session:
            configuration = session.get(RuntimeConfiguration, 1)
            if configuration is not None:
                configuration.settings = None
                session.commit()
