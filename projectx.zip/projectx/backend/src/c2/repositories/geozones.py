from collections.abc import Collection
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from c2.domain.geozones import RESTRICTIONS, Geozone, GeozoneSource, validate_shape
from c2.models import GeozoneSource as GeozoneSourceRow
from c2.models import NoFlyZone

_ZONE_FIELDS = (
    "name", "restriction", "reason", "message", "lower_m", "upper_m",
    "lower_ref", "upper_ref", "valid_from", "valid_to",
)  # fmt: skip


def _to_source(row: GeozoneSourceRow) -> GeozoneSource:
    return GeozoneSource(
        id=row.id, name=row.name, url=row.url, attribution=row.attribution,
        license_note=row.license_note, dataset_version=row.dataset_version,
        retrieved_at=row.retrieved_at,
    )  # fmt: skip


def _to_zone(row: NoFlyZone) -> Geozone:
    return Geozone(
        id=row.id, source_id=row.source_id, external_id=row.external_id, name=row.name,
        restriction=row.restriction, reason=row.reason, message=row.message, shape=row.shape,
        lower_m=row.lower_m, upper_m=row.upper_m, lower_ref=row.lower_ref, upper_ref=row.upper_ref,
        valid_from=row.valid_from, valid_to=row.valid_to, properties=row.properties or {},
    )  # fmt: skip


class SqlAlchemyGeozoneRepository:
    """Zones and their sources. Knows nothing about any particular source: adapters feed it."""

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    def upsert_source(
        self,
        source_id: str,
        *,
        name: str,
        attribution: str,
        url: str | None = None,
        license_note: str | None = None,
        dataset_version: str | None = None,
        retrieved_at: datetime | None = None,
    ) -> None:
        with Session(self._engine) as session:
            row = session.get(GeozoneSourceRow, source_id)
            if row is None:
                row = GeozoneSourceRow(id=source_id, name=name, attribution=attribution)
                session.add(row)
            row.name = name
            row.attribution = attribution
            row.url = url
            row.license_note = license_note
            row.dataset_version = dataset_version
            row.retrieved_at = retrieved_at or datetime.now(UTC)
            session.commit()

    def upsert_zones(self, source_id: str, zones: list[dict[str, Any]]) -> int:
        """Inserts or updates zones by (source_id, external_id). All or nothing."""
        self._write(source_id, zones, keep=None)
        return len(zones)

    def replace_zones(
        self, source_id: str, zones: list[dict[str, Any]], keep: Collection[str] = ()
    ) -> int:
        """Makes `zones` the full content of a source: upserts them and deletes the rest.

        `keep` lists external ids that are still published by the source but could not be
        loaded; their stored version stays. Other sources are untouched. An empty `zones` is
        refused so a broken download cannot wipe the map. All or nothing; returns the number
        of zones removed.
        """
        if not zones:
            raise ValueError(f"refusing to replace source {source_id!r} with no zones")
        return self._write(source_id, zones, keep=set(keep))

    def _write(self, source_id: str, zones: list[dict[str, Any]], keep: set[str] | None) -> int:
        """Upserts `zones`; unless `keep` is None, also deletes the zones in neither."""
        prepared = []
        for zone in zones:
            restriction = zone["restriction"]
            if restriction not in RESTRICTIONS:
                raise ValueError(f"unknown restriction: {restriction!r}")
            prepared.append({**zone, "shape": validate_shape(zone["shape"])})
        with Session(self._engine) as session:
            existing = {
                r.external_id: r
                for r in session.execute(
                    select(NoFlyZone).where(NoFlyZone.source_id == source_id)
                ).scalars()
            }
            for zone in prepared:
                row = existing.get(zone["external_id"])
                if row is None:
                    row = NoFlyZone(source_id=source_id, external_id=zone["external_id"])
                    session.add(row)
                    existing[zone["external_id"]] = row
                row.shape = zone["shape"]
                row.properties = zone.get("properties") or {}
                for field in _ZONE_FIELDS:
                    setattr(row, field, zone.get(field))
            removed = 0
            if keep is not None:
                present = keep | {zone["external_id"] for zone in prepared}
                for external_id, row in existing.items():
                    if external_id not in present:
                        session.delete(row)
                        removed += 1
            session.commit()
        return removed

    def list_zones(self) -> list[Geozone]:
        with Session(self._engine) as session:
            rows = session.execute(select(NoFlyZone).order_by(NoFlyZone.id)).scalars().all()
            return [_to_zone(r) for r in rows]

    def list_sources(self) -> list[GeozoneSource]:
        with Session(self._engine) as session:
            rows = session.execute(select(GeozoneSourceRow).order_by(GeozoneSourceRow.id)).scalars()
            return [_to_source(r) for r in rows]
