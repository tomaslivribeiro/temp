from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as postgresql_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.engine import Engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from c2.models import MissionEvent, Uav
from c2.ports.repositories import FleetEventRepository

DOMAINS = {"UAV": "air", "UGV": "ground", "USV": "water", "DIGITAL_TWIN": "air"}
# Default NATO APP-6 platform category seeded on first sighting; the operator can later override it
# through the admin API without touching the driver.
PLATFORMS = {"UAV": "ROTARY_UAV", "UGV": "WHEELED_UGV", "USV": "USV", "DIGITAL_TWIN": "ROTARY_UAV"}


class SqlAlchemyFleetEventRepository(FleetEventRepository):
    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    def save_event(
        self,
        mission_id: str,
        asset_id: str,
        kind: str,
        name: str,
        payload: dict,
        occurred_at: float,
    ) -> bool:
        values = {
            "mission_id": mission_id,
            "asset_id": asset_id,
            "kind": kind,
            "name": name,
            "payload": payload,
            "occurred_at": datetime.fromtimestamp(occurred_at, UTC),
        }
        with Session(self._engine) as session:
            unique_key = [
                MissionEvent.mission_id,
                MissionEvent.asset_id,
                MissionEvent.kind,
                MissionEvent.name,
            ]
            # Status messages may be redelivered; ignore duplicates at the database constraint.
            if self._engine.dialect.name == "postgresql":
                statement = postgresql_insert(MissionEvent).values(**values).on_conflict_do_nothing(
                    index_elements=unique_key
                )
                result = session.execute(statement)
                session.commit()
                return result.rowcount > 0
            if self._engine.dialect.name == "sqlite":
                statement = sqlite_insert(MissionEvent).values(**values).on_conflict_do_nothing(
                    index_elements=unique_key
                )
                result = session.execute(statement)
                session.commit()
                return result.rowcount > 0

            row = MissionEvent(**values)
            session.add(row)
            try:
                session.commit()
            except IntegrityError:
                session.rollback()
                return False
        return True

    def ensure_uav(self, asset_id: str, asset_type: str, base_id: str | None) -> bool:
        with Session(self._engine) as session:
            if session.execute(select(Uav.id).where(Uav.id == asset_id)).first():
                return False
            session.add(
                Uav(
                    id=asset_id,
                    name=asset_id,
                    domain=DOMAINS.get(asset_type, "air"),
                    base_id=base_id,
                    affiliation="FRIEND",
                    platform_type=PLATFORMS.get(asset_type, "ROTARY_UAV"),
                )
            )
            try:
                session.commit()
            except IntegrityError:
                session.rollback()
                return False
        return True