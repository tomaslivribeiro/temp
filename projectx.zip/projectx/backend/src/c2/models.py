from datetime import datetime

from sqlalchemy import JSON, CheckConstraint, DateTime, Integer, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column

from c2.db import Base


class MissionEvent(Base):
    """Append-only log of commands sent to assets and the statuses they answered with.

    One row per (mission, asset, kind, name): a repeated status (e.g. IN_PROGRESS) is not new.
    """

    __tablename__ = "mission_event"
    __table_args__ = (UniqueConstraint("mission_id", "asset_id", "kind", "name"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    mission_id: Mapped[str] = mapped_column(String(64), index=True)
    asset_id: Mapped[str] = mapped_column(String(64), index=True)
    kind: Mapped[str] = mapped_column(String(16))  # command | status
    name: Mapped[str] = mapped_column(String(32))  # MOVE, RETURN_HOME... | RECEIVED, COMPLETED...
    payload: Mapped[dict] = mapped_column(JSON)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Uav(Base):
    __tablename__ = "uav"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    domain: Mapped[str] = mapped_column(String(16))  # air | ground | water
    base_id: Mapped[str | None] = mapped_column(String(32))
    # NATO APP-6 standard identity. Always FRIEND for assets the C2 commands; left extensible for
    # external tracks (hostile/neutral/unknown) when they are introduced.
    affiliation: Mapped[str] = mapped_column(String(16), nullable=False, server_default="FRIEND")
    # Specific platform category for symbology (rotary vs fixed-wing UAV, tracked vs wheeled UGV).
    platform_type: Mapped[str | None] = mapped_column(String(32), nullable=True)
    # Operational designation; falls back to `id` when empty.
    callsign: Mapped[str | None] = mapped_column(String(64), nullable=True)
    higher_formation: Mapped[str | None] = mapped_column(String(64), nullable=True)
    echelon: Mapped[str | None] = mapped_column(String(16), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class RuntimeConfiguration(Base):
    """Latest backend runtime selection persisted for operations and diagnostics."""

    __tablename__ = "runtime_configuration"
    __table_args__ = (CheckConstraint("id = 1", name="ck_runtime_configuration_singleton"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    active_driver: Mapped[str] = mapped_column(String(16), nullable=False)
    # Settings saved from the configuration screen; they override the environment at startup.
    settings: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )
