from datetime import datetime

from sqlalchemy import (
    JSON,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from c2.db import Base


class MissionEvent(Base):
    """Append-only log of commands sent to assets and the statuses they answered with.

    One row per (mission, asset, kind, name): a repeated status (e.g. IN_PROGRESS) is not new.
    """

    __tablename__ = "mission_event"
    __table_args__ = (UniqueConstraint("mission_id", "asset_id", "kind", "name"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    mission_id: Mapped[str] = mapped_column(String(64), index=True)
    asset_id: Mapped[str] = mapped_column(String(64), index=True)
    kind: Mapped[str] = mapped_column(String(16))  # command | status
    name: Mapped[str] = mapped_column(String(32))  # MOVE, RETURN_HOME... | RECEIVED, COMPLETED...
    payload: Mapped[dict] = mapped_column(JSON)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Uav(Base):
    __tablename__ = "uav"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    domain: Mapped[str] = mapped_column(String(16))  # air | ground | water
    base_id: Mapped[str | None] = mapped_column(String(32))
    # NATO APP-6 standard identity. Always FRIEND for assets the C2 commands; left extensible for
    # external tracks (hostile/neutral/unknown) when they are introduced.
    affiliation: Mapped[str] = mapped_column(String(16), nullable=False, server_default="FRIEND")
    # Specific platform category for symbology (rotary vs fixed-wing UAV, tracked vs wheeled UGV).
    platform_type: Mapped[str | None] = mapped_column(String(32), nullable=True)
    # Operational designation; falls back to `id` when empty.
    callsign: Mapped[str | None] = mapped_column(String(64), nullable=True)
    higher_formation: Mapped[str | None] = mapped_column(String(64), nullable=True)
    echelon: Mapped[str | None] = mapped_column(String(16), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class RuntimeConfiguration(Base):
    """Latest backend runtime selection persisted for operations and diagnostics."""

    __tablename__ = "runtime_configuration"
    __table_args__ = (CheckConstraint("id = 1", name="ck_runtime_configuration_singleton"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    active_driver: Mapped[str] = mapped_column(String(16), nullable=False)
    # Settings saved from the configuration screen; they override the environment at startup.
    settings: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )


class GeozoneSource(Base):
    """Where a set of no-fly zones came from: attribution and licence note shown to operators."""

    __tablename__ = "geozone_source"

    id: Mapped[str] = mapped_column(String(32), primary_key=True)  # slug, e.g. "anac"
    name: Mapped[str] = mapped_column(String(128))
    url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    attribution: Mapped[str] = mapped_column(String(256))
    license_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    dataset_version: Mapped[str | None] = mapped_column(String(128), nullable=True)
    retrieved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


class NoFlyZone(Base):
    """A restricted airspace volume, independent of the source it was loaded from.

    `shape` keeps the original geometry (see c2.domain.geozones) so tests stay exact. Altitude
    limits are optional and carry their own reference (AGL/AMSL). No validity window = permanent.
    """

    __tablename__ = "no_fly_zone"
    __table_args__ = (UniqueConstraint("source_id", "external_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source_id: Mapped[str] = mapped_column(ForeignKey("geozone_source.id"), index=True)
    external_id: Mapped[str] = mapped_column(String(128))
    name: Mapped[str] = mapped_column(String(256))
    restriction: Mapped[str] = mapped_column(String(32))
    reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    message: Mapped[str | None] = mapped_column(Text, nullable=True)
    shape: Mapped[dict] = mapped_column(JSON)
    lower_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    upper_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    lower_ref: Mapped[str | None] = mapped_column(String(4), nullable=True)
    upper_ref: Mapped[str | None] = mapped_column(String(4), nullable=True)
    valid_from: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    valid_to: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    properties: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
