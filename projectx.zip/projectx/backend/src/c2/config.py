from typing import Any, Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="", extra="ignore")

    c2_env: str = "dev"
    # Selects the fleet source at startup. Left empty, it is `zenoh` when ZENOH_CONNECT is set and `sim` otherwise.
    # NATO remains reserved until its adapter exists.
    c2_driver: Literal["sim", "zenoh", "nato"] = "sim"
    c2_cors_origins: str = "http://localhost:5173"
    ws_heartbeat_seconds: float = 5.0
    c2_operator_id: str = "operator-01"
    c2_default_speed_mps: float = 15.0
    database_url: str = "postgresql+psycopg://c2:c2@localhost:5432/c2"
    zenoh_connect: str = ""  # comma-separated endpoints, e.g. tcp/xverse-mock:7447
    c2_lost_after_s: int = 10
    # geo: assets send real lat/lon. carla: assets send CARLA local metres (latitude_deg = X, longitude_deg = Y).
    c2_position_format: Literal["geo", "carla"] = "geo"
    # Protects /admin/*. Empty disables the admin API.
    c2_admin_token: str = ""
    # Simulator only (driver `sim`): wind drift and random avoidance manoeuvres, so the map shows a real route
    # that differs from the planned one. The wind is capped at half the cruise speed so every flight arrives.
    c2_sim_deviations: bool = True
    c2_sim_wind_km_per_tick: float = Field(0.35, ge=0, le=0.75, allow_inf_nan=False)
    c2_sim_wind_from_deg: float = Field(300.0, ge=0, lt=360, allow_inf_nan=False)

    @model_validator(mode="before")
    @classmethod
    def _infer_driver(cls, data: Any) -> Any:
        if isinstance(data, dict) and not data.get("c2_driver"):
            has_endpoint = bool(str(data.get("zenoh_connect") or "").strip())
            data = {**data, "c2_driver": "zenoh" if has_endpoint else "sim"}
        return data


settings = Settings()
