"""C2 <-> Asset Interface Control Document (ICD): Zenoh topics and mappings to the UI model.

Signals are transport independent; for the PoC each one maps to a Zenoh topic. Asset ids travel in
the payload, never in the topic.
"""

import math

from c2.drivers.sim import BASES, km

# C2 publishes
TOPIC_COMMAND = "c2/mission/command"
TOPIC_CANCEL = "c2/mission/cancel"
# Assets publish
TOPIC_STATUS = "mission/status"
TOPIC_TELEMETRY = "asset/telemetry"
TOPIC_HEALTH = "asset/health"
TOPIC_HEARTBEAT = "system/heartbeat"

SUBSCRIBE = [TOPIC_STATUS, TOPIC_TELEMETRY, TOPIC_HEALTH, TOPIC_HEARTBEAT]

# UI action -> ICD command. takeoff/poweron have no signal in the ICD yet.
ACTION_TO_COMMAND = {
    "goto": "MOVE",
    "changeb": "MOVE",
    "hold": "HOLD_POSITION",
    "rtb": "RETURN_HOME",
    "land": "LAND",
    "poweroff": "SHUTDOWN",
}

# ICD current_state -> UI state code (O off, S standby, T taking off, H hover, M mission,
# R returning, L landing, G grounded/fault).
_STATE = {
    "OFFLINE": "O",
    "INITIALIZING": "S",
    "READY": "S",
    "PARKED": "S",
    "MOVING": "M",
    "RETURNING_HOME": "R",
    "HOLDING": "H",
    "HOVERING": "H",
    "LOITERING": "H",
    "MISSION_COMPLETE": "H",
    "LANDING": "L",
    "EMERGENCY": "G",
    "FAULT": "G",
}


def ui_state(current_state: str, navigation_mode: str | None) -> str:
    if current_state == "MOVING" and navigation_mode == "RETURN_HOME":
        return "R"
    return _STATE.get(current_state, "H")


def nearest_base(lon: float, lat: float) -> str:
    """The UI knows a fixed set of bases; the ICD carries no home position yet."""
    here = {"lon": lon, "lat": lat}
    return min(BASES, key=lambda name: km(here, BASES[name]))


# CARLA sends its local metres (X east, Y south) in latitude_deg / longitude_deg. The X-Verse floorplan of
# the UI is placed in Web Mercator around (0, 0), so a local point is a lon/lat very close to the origin.
EARTH_RADIUS_M = 6378137.0


def carla_to_lonlat(x: float, y: float) -> tuple[float, float]:
    return math.degrees(x / EARTH_RADIUS_M), math.degrees(math.atan(math.sinh(-y / EARTH_RADIUS_M)))


def lonlat_to_carla(lon: float, lat: float) -> tuple[float, float]:
    return math.radians(lon) * EARTH_RADIUS_M, -math.asinh(math.tan(math.radians(lat))) * EARTH_RADIUS_M
