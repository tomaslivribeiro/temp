"""Zenoh session: connects (with retry), subscribes to the asset topics, publishes C2 signals."""

import asyncio
import json
import logging
import time
from collections.abc import Callable
from typing import Any

import zenoh

from c2.drivers.zenoh import icd

log = logging.getLogger(__name__)
RETRY_SECONDS = 3


class ZenohTransport:
    def __init__(self, connect: str = "") -> None:
        self._connect = [e.strip() for e in connect.split(",") if e.strip()]
        self._session: zenoh.Session | None = None

    @property
    def connected(self) -> bool:
        return self._session is not None

    def peers(self) -> int:
        """Remote Zenoh nodes currently linked to this session (the session can be open with none)."""
        if self._session is None:
            return 0
        info = self._session.info
        return len(info.routers_zid()) + len(info.peers_zid())

    def _open(self) -> zenoh.Session:
        return zenoh.open(_config(self._connect))

    async def run(self, on_message: Callable[[str, bytes], None]) -> None:
        """Opens the session and keeps it until cancelled. Never blocks the event loop."""
        loop = asyncio.get_running_loop()
        while self._session is None:
            try:
                self._session = await asyncio.to_thread(self._open)
            except Exception:  # the router may simply not be up yet
                log.warning("zenoh unavailable, retrying in %ss", RETRY_SECONDS, exc_info=True)
                await asyncio.sleep(RETRY_SECONDS)

        def deliver(sample: zenoh.Sample) -> None:
            # Zenoh calls back on its own thread; hand over to the event loop.
            loop.call_soon_threadsafe(on_message, str(sample.key_expr), sample.payload.to_bytes())

        subs = [self._session.declare_subscriber(t, deliver) for t in icd.SUBSCRIBE]
        log.info("zenoh connected, subscribed to %s", ", ".join(icd.SUBSCRIBE))
        try:
            await asyncio.Event().wait()
        finally:
            for s in subs:
                s.undeclare()
            self._session.close()
            self._session = None

    def publish(self, topic: str, payload: dict[str, Any]) -> None:
        if self._session is None:
            raise RuntimeError("zenoh session not open")
        self._session.put(topic, json.dumps(payload).encode())


def _config(endpoints: list[str]) -> zenoh.Config:
    conf = zenoh.Config()
    if endpoints:
        conf.insert_json5("connect/endpoints", json.dumps(endpoints))
        # Explicit endpoints mean exactly those nodes: no multicast discovery of anything else.
        conf.insert_json5("scouting/multicast/enabled", "false")
    return conf


def probe(connect: str, timeout_s: float = 4.0) -> int:
    """Opens a throwaway session and returns how many remote nodes it reached within the timeout."""
    session = zenoh.open(_config([e.strip() for e in connect.split(",") if e.strip()]))
    try:
        deadline = time.monotonic() + timeout_s
        while True:
            info = session.info
            peers = len(info.routers_zid()) + len(info.peers_zid())
            if peers or time.monotonic() >= deadline:
                return peers
            time.sleep(0.25)
    finally:
        session.close()
