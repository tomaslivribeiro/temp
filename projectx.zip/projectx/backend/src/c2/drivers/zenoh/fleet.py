"""Fleet source fed by Zenoh messages (X-Verse mock today, real assets later).

Pure state machine: messages come in through `on_message`, commands go out through `publish`, and
persistence jobs go through `record`. The Zenoh session itself lives in transport.py.
"""

import json
import logging
import time
import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from c2.domain.actual_route import ActualRoute
from c2.domain.commands import KEEP_COMMANDS, MIN_MISSION_BATTERY, validate_command
from c2.domain.errors import (
    CommandNotImplemented,
    FleetUnavailable,
    UavNotFound,
)
from c2.drivers.zenoh import icd
from c2.ports.events import FleetEventRecorderPort
from c2.ports.fleet import Command

log = logging.getLogger(__name__)

TRAIL_MAX = 150
DEFAULT_SPEED_MPS = 15.0
LOST_AFTER_S = 10
# ICD mission_status -> command stage (Sent 0, Accepted 1, Confirmed 2, Executing 3, Completed 4)
STAGE_OF_STATUS = {"RECEIVED": 1, "ACCEPTED": 2, "IN_PROGRESS": 3, "COMPLETED": 4}
FAILED_STATUSES = {"REJECTED", "FAILED", "ABORTED"}

Publish = Callable[[str, dict[str, Any]], None]
def _hms() -> str:
    return datetime.now(UTC).strftime("%H:%M:%SZ")


class ZenohFleet:
    def __init__(
        self,
        publish: Publish,
        recorder: FleetEventRecorderPort,
        *,
        operator_id: str = "operator-01",
        speed_mps: float = DEFAULT_SPEED_MPS,
        lost_after_s: int = LOST_AFTER_S,
        carla_positions: bool = False,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self._publish = publish
        self._recorder = recorder
        self._operator = operator_id
        self._speed = speed_mps
        self._lost_after = lost_after_s
        self._carla = carla_positions  # asset positions are CARLA metres: latitude_deg = X, longitude_deg = Y
        self._now = clock
        self.last_message_at: float | None = None
        self.t = 0
        self._drones: dict[str, dict[str, Any]] = {}
        self._seen: dict[str, float] = {}
        self._mission: dict[str, dict[str, Any]] = {}
        self._cmds: list[Command] = []
        self._by_mission: dict[str, Command] = {}
        self._routes: dict[str, ActualRoute] = {}
        # Origin of each goto not yet accepted: a rejected goto must not wipe the current actual route.
        self._goto_origin: dict[int, list[float]] = {}
        self._seq = 0

    # ---- FleetPort -------------------------------------------------------------------------
    def snapshot(self) -> dict[str, Any]:
        return {"t": self.t, "drones": list(self._drones.values()), "cmds": self._cmds}

    def tick(self) -> None:
        self.t += 1
        now = self._now()
        for id_, d in self._drones.items():
            d["hb"] = 0 if d["state"] == "O" else int(now - self._seen[id_])
            d["lost"] = d["hb"] >= self._lost_after
        for c in self._cmds:
            d = self._drones.get(c["droneId"])
            if d and not c.get("final") and c["stage"] >= 1 and d["lost"]:
                self._goto_origin.pop(c["key"], None)
                c["final"] = "unknown"
                c["reason"] = (
                    "Link to the asset lost after sending. Result unknown: "
                    "check the real asset state before retrying."
                )

    def send(self, drone_id: str, action: str, b: dict[str, float] | None) -> Command:
        d = self._drones.get(drone_id)
        if d is None:
            raise UavNotFound(f"unknown UAV {drone_id}")
        validate_command(d["state"], action, b)
        command = icd.ACTION_TO_COMMAND.get(action)
        if command is None:
            raise CommandNotImplemented(f"{action} has no signal in the ICD yet")

        now = self._now()
        mission_id = f"MIS-{uuid.uuid4().hex[:8].upper()}"
        msg: dict[str, Any] = {
            "message_id": f"msg-{uuid.uuid4().hex[:8]}",
            "timestamp_utc": int(now),
            "mission_id": mission_id,
            "asset_id": drone_id,
            "command": command,
            "priority": "NORMAL",
            "operator_id": self._operator,
        }
        if command == "MOVE" and b is not None:
            lat, lon = b["lat"], b["lon"]
            if self._carla:
                lat, lon = icd.lonlat_to_carla(b["lon"], b["lat"])
            msg["destination"] = {"latitude_deg": lat, "longitude_deg": lon, "altitude_m": max(d["alt"], 120.0)}
            msg["speed_mps"] = self._speed
            msg["final_state"] = "HOVER"
        try:
            self._publish(icd.TOPIC_COMMAND, msg)
        except RuntimeError as e:
            raise FleetUnavailable("Zenoh link is down; command not sent") from e

        self._seq += 1
        cmd: Command = {
            "key": self._seq, "droneId": drone_id, "action": action, "b": b, "stage": 0,
            "times": [_hms()],
        }
        self._cmds = (self._cmds + [cmd])[-KEEP_COMMANDS:]
        self._by_mission[mission_id] = cmd
        if command == "MOVE":
            self._mission[drone_id] = {"a": {"lon": d["lon"], "lat": d["lat"]}, "b": b}
        if action == "goto":
            self._goto_origin[cmd["key"]] = [d["lon"], d["lat"]]
        self._recorder.record_event(mission_id, drone_id, "command", command, msg, now)
        return cmd

    # ---- Inbound messages ------------------------------------------------------------------
    def on_message(self, topic: str, raw: bytes) -> None:
        self.last_message_at = self._now()
        try:
            data = json.loads(raw)
            handler = {
                icd.TOPIC_TELEMETRY: self._telemetry,
                icd.TOPIC_HEALTH: self._health,
                icd.TOPIC_HEARTBEAT: self._heartbeat,
                icd.TOPIC_STATUS: self._status,
            }.get(topic)
            if handler:
                handler(data)
        except (ValueError, KeyError, TypeError):
            log.warning("dropping malformed message on %s", topic, exc_info=True)

    def _telemetry(self, m: dict[str, Any]) -> None:
        id_ = m["asset_id"]
        pos = m["position"]
        lon, lat = float(pos["longitude_deg"]), float(pos["latitude_deg"])
        if self._carla:
            lon, lat = icd.carla_to_lonlat(x=lat, y=lon)
        state = icd.ui_state(m["current_state"], m.get("navigation_mode"))
        d = self._drones.get(id_)
        if d is None:
            base = icd.nearest_base(lon, lat)
            d = self._drones[id_] = {
                "id": id_, "state": state, "base": base, "lon": lon, "lat": lat, "alt": 0, "spd": 0,
                "hdg": 0, "bat": 100, "hb": 0, "flaky": False, "lost": False, "gps": "good",
                # UI-only hint: "local" means lon/lat is a projected CARLA point, shown to the operator as metres.
                "frame": "local" if self._carla else "geo",
            }
            self._routes[id_] = ActualRoute()
            asset_type = m.get("asset_type", "UAV")
            self._recorder.register_asset(id_, asset_type, base)
            log.info("asset discovered: %s", id_)
        self._seen[id_] = self._now()
        d.update(
            state=state, lon=lon, lat=lat, alt=pos.get("altitude_m", 0),
            spd=round(m.get("velocity", {}).get("ground_speed_mps", 0) * 3.6),
            hdg=m.get("heading_deg", 0),
            # Forward optional sensor geometry so the UI can draw its field-of-view sector.
            horizontal_fov=m.get("horizontal_fov"),
            visual_los=m.get("visual_los"),
        )
        route = self._routes[id_]
        route.observe(state, [lon, lat])  # unlike trail, it survives hover after the mission
        d.update(route.snapshot_fields())
        if state in ("M", "R"):
            d["trail"] = (d["trail"] + [[lon, lat]])[-TRAIL_MAX:]
        else:
            d["trail"] = []
        mission = self._mission.get(id_) if state == "M" else None
        d["a"], d["b"] = (mission["a"], mission["b"]) if mission else (None, None)
        if state != "M":
            self._mission.pop(id_, None)

    def _health(self, m: dict[str, Any]) -> None:
        d = self._drones.get(m["asset_id"])
        if d is None:
            return
        d["bat"] = m["battery_percent"]
        d["sats"] = m.get("satellite_count", d["sats"])
        d["gps"] = "good" if m.get("gps_fix", True) and d["sats"] >= 8 else "weak"

    def _heartbeat(self, m: dict[str, Any]) -> None:
        id_ = m["asset_id"]
        if id_ not in self._drones:
            return
        self._seen[id_] = self._now()
        if m.get("status") == "OFFLINE":
            self._drones[id_]["state"] = "O"

    def _status(self, m: dict[str, Any]) -> None:
        status, mission_id, asset_id = m["status"], m["mission_id"], m["asset_id"]
        ts = float(m.get("timestamp_utc", self._now()))
        self._recorder.record_event(mission_id, asset_id, "status", status, m, ts)
        d = self._drones.get(asset_id)
        if d is not None and "current_speed_mps" in m:
            d["spd"] = round(float(m["current_speed_mps"]) * 3.6)  # latest speed received wins
        cmd = self._by_mission.get(mission_id)
        if cmd is None or cmd.get("final"):
            return
        if status in FAILED_STATUSES:
            self._goto_origin.pop(cmd["key"], None)
            cmd["final"] = "rejected"
            cmd["reason"] = self._failure_reason(status, cmd, asset_id)
            return
        stage = STAGE_OF_STATUS.get(status)
        if stage is None:
            return
        cmd["stage"] = max(cmd["stage"], stage)
        origin = self._goto_origin.pop(cmd["key"], None) if cmd["stage"] >= 2 else None
        if origin is not None and d is not None:
            # An accepted goto starts a new actual route; changeb keeps it, so the turn shows as a vertex.
            route = self._routes[asset_id]
            route.reset(origin)
            d.update(route.snapshot_fields())
        while len(cmd["times"]) <= cmd["stage"]:
            cmd["times"].append(_hms())
        if status == "COMPLETED":
            cmd["final"] = "completed"

    def _failure_reason(self, status: str, cmd: Command, asset_id: str) -> str:
        d = self._drones.get(asset_id)
        if status == "REJECTED" and d and d["bat"] < MIN_MISSION_BATTERY:
            return f"Rejected by the asset: battery too low ({round(d['bat'])}%). Drone state unchanged."
        return f"{status.capitalize()} by the asset. Check its state before retrying."
