"""Fleet source fed by Zenoh messages (X-Verse mock today, real assets later).

Pure state machine: messages come in through `on_message`, commands go out through `publish`, and
persistence jobs go through `record`. The Zenoh session itself lives in transport.py.
"""

import json
import logging
import time
import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from c2.domain.actual_route import ActualRoute
from c2.domain.commands import KEEP_COMMANDS, MIN_MISSION_BATTERY, validate_command
from c2.domain.errors import (
    CommandNotImplemented,
    FleetUnavailable,
    UavNotFound,
)
from c2.drivers.zenoh import icd
from c2.ports.events import FleetEventRecorderPort
from c2.ports.fleet import Command

log = logging.getLogger(__name__)

TRAIL_MAX = 150
DEFAULT_SPEED_MPS = 15.0
LOST_AFTER_S = 10
# ICD mission_status -> command stage (Sent 0, Accepted 1, Confirmed 2, Executing 3, Completed 4)
STAGE_OF_STATUS = {"RECEIVED": 1, "ACCEPTED": 2, "IN_PROGRESS": 3, "COMPLETED": 4}
FAILED_STATUSES = {"REJECTED", "FAILED", "ABORTED"}

Publish = Callable[[str, dict[str, Any]], None]
def _hms() -> str:
    return datetime.now(UTC).strftime("%H:%M:%SZ")


class ZenohFleet:
    def __init__(
        self,
        publish: Publish,
        recorder: FleetEventRecorderPort,
        *,
        operator_id: str = "operator-01",
        speed_mps: float = DEFAULT_SPEED_MPS,
        lost_after_s: int = LOST_AFTER_S,
        carla_positions: bool = False,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self._publish = publish
        self._recorder = recorder
        self._operator = operator_id
        self._speed = speed_mps
        self._lost_after = lost_after_s
        self._carla = carla_positions  # asset positions are CARLA metres: latitude_deg = X, longitude_deg = Y
        self._now = clock
        self.last_message_at: float | None = None
        self.t = 0
        self._drones: dict[str, dict[str, Any]] = {}
        self._seen: dict[str, float] = {}
        self._mission: dict[str, dict[str, Any]] = {}
        self._cmds: list[Command] = []
        self._by_mission: dict[str, Command] = {}
        # Each ICD MOVE has its own mission ID, while this tracks the overall goto command.
        self._route_by_command: dict[int, dict[str, Any]] = {}
        self._routes: dict[str, ActualRoute] = {}
        # Origin of each goto not yet accepted: a rejected goto must not wipe the current actual route.
        self._goto_origin: dict[int, list[float]] = {}
        self._seq = 0

    # ---- FleetPort -------------------------------------------------------------------------
    def snapshot(self) -> dict[str, Any]:
        return {"t": self.t, "drones": list(self._drones.values()), "cmds": self._cmds}

    def tick(self) -> None:
        self.t += 1
        now = self._now()
        for id_, d in self._drones.items():
            d["hb"] = 0 if d["state"] == "O" else int(now - self._seen[id_])
            d["lost"] = d["hb"] >= self._lost_after
        for c in self._cmds:
            d = self._drones.get(c["droneId"])
            if d and not c.get("final") and c["stage"] >= 1 and d["lost"]:
                self._goto_origin.pop(c["key"], None)
                c["final"] = "unknown"
                c["reason"] = (
                    "Link to the asset lost after sending. Result unknown: "
                    "check the real asset state before retrying."
                )

    def send(
        self,
        drone_id: str,
        action: str,
        b: dict[str, float] | None,
        waypoints: list[dict[str, float]] | None = None,
    ) -> Command:
        d = self._drones.get(drone_id)
        if d is None:
            raise UavNotFound(f"unknown UAV {drone_id}")
        route = waypoints if action == "goto" else None
        if action == "goto" and not route and b:
            route = [b]
        if action == "changeb" and b:
            route = [b]
        validate_command(d["state"], action, b, route if action == "goto" else None)
        command = icd.ACTION_TO_COMMAND.get(action)
        if command is None:
            raise CommandNotImplemented(f"{action} has no signal in the ICD yet")

        now = self._now()
        mission_id = f"MIS-{uuid.uuid4().hex[:8].upper()}"
        first_destination = route[0] if command == "MOVE" and route else b
        msg = self._command_message(drone_id, command, mission_id, now, first_destination, d)
        self._seq += 1
        final_destination = route[-1] if route else b
        cmd: Command = {
            "key": self._seq, "droneId": drone_id, "action": action, "b": final_destination, "stage": 0,
            "times": [_hms()],
        }
        if route:
            cmd["waypoints"] = route
        self._cmds = (self._cmds + [cmd])[-KEEP_COMMANDS:]
        self._by_mission[mission_id] = cmd
        if command == "MOVE":
            points = route or ([b] if b else [])
            self._mission[drone_id] = {
                "a": {"lon": d["lon"], "lat": d["lat"]},
                "b": points[0] if points else b,
                "waypoints": points,
            }
            if points:
                # Register progress before publishing: the asset may report RECEIVED immediately.
                self._route_by_command[cmd["key"]] = {
                    "drone_id": drone_id,
                    "waypoints": points,
                    "next_index": 1,
                }
                log.info("goto %s accepted with %d waypoint(s)", drone_id, len(points))
            if action == "goto":
                self._goto_origin[cmd["key"]] = [d["lon"], d["lat"]]
        try:
            self._publish(icd.TOPIC_COMMAND, msg)
        except RuntimeError as e:
            self._by_mission.pop(mission_id, None)
            self._route_by_command.pop(cmd["key"], None)
            self._goto_origin.pop(cmd["key"], None)
            self._mission.pop(drone_id, None)
            raise FleetUnavailable("Zenoh link is down; command not sent") from e

        self._recorder.record_event(mission_id, drone_id, "command", command, msg, now)
        return cmd

    def _command_message(
        self,
        drone_id: str,
        command: str,
        mission_id: str,
        now: float,
        destination: dict[str, float] | None,
        drone: dict[str, Any],
    ) -> dict[str, Any]:
        msg: dict[str, Any] = {
            "message_id": f"msg-{uuid.uuid4().hex[:8]}",
            "timestamp_utc": int(now),
            "mission_id": mission_id,
            "asset_id": drone_id,
            "command": command,
            "priority": "NORMAL",
            "operator_id": self._operator,
        }
        if command == "MOVE" and destination is not None:
            lat, lon = destination["lat"], destination["lon"]
            if self._carla:
                lat, lon = icd.lonlat_to_carla(destination["lon"], destination["lat"])
            msg["destination"] = {
                "latitude_deg": lat,
                "longitude_deg": lon,
                "altitude_m": max(drone["alt"], 120.0),
            }
            msg["speed_mps"] = self._speed
            msg["final_state"] = "HOVER"
        return msg

    # ---- Inbound messages ------------------------------------------------------------------
    def on_message(self, topic: str, raw: bytes) -> None:
        self.last_message_at = self._now()
        try:
            data = json.loads(raw)
            handler = {
                icd.TOPIC_TELEMETRY: self._telemetry,
                icd.TOPIC_HEALTH: self._health,
                icd.TOPIC_HEARTBEAT: self._heartbeat,
                icd.TOPIC_STATUS: self._status,
            }.get(topic)
            if handler:
                handler(data)
        except (ValueError, KeyError, TypeError):
            log.warning("dropping malformed message on %s", topic, exc_info=True)

    def _telemetry(self, m: dict[str, Any]) -> None:
        id_ = m["asset_id"]
        pos = m["position"]
        lon, lat = float(pos["longitude_deg"]), float(pos["latitude_deg"])
        if self._carla:
            lon, lat = icd.carla_to_lonlat(x=lat, y=lon)
        state = icd.ui_state(m["current_state"], m.get("navigation_mode"))
        d = self._drones.get(id_)
        if d is None:
            base = icd.nearest_base(lon, lat)
            d = self._drones[id_] = {
                "id": id_, "state": state, "base": base, "lon": lon, "lat": lat, "alt": 0, "spd": 0,
                "hdg": 0, "bat": 100, "hb": 0, "flaky": False, "lost": False, "gps": "good",
                "sats": 12, "trail": [], "track": [], "a": None, "b": None, "route": [], "timer": 0,
                # UI-only hint: "local" means lon/lat is a projected CARLA point, shown to the operator as metres.
                "frame": "local" if self._carla else "geo",
            }
            self._routes[id_] = ActualRoute()
            asset_type = m.get("asset_type", "UAV")
            self._recorder.register_asset(id_, asset_type, base)
            log.info("asset discovered: %s", id_)
        self._seen[id_] = self._now()
        d.update(
            state=state, lon=lon, lat=lat, alt=pos.get("altitude_m", 0),
            spd=round(m.get("velocity", {}).get("ground_speed_mps", 0) * 3.6),
            hdg=m.get("heading_deg", 0),
            # Forward optional sensor geometry so the UI can draw its field-of-view sector.
            horizontal_fov=m.get("horizontal_fov"),
            visual_los=m.get("visual_los"),
        )
        route = self._routes[id_]
        route.observe(state, [lon, lat])  # unlike trail, it survives hover after the mission
        d.update(route.snapshot_fields())
        if state in ("M", "R"):
            d["trail"] = (d["trail"] + [[lon, lat]])[-TRAIL_MAX:]
        else:
            d["trail"] = []
        route_active = any(progress["drone_id"] == id_ for progress in self._route_by_command.values())
        # Preserve route geometry during telemetry gaps between one completed leg and the next.
        mission = self._mission.get(id_) if state == "M" or route_active else None
        d["a"], d["b"] = (mission["a"], mission["b"]) if mission else (None, None)
        d["route"] = mission["waypoints"] if mission else []
        if state != "M" and not route_active:
            self._mission.pop(id_, None)

    def _health(self, m: dict[str, Any]) -> None:
        d = self._drones.get(m["asset_id"])
        if d is None:
            return
        d["bat"] = m["battery_percent"]
        d["sats"] = m.get("satellite_count", d["sats"])
        d["gps"] = "good" if m.get("gps_fix", True) and d["sats"] >= 8 else "weak"

    def _heartbeat(self, m: dict[str, Any]) -> None:
        id_ = m["asset_id"]
        if id_ not in self._drones:
            return
        self._seen[id_] = self._now()
        if m.get("status") == "OFFLINE":
            self._drones[id_]["state"] = "O"

    def _status(self, m: dict[str, Any]) -> None:
        status, mission_id, asset_id = m["status"], m["mission_id"], m["asset_id"]
        ts = float(m.get("timestamp_utc", self._now()))
        self._recorder.record_event(mission_id, asset_id, "status", status, m, ts)
        d = self._drones.get(asset_id)
        if d is not None and "current_speed_mps" in m:
            d["spd"] = round(float(m["current_speed_mps"]) * 3.6)  # latest speed received wins
        cmd = self._by_mission.get(mission_id)
        route = self._route_by_command.get(cmd["key"]) if cmd else None
        log.info(
            "mission status %s asset=%s mission=%s command_tracked=%s route_progress=%s",
            status,
            asset_id,
            mission_id,
            cmd is not None,
            f"{route['next_index']}/{len(route['waypoints'])}" if route else "none",
        )
        if cmd is None or cmd.get("final"):
            return
        if status in FAILED_STATUSES:
            self._goto_origin.pop(cmd["key"], None)
            cmd["final"] = "rejected"
            cmd["reason"] = self._failure_reason(status, cmd, asset_id)
            self._route_by_command.pop(cmd["key"], None)
            self._mission.pop(asset_id, None)
            if d:
                d.update(a=None, b=None, route=[])
            return
        stage = STAGE_OF_STATUS.get(status)
        if stage is None:
            return
        if status == "COMPLETED" and route and route["next_index"] < len(route["waypoints"]):
            # A leg completion sends the next MOVE but does not complete the operator's logical goto.
            next_index = route["next_index"]
            destination = route["waypoints"][next_index]
            next_mission_id = f"MIS-{uuid.uuid4().hex[:8].upper()}"
            now = self._now()
            if d is None:
                cmd["final"] = "unknown"
                cmd["reason"] = "Route progress was lost before the next waypoint could be sent."
                self._route_by_command.pop(cmd["key"], None)
                self._mission.pop(asset_id, None)
                if d:
                    d.update(a=None, b=None, route=[])
                return
            message = self._command_message(
                asset_id, "MOVE", next_mission_id, now, destination, d
            )
            self._by_mission.pop(mission_id, None)
            route["next_index"] = next_index + 1
            self._by_mission[next_mission_id] = cmd
            mission = self._mission.get(asset_id)
            if mission:
                mission["b"] = destination
            try:
                self._publish(icd.TOPIC_COMMAND, message)
            except RuntimeError as exc:
                cmd["final"] = "unknown"
                cmd["reason"] = (
                    "The route could not continue after a waypoint because the Zenoh link is down. "
                    "Check the asset position before retrying."
                )
                self._route_by_command.pop(cmd["key"], None)
                self._mission.pop(asset_id, None)
                d.update(a=None, b=None, route=[])
                log.warning("could not send next route leg for %s: %s", asset_id, exc)
                return

            log.info(
                "goto %s completed waypoint %d/%d; sent next leg",
                asset_id,
                next_index,
                len(route["waypoints"]),
            )
            self._recorder.record_event(
                next_mission_id, asset_id, "command", "MOVE", message, now
            )
            cmd["stage"] = max(cmd["stage"], 3)
            while len(cmd["times"]) <= 3:
                cmd["times"].append(_hms())
            return
        cmd["stage"] = max(cmd["stage"], stage)
        if status in ("ACCEPTED", "IN_PROGRESS") and cmd["action"] == "changeb" and d is not None:
            route = self._routes[asset_id]
            route.mark_vertex([d["lon"], d["lat"]])
            d.update(route.snapshot_fields())
        origin = self._goto_origin.pop(cmd["key"], None) if cmd["stage"] >= 2 else None
        if origin is not None and d is not None:
            # An accepted goto starts a new actual route; changeb keeps it, so the turn shows as a vertex.
            route = self._routes[asset_id]
            route.reset(origin)
            d.update(route.snapshot_fields())
        while len(cmd["times"]) <= cmd["stage"]:
            cmd["times"].append(_hms())
        if status == "COMPLETED":
            self._route_by_command.pop(cmd["key"], None)
            cmd["final"] = "completed"
            self._mission.pop(asset_id, None)
            if d:
                d.update(a=None, b=None, route=[])
                route = self._routes.get(asset_id)
                if route:
                    route.clear()
                    d.update(route.snapshot_fields())

    def _failure_reason(self, status: str, cmd: Command, asset_id: str) -> str:
        d = self._drones.get(asset_id)
        if status == "REJECTED" and d and d["bat"] < MIN_MISSION_BATTERY:
            return f"Rejected by the asset: battery too low ({round(d['bat'])}%). Drone state unchanged."
        return f"{status.capitalize()} by the asset. Check its state before retrying."
