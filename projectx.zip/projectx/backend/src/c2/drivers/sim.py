"""Server-side fleet simulator.

Stand-in for the real source of fleet data (Zenoh driver + X-Verse). It keeps the same JSON shape
the frontend consumes, so swapping it for the real driver changes nothing on the client.
"""

import math
import random
from datetime import UTC, datetime
from typing import Any, Literal

from c2.config import Settings, settings
from c2.domain.actual_route import ActualRoute
from c2.domain.commands import KEEP_COMMANDS, MIN_MISSION_BATTERY, validate_command
from c2.domain.errors import UavNotFound
from c2.services.asset_registry import AssetMetadata

SPEED_KM_PER_TICK = 1.5
AIRBORNE = {"T", "H", "M", "R", "L"}
STAGES = 5  # Sent, Accepted, Confirmed, Executing, Completed

BASES: dict[str, dict[str, Any]] = {
    # Capgemini Portugal offices (coordinates geocoded from the public addresses; elevations approximate).
    "ALFA": {"lon": -9.1869, "lat": 38.7542, "elev": 100},  # Lisboa, Torre Colombo
    "BRAVO": {"lon": -8.6392, "lat": 41.1415, "elev": 30},  # Porto, Lake Towers
    "CHARLIE": {"lon": -7.9008, "lat": 38.5640, "elev": 280},  # Evora, Rua da Somefe
    "DELTA": {"lon": -7.5022, "lat": 40.1375, "elev": 450},  # Fundao, Centro de Negocios
}

Drone = dict[str, Any]
Command = dict[str, Any]


def km(a: dict[str, float], b: dict[str, float]) -> float:
    la = math.radians((a["lat"] + b["lat"]) / 2)
    return math.hypot((b["lon"] - a["lon"]) * 111.32 * math.cos(la), (b["lat"] - a["lat"]) * 110.57)


def bearing(a: dict[str, float], b: dict[str, float]) -> float:
    la = math.radians(a["lat"])
    deg = math.degrees(math.atan2((b["lon"] - a["lon"]) * 111.32 * math.cos(la), (b["lat"] - a["lat"]) * 110.57))
    return (deg + 360) % 360


# ---- Deviations (simulator only) ---------------------------------------------------------------------
# Wind and avoidance manoeuvres bend the positions the simulated drones REPORT, so the map shows a real
# route that differs from the planned straight line. Nothing needs to be "there": each flight simply gets a
# random sidestep, as if the pilot had dodged something. They live only here, in the data source: the
# pipeline downstream (fleet service, actual-route builder, API) just receives positions and never corrects
# them, so a real driver feeding real positions behaves the same way.

WIND_KM_PER_TICK = 0.35  # about a quarter of the cruise speed
MAX_WIND_KM_PER_TICK = SPEED_KM_PER_TICK / 2  # even at the strongest gust (x1.5) the drone still makes headway
GUST_RANGE = (0.5, 1.5)
WIND_FROM_DEG = 300.0  # meteorological: the direction the wind blows FROM
CRUISE_SPD = 65
MIN_DETOUR_LEG_KM = 10.0  # shorter legs fly straight
LONG_LEG_KM = 80.0  # legs longer than this may get a second manoeuvre
DETOUR_OFFSET_FRACTION = (0.06, 0.14)  # sidestep as a fraction of the leg length...
DETOUR_OFFSET_KM = (2.0, 15.0)  # ...clamped to this range


def _xy(lon: float, lat: float, o: dict[str, float]) -> tuple[float, float]:
    la = math.radians((lat + o["lat"]) / 2)
    return (lon - o["lon"]) * 111.32 * math.cos(la), (lat - o["lat"]) * 110.57


def detour_waypoints(
    start: dict[str, float], dest: dict[str, float], rng: random.Random
) -> list[tuple[float, float]]:
    """(lon, lat) waypoints for an avoidance manoeuvre on the leg start->dest: the drone leaves the line,
    flies alongside it and comes back. Each manoeuvre is a pair of waypoints on the same side. Short legs get none."""
    dx, dy = _xy(dest["lon"], dest["lat"], start)
    length = math.hypot(dx, dy)
    if length < MIN_DETOUR_LEG_KM:
        return []
    count = 2 if length > LONG_LEG_KM and rng.random() < 0.5 else 1
    out: list[tuple[float, float]] = []
    slot = 0.8 / count  # share of the leg each manoeuvre may use (the first and last 10 % stay straight)
    for i in range(count):
        t0 = 0.1 + slot * i + slot * rng.uniform(0.1, 0.35)
        t1 = t0 + slot * rng.uniform(0.25, 0.4)
        side = rng.choice((-1, 1))
        off = side * min(max(length * rng.uniform(*DETOUR_OFFSET_FRACTION), DETOUR_OFFSET_KM[0]), DETOUR_OFFSET_KM[1])
        nx, ny = -dy / length, dx / length
        for t in (t0, t1):
            x, y = t * dx + nx * off, t * dy + ny * off
            out.append(_from_xy(x, y, start))
    return out


def _from_xy(x: float, y: float, o: dict[str, float]) -> tuple[float, float]:
    """Exact inverse of `_xy` (same mean-latitude projection), so waypoints land at the intended offset."""
    lat = o["lat"] + y / 110.57
    return o["lon"] + x / (111.32 * math.cos(math.radians((lat + o["lat"]) / 2))), lat


class Deviations:
    """Wind drift and random avoidance manoeuvres for the simulated drones. Keeps its per-drone state here,
    not in the drone dicts, so the JSON snapshot the frontend consumes keeps its shape."""

    def __init__(
        self,
        wind_km_per_tick: float = WIND_KM_PER_TICK,
        wind_from_deg: float = WIND_FROM_DEG,
        detours: bool = True,
        seed: int | None = None,
    ) -> None:
        if not (math.isfinite(wind_km_per_tick) and math.isfinite(wind_from_deg)):
            raise ValueError("wind speed and direction must be finite numbers")
        # Capped so a headwind never stops the drone: every flight still arrives.
        self.wind = min(max(0.0, wind_km_per_tick), MAX_WIND_KM_PER_TICK)
        self.wind_from = wind_from_deg % 360
        self.detours = detours
        self._seed = seed
        # Per drone, so one drone's flight does not depend on how many others are flying (repeatable with a seed).
        self._rngs: dict[str, random.Random] = {}
        self._gusts: dict[str, float] = {}
        self._legs: dict[str, list[tuple[float, float]]] = {}

    @classmethod
    def from_settings(cls, s: Settings = settings) -> "Deviations | None":
        """Reads C2_SIM_DEVIATIONS / C2_SIM_WIND_KM_PER_TICK / C2_SIM_WIND_FROM_DEG (validated in c2.config)."""
        if not s.c2_sim_deviations:
            return None
        return cls(wind_km_per_tick=s.c2_sim_wind_km_per_tick, wind_from_deg=s.c2_sim_wind_from_deg)

    def _rng(self, drone_id: str) -> random.Random:
        rng = self._rngs.get(drone_id)
        if rng is None:
            rng = self._rngs[drone_id] = random.Random(None if self._seed is None else f"{self._seed}:{drone_id}")
        return rng

    def start_leg(self, drone_id: str) -> None:
        """A command set a new target (goto, changeb, rtb): the next aim() plans a fresh manoeuvre from here."""
        self._legs.pop(drone_id, None)

    def aim(self, d: "Drone", target: dict[str, float]) -> dict[str, float]:
        """Where to head now: the next waypoint of the current leg, or the target itself. The leg's
        manoeuvre is planned on the first tick after start_leg() (or at startup for flights in progress)."""
        via = self._legs.get(d["id"])
        if via is None:
            via = self._legs[d["id"]] = (
                detour_waypoints(d, target, self._rng(d["id"])) if self.detours else []  # type: ignore[arg-type]
            )
        return {"lon": via[0][0], "lat": via[0][1]} if via else target

    def reached(self, d: "Drone", aim: dict[str, float], target: dict[str, float]) -> None:
        """The drone got to `aim`: either the next detour waypoint or the leg's target (which ends the leg)."""
        if aim is target:
            self._legs.pop(d["id"], None)
        elif self._legs.get(d["id"]):
            self._legs[d["id"]].pop(0)

    def drift(self, d: "Drone") -> None:
        """Carries the drone downwind for one tick, with slow gusts (each drone has its own)."""
        if self.wind <= 0:
            return
        g = self._gusts.get(d["id"], 1.0)
        g = max(GUST_RANGE[0], min(GUST_RANGE[1], g + (1 - g) * 0.1 + self._rng(d["id"]).gauss(0, 0.06)))
        self._gusts[d["id"]] = g
        to = math.radians((self.wind_from + 180) % 360)
        km_ = self.wind * g
        la = math.radians(d["lat"])
        d["lon"] += km_ * math.sin(to) / (111.32 * math.cos(la))
        d["lat"] += km_ * math.cos(to) / 110.57


# Sensor geometry for the map's field-of-view sector; same values the X-Verse mock publishes.
HORIZONTAL_FOV_DEG = 78
VISUAL_LOS_M = 1000


def _drone(id_: str, state: str, base: str, bat: float, **over: Any) -> Drone:
    b = BASES[base]
    d: Drone = {
        "id": id_, "state": state, "base": base, "lon": b["lon"], "lat": b["lat"], "alt": b["elev"],
        "spd": 0, "hdg": 0, "bat": bat, "hb": 0, "flaky": False, "lost": False, "gps": "good",
        "sats": 14, "trail": [], "track": [], "a": None, "b": None, "timer": 0, "frame": "geo",
        "horizontal_fov": HORIZONTAL_FOV_DEG, "visual_los": VISUAL_LOS_M,
    }
    d.update(over)
    return d


def initial_metadata() -> dict[str, AssetMetadata]:
    """APP-6 metadata for the simulator fleet, preloaded into the AssetRegistry.

    The sim has no DB; without preload the registry would answer with DEFAULT and every asset would
    render as an anonymous rotary UAV with no callsign.
    """
    return {
        name: AssetMetadata(
            affiliation="FRIEND", platform_type="ROTARY_UAV",
            callsign=name, higher_formation="1 ESQAV", echelon="SECTION",
        )
        for name in (
            "EANES", "TRISTÃO", "GAMA", "GOMES", "BARTOLOMEU",
            "DIOGO CÃO", "MAGALHÃES", "CORTE-REAL", "ZARCO", "CABRAL",
        )
    }


def initial_drones() -> list[Drone]:
    return [
        _drone("EANES", "O", "ALFA", 100),
        _drone("TRISTÃO", "S", "ALFA", 96),
        _drone("GAMA", "M", "ALFA", 78, lon=-8.919, lat=39.26, alt=420, spd=65, hdg=22,
               a={"lon": -9.1869, "lat": 38.7542}, b={"lon": -8.42, "lat": 40.2},
               trail=[[-9.1869, 38.7542], [-9.05, 39.0], [-8.919, 39.26]]),
        _drone("GOMES", "H", "BRAVO", 61, lon=-8.62, lat=41.16, alt=260, gps="weak", sats=5),
        _drone("BARTOLOMEU", "R", "CHARLIE", 24, lon=-8.2, lat=38.0, alt=380, spd=65, hdg=25,
               trail=[[-8.5, 37.5], [-8.35, 37.75], [-8.2, 38.0]]),
        _drone("DIOGO CÃO", "S", "BRAVO", 88),
        _drone("MAGALHÃES", "H", "BRAVO", 47, lon=-6.78, lat=41.72, alt=900, hb=38, lost=True),
        _drone("CORTE-REAL", "G", "CHARLIE", 9, lon=-8.66, lat=37.16, alt=40),
        _drone("ZARCO", "H", "CHARLIE", 72, lon=-7.75, lat=38.8, alt=300, flaky=True),
        _drone("CABRAL",         "M", "DELTA", 83, lon=-7.3, lat=40.56, alt=350, spd=65, hdg=20,
                       a={"lon": -7.5022, "lat": 40.1375}, b={"lon": -7.0, "lat": 41.2},
                       trail=[[-7.5022, 40.1375], [-7.4, 40.35], [-7.3, 40.56]]),
    ]


def step_drone(d: Drone, t: int, dev: "Deviations | None" = None) -> None:
    """Advances a drone by one second of simulated time (in place). `dev` adds wind and obstacle detours."""
    if d["state"] == "O":
        d["hb"] = 0
        return
    if d["lost"]:
        d["hb"] += 1
    elif d["flaky"]:
        d["hb"] = t % 9
    else:
        d["hb"] = 0
    if d["hb"] >= 10:
        return

    base = BASES[d["base"]]
    if d["state"] == "T":
        d["timer"] += 1
        d["alt"] += 30
        if d["timer"] >= 3:
            d["state"], d["timer"] = "H", 0
    if d["state"] == "L":
        d["timer"] += 1
        d["spd"] = 0
        d["alt"] = max(base["elev"], d["alt"] - 80)
        if d["timer"] >= 4:
            d["timer"] = 0
            if km(d, base) < 0.8:
                d.update(state="S", lon=base["lon"], lat=base["lat"], alt=base["elev"], trail=[], b=None)
            else:
                d["state"] = "G"

    target = d["b"] if d["state"] == "M" else base if d["state"] == "R" else None
    if target:
        aim = dev.aim(d, target) if dev else target
        before = (d["lon"], d["lat"])
        dist = km(d, aim)
        d["hdg"] = bearing(d, aim)
        if dist <= SPEED_KM_PER_TICK:
            d["lon"], d["lat"] = aim["lon"], aim["lat"]
            d["trail"] = d["trail"] + [[d["lon"], d["lat"]]]
            if dev:
                dev.reached(d, aim, target)
            if aim is target:  # a detour waypoint just means: carry on to the next one next tick
                if d["state"] == "M":
                    d.update(state="H", spd=0, trail=[], b=None)
                else:
                    d["state"], d["timer"] = "L", 0
        else:
            f = SPEED_KM_PER_TICK / dist
            d["lon"] += (aim["lon"] - d["lon"]) * f
            d["lat"] += (aim["lat"] - d["lat"]) * f
            d["spd"] = CRUISE_SPD
            if dev:
                dev.drift(d)
                moved = km({"lon": before[0], "lat": before[1]}, d)
                d["spd"] = round(CRUISE_SPD * moved / SPEED_KM_PER_TICK)  # ground speed, wind included
            if t % 2 == 0:
                d["trail"] = (d["trail"] + [[d["lon"], d["lat"]]])[-150:]
    if d["state"] in AIRBORNE:
        d["bat"] = max(0, d["bat"] - 0.04)


def _apply(c: Command, d: Drone) -> None:
    a = c["action"]
    if a == "poweron":
        d["state"] = "S"
    elif a == "poweroff":
        d["state"] = "O"
    elif a == "takeoff":
        d["state"], d["timer"] = "T", 0
    elif a in ("goto", "changeb"):
        if d["state"] == "S":
            d["alt"] += 120
        d.update(state="M", a={"lon": d["lon"], "lat": d["lat"]}, b=c["b"], trail=[[d["lon"], d["lat"]]])
    elif a == "hold":
        d["state"], d["spd"] = "H", 0
    elif a == "rtb":
        d["state"] = "R"
        if not d["trail"]:
            d["trail"] = [[d["lon"], d["lat"]]]
    elif a == "land":
        d["state"], d["timer"] = "L", 0


def _is_done(c: Command, d: Drone) -> bool:
    a = c["action"]
    if a in ("goto", "changeb", "takeoff"):
        return d["state"] == "H"
    if a == "rtb":
        return d["state"] == "S"
    if a == "land":
        return d["state"] in ("S", "G")
    return True


def _hms() -> str:
    return datetime.now(UTC).strftime("%H:%M:%SZ")


def step_command(c: Command, d: Drone) -> None:
    """Moves a command one step through Sent -> Accepted -> Confirmed -> Executing -> Completed."""
    if c.get("final"):
        return
    if c["stage"] < 3:
        c["stage"] += 1
        c["times"].append(_hms())
        if c["stage"] == 1 and c["action"] in ("goto", "changeb") and d["bat"] < MIN_MISSION_BATTERY:
            c["final"] = "rejected"
            c["reason"] = (
                f"Rejected by server: battery too low for mission ({round(d['bat'])}%, "
                f"minimum {MIN_MISSION_BATTERY}%). Drone state unchanged."
            )
        elif c["stage"] == 2 and d["hb"] >= 3:
            c["final"] = "unknown"
            c["reason"] = (
                "Link to drone degraded after sending. Result unknown: "
                "check the real drone state before retrying."
            )
        elif c["stage"] == 3:
            _apply(c, d)
    elif _is_done(c, d):
        c["stage"] = STAGES - 1
        c["times"].append(_hms())
        c["final"] = "completed"


class SimFleet:
    def __init__(self, deviations: "Deviations | None | Literal['settings']" = "settings") -> None:
        """`deviations`: a Deviations instance, None for ideal straight flight, or "settings" (default) to
        follow C2_SIM_DEVIATIONS and the wind settings in c2.config."""
        if deviations == "settings":
            self.deviations = Deviations.from_settings()
        elif deviations is None or isinstance(deviations, Deviations):
            self.deviations = deviations
        else:
            raise TypeError(f"deviations must be a Deviations, None or 'settings', not {deviations!r}")
        self.t = 0
        self.drones = initial_drones()
        self.cmds: list[Command] = []
        self._seq = 0
        self._routes: dict[str, ActualRoute] = {}
        for d in self.drones:
            route = self._routes[d["id"]] = ActualRoute()
            for lon, lat in d["trail"]:  # drones already flying start with the path they flew so far
                route.update([lon, lat])
            d.update(route.snapshot_fields())

    def snapshot(self) -> dict[str, Any]:
        return {"t": self.t, "drones": self.drones, "cmds": self.cmds}

    def get(self, drone_id: str) -> Drone | None:
        return next((d for d in self.drones if d["id"] == drone_id), None)

    def send(self, drone_id: str, action: str, b: dict[str, float] | None) -> Command:
        d = self.get(drone_id)
        if d is None:
            raise UavNotFound(f"unknown UAV {drone_id}")
        validate_command(d["state"], action, b)
        self._seq += 1
        c: Command = {
            "key": self._seq, "droneId": drone_id, "action": action, "b": b, "stage": 0,
            "times": [_hms()],
        }
        self.cmds.append(c)
        return c

    def tick(self) -> None:
        self.t += 1
        for d in self.drones:
            step_drone(d, self.t, self.deviations)
        for c in self.cmds:
            d = self.get(c["droneId"])
            applied_before = c["stage"] >= 3
            step_command(c, d)  # type: ignore[arg-type]
            if applied_before or c["stage"] != 3 or c.get("final"):
                continue
            if c["action"] in ("goto", "changeb", "rtb") and self.deviations:
                self.deviations.start_leg(d["id"])  # type: ignore[index]
            if c["action"] == "goto":  # changeb keeps the route, so the turn shows as a vertex
                self._routes[d["id"]].reset([d["lon"], d["lat"]])  # type: ignore[index]
        for d in self.drones:
            route = self._routes[d["id"]]
            route.observe(d["state"], [d["lon"], d["lat"]])
            d.update(route.snapshot_fields())
        self.cmds = self.cmds[-KEEP_COMMANDS:]
