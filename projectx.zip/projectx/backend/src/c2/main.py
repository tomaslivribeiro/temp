import asyncio
import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from c2 import db
from c2.api import admin, geozones, uavs, ws
from c2.api.schemas import DatabaseVersionResponse, ErrorResponse, HealthResponse, VersionResponse
from c2.config import settings
from c2.repositories.geozones import SqlAlchemyGeozoneRepository
from c2.repositories.runtime_configuration import SqlAlchemyRuntimeConfigurationRepository
from c2.runtime import Runtime, RuntimeSettings
from c2.services.asset_registry import AssetRegistry
from c2.services.geozone_registry import GeozoneRegistry

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")


async def _heartbeat() -> None:
    while True:
        await asyncio.sleep(settings.ws_heartbeat_seconds)
        await ws.manager.broadcast("server.heartbeat", {"clients": ws.manager.count})


async def _fleet_loop(runtime: Runtime) -> None:
    while True:
        await asyncio.sleep(1)
        await ws.manager.broadcast("fleet.snapshot", runtime.service.advance())


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    tasks = [asyncio.create_task(_heartbeat())]
    runtime = Runtime(
        RuntimeSettings.from_env(settings),
        SqlAlchemyRuntimeConfigurationRepository(db.engine),
        AssetRegistry(db.engine),
    )
    await runtime.start()
    app.state.runtime = runtime
    app.state.geozones = GeozoneRegistry(SqlAlchemyGeozoneRepository(db.engine))
    try:
        repository = SqlAlchemyRuntimeConfigurationRepository(db.engine)
        await asyncio.to_thread(repository.save_active_driver, runtime.settings.driver)
    except Exception:
        logging.getLogger(__name__).warning(
            "could not persist active driver configuration", exc_info=True
        )
    tasks.append(asyncio.create_task(_fleet_loop(runtime)))
    yield
    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)
    await runtime.stop()


app = FastAPI(
    title="ProjectX UAV C2 API",
    version="0.1.0",
    description=(
        "HTTP API for health and runtime information and for submitting UAV commands. "
        "Live fleet snapshots and command progress use the `/ws` WebSocket; its message "
        "contract is documented separately because OpenAPI describes HTTP APIs."
    ),
    openapi_tags=[
        {"name": "System", "description": "Health, runtime and database migration status."},
        {"name": "UAV commands", "description": "Commands submitted to the active fleet source."},
        {"name": "Geozones", "description": "No-fly zones and the sources they come from."},
        {"name": "Admin", "description": "Runtime settings (requires the X-Admin-Token header)."},
    ],
    lifespan=lifespan,
)
app.include_router(ws.router)
app.include_router(uavs.router)
app.include_router(admin.router)
app.include_router(geozones.router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.c2_cors_origins.split(",") if o.strip()],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["System"],
    summary="Check API health",
    description="Returns a successful status when the backend API process is responding.",
)
def health() -> HealthResponse:
    return HealthResponse(status="ok")


@app.get(
    "/version",
    response_model=VersionResponse,
    tags=["System"],
    summary="Get API and active fleet source version",
)
def version() -> VersionResponse:
    runtime = getattr(app.state, "runtime", None)
    return VersionResponse(version=app.version, driver=runtime.settings.driver if runtime else settings.c2_driver)


@app.get(
    "/db/version",
    response_model=DatabaseVersionResponse,
    tags=["System"],
    summary="Get the database migration revision",
    description="Returns the Alembic revision currently applied to the configured database.",
    responses={503: {"model": ErrorResponse, "description": "The database is unavailable."}},
)
def db_version() -> DatabaseVersionResponse:
    try:
        return DatabaseVersionResponse(revision=db.current_revision())
    except Exception as exc:
        raise HTTPException(status_code=503, detail="database unavailable") from exc
