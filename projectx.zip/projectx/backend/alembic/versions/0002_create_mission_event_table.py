"""create mission_event table

Revision ID: 0002
Revises: 0001
"""
from alembic import op
import sqlalchemy as sa

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "mission_event",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("mission_id", sa.String(64), nullable=False),
        sa.Column("asset_id", sa.String(64), nullable=False),
        sa.Column("kind", sa.String(16), nullable=False),
        sa.Column("name", sa.String(32), nullable=False),
        sa.Column("payload", sa.JSON, nullable=False),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.UniqueConstraint("mission_id", "asset_id", "kind", "name"),
    )
    op.create_index("ix_mission_event_mission_id", "mission_event", ["mission_id"])
    op.create_index("ix_mission_event_asset_id", "mission_event", ["asset_id"])


def downgrade() -> None:
    op.drop_index("ix_mission_event_asset_id", table_name="mission_event")
    op.drop_index("ix_mission_event_mission_id", table_name="mission_event")
    op.drop_table("mission_event")
