"""add military metadata to uav

Revision ID: 0005
Revises: 0004
"""
import sqlalchemy as sa
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None

# Default platform type per existing `domain` value, so a column backfill maps the asset_type the
# Zenoh driver captured on first sighting into a specific NATO platform category.
DOMAIN_TO_PLATFORM = {"air": "ROTARY_UAV", "ground": "WHEELED_UGV", "water": "USV"}


def upgrade() -> None:
    op.add_column("uav", sa.Column("affiliation", sa.String(16), nullable=False, server_default="FRIEND"))
    op.add_column("uav", sa.Column("platform_type", sa.String(32), nullable=True))
    op.add_column("uav", sa.Column("callsign", sa.String(64), nullable=True))
    op.add_column("uav", sa.Column("higher_formation", sa.String(64), nullable=True))
    op.add_column("uav", sa.Column("echelon", sa.String(16), nullable=True))

    conn = op.get_bind()
    for domain, platform in DOMAIN_TO_PLATFORM.items():
        conn.execute(
            sa.text("UPDATE uav SET platform_type = :p WHERE domain = :d AND platform_type IS NULL"),
            {"p": platform, "d": domain},
        )
    conn.execute(
        sa.text("UPDATE uav SET platform_type = :p WHERE platform_type IS NULL"),
        {"p": "ROTARY_UAV"},
    )


def downgrade() -> None:
    op.drop_column("uav", "echelon")
    op.drop_column("uav", "higher_formation")
    op.drop_column("uav", "callsign")
    op.drop_column("uav", "platform_type")
    op.drop_column("uav", "affiliation")
