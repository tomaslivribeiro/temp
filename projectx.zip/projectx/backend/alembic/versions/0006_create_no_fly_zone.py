"""no-fly zones and their sources

Revision ID: 0006
Revises: 0005
"""
import sqlalchemy as sa
from alembic import op

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "geozone_source",
        sa.Column("id", sa.String(32), primary_key=True),
        sa.Column("name", sa.String(128), nullable=False),
        sa.Column("url", sa.String(512), nullable=True),
        sa.Column("attribution", sa.String(256), nullable=False),
        sa.Column("license_note", sa.Text, nullable=True),
        sa.Column("dataset_version", sa.String(128), nullable=True),
        sa.Column("retrieved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_table(
        "no_fly_zone",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("source_id", sa.String(32), sa.ForeignKey("geozone_source.id"), nullable=False),
        sa.Column("external_id", sa.String(128), nullable=False),
        sa.Column("name", sa.String(256), nullable=False),
        sa.Column("restriction", sa.String(32), nullable=False),
        sa.Column("reason", sa.String(64), nullable=True),
        sa.Column("message", sa.Text, nullable=True),
        sa.Column("shape", sa.JSON, nullable=False),
        sa.Column("lower_m", sa.Float, nullable=True),
        sa.Column("upper_m", sa.Float, nullable=True),
        sa.Column("lower_ref", sa.String(4), nullable=True),
        sa.Column("upper_ref", sa.String(4), nullable=True),
        sa.Column("valid_from", sa.DateTime(timezone=True), nullable=True),
        sa.Column("valid_to", sa.DateTime(timezone=True), nullable=True),
        sa.Column("properties", sa.JSON, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.UniqueConstraint("source_id", "external_id"),
    )
    op.create_index("ix_no_fly_zone_source_id", "no_fly_zone", ["source_id"])


def downgrade() -> None:
    op.drop_index("ix_no_fly_zone_source_id", table_name="no_fly_zone")
    op.drop_table("no_fly_zone")
    op.drop_table("geozone_source")
