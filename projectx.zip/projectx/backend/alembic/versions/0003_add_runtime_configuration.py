"""persist active runtime driver

Revision ID: 0003
Revises: 0002
"""
from alembic import op
import sqlalchemy as sa

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "runtime_configuration",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("active_driver", sa.String(16), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("id = 1", name="ck_runtime_configuration_singleton"),
    )


def downgrade() -> None:
    op.drop_table("runtime_configuration")