# Put an asset on the C2 map

A guide for anyone who wants to publish information about a vehicle (drone, ground vehicle, vessel) and see it on the C2 map. No C2 code change is needed: just publish Zenoh messages in the format below.

## 1. Make the C2 listen to Zenoh

- With Docker: `make mock` starts the C2 in Zenoh mode with a router/mock at `tcp/localhost:7447`.
- Or, in the C2 **Settings** screen: driver `zenoh` and your router's endpoint (e.g. `tcp/10.0.0.5:7447`), **Test connection**, **Save and apply**.

Your process connects to the same endpoint and publishes on the topics below.

## 2. Publish telemetry

Topic: **`asset/telemetry`**, JSON payload, 1 to 10 times per second. The first message for a new `asset_id` creates the asset on the map.

```json
{
  "asset_id": "UGV-01",
  "asset_type": "UGV",
  "position": { "latitude_deg": 38.7223, "longitude_deg": -9.1393, "altitude_m": 0 },
  "velocity": { "ground_speed_mps": 4.2 },
  "heading_deg": 90,
  "horizontal_fov": 78,
  "visual_los": 1000,
  "current_state": "MOVING"
}
```

| Field | Required | Notes |
| --- | --- | --- |
| `asset_id` | yes | unique identifier; shown on the map until there is a callsign |
| `position.latitude_deg`, `position.longitude_deg` | yes | WGS84 degrees (see [Coordinates](#coordinates)) |
| `current_state` | yes | see the states table |
| `asset_type` | no (default `UAV`) | decides the symbol; see the table below |
| `position.altitude_m` | no | metres |
| `velocity.ground_speed_mps` | no | m/s; with speed > 0 the symbol shows an arrow and km/h |
| `heading_deg` | no | 0 = north, clockwise |
| `horizontal_fov` | no | degrees; draws the sensor cone centered on `heading_deg` |
| `visual_los` | no | metres; distance from the asset to the sensor cone arc |
| `navigation_mode` | no | `RETURN_HOME` with `MOVING` shows the asset returning to base |

Messages missing a required field are dropped (a warning appears in the backend log).

### Vehicle type → symbol

| `asset_type` | Symbol on the map |
| --- | --- |
| `UAV` | rotary-wing UAV (blue dome) |
| `DIGITAL_TWIN` | rotary-wing UAV |
| `UGV` | wheeled ground vehicle (blue circle) |
| `USV` | surface vessel (blue circle) |

`asset_type` only counts in the **first message** for each `asset_id`. To refine it later (fixed wing, tracked, callsign, formation), use Settings → **Assets** or the admin API:

```bash
curl -s -X PATCH -H 'X-Admin-Token: dev-admin' -H 'Content-Type: application/json' \
  -d '{"platform_type": "TRACKED_UGV", "callsign": "BRAVO-1"}' \
  http://localhost:8000/admin/uavs/UGV-01
```

`platform_type` values: `ROTARY_UAV`, `FIXED_WING_UAV`, `WHEELED_UGV`, `TRACKED_UGV`, `USV`, `FOOT`.

### States (`current_state`)

| Value | Shown as |
| --- | --- |
| `OFFLINE` | off |
| `INITIALIZING`, `READY`, `PARKED` | standby |
| `MOVING` | on mission (draws the trail) |
| `RETURNING_HOME` | returning |
| `HOLDING`, `HOVERING`, `LOITERING`, `MISSION_COMPLETE` | stopped / hovering |
| `LANDING` | landing |
| `EMERGENCY`, `FAULT` | faulty (damage mark on the symbol) |

An unknown value is shown as stopped.

## 3. Optional: health and heartbeat

They only take effect for assets that have already sent telemetry.

- **`asset/health`**: `{"asset_id": "UGV-01", "battery_percent": 72, "satellite_count": 11, "gps_fix": true}`. Battery below 30 % (warning) or 15 % (critical) adds `!` / `!!` to the symbol.
- **`system/heartbeat`**: `{"asset_id": "UGV-01", "status": "ONLINE"}`. Keeps the asset alive without telemetry; `"status": "OFFLINE"` marks it as off.

With no telemetry or heartbeat for 10 s (configurable in Settings, *lost after*), the asset is faded on the map as "no contact".

## Python example

```python
import json, time
import zenoh  # pip install eclipse-zenoh

conf = zenoh.Config()
conf.insert_json5("connect/endpoints", json.dumps(["tcp/127.0.0.1:7447"]))

with zenoh.open(conf) as session:
    lon = -9.1393
    while True:
        lon += 0.0001
        session.put("asset/telemetry", json.dumps({
            "asset_id": "UGV-01",
            "asset_type": "UGV",
            "position": {"latitude_deg": 38.7223, "longitude_deg": lon, "altitude_m": 0},
            "velocity": {"ground_speed_mps": 4.2},
            "heading_deg": 90,
            "current_state": "MOVING",
        }))
        time.sleep(1)
```

Without writing code: with `make mock`, the mock console at `http://localhost:5174` publishes messages by hand on any topic.

## Coordinates

- By default (`C2_POSITION_FORMAT=geo`), `latitude_deg` and `longitude_deg` are WGS84 degrees.
- With `C2_POSITION_FORMAT=carla` (CARLA Town10HD map), `latitude_deg` carries **x** and `longitude_deg` carries **y**, in metres, as in ICD v0.2.

## Common problems

| Symptom | Likely cause |
| --- | --- |
| The asset does not appear | C2 is not in `zenoh` mode, a different endpoint, or `asset_id` / `position` / `current_state` is missing |
| Shows as a drone but it is a ground vehicle | the first message had no `asset_type: "UGV"`; fix it with the PATCH above |
| It is faded | no messages for more than 10 s |
| It does not receive commands | the C2 publishes them on `c2/mission/command`; see the [ICD](zenoh-driver.md) |

Implementation details: [symbology-implementation.md](symbology-implementation.md). Full contract: the wiki ICD page and [zenoh-driver.md](zenoh-driver.md).
