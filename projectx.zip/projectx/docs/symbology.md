# Military symbology (APP-6)

The map renders every asset as a NATO APP-6 symbol produced by [`milsymbol`](https://github.com/spatialillusions/milsymbol). This page documents the mapping from the internal C2 data model to the 30-character SIDC we pass to the library. The wiki page [Military Symbology](../projectx.wiki/Military-Symbology.md) covers the "what" and "why"; this page covers the "how".

## SIDC layout (positions 1-30)

| Pos | Field | How we fill it |
|---|---|---|
| 1-2 | Version | `13` (APP-6 E), fixed |
| 3 | Context | `0` (Reality) — hardcoded |
| 4 | Standard Identity | `3` Friend, `6` Hostile, `4` Neutral, `1` Unknown |
| 5-6 | Symbol Set | `01` Air, `10` Land Unit, `15` Land Equipment, `30` Sea Surface |
| 7 | Status | `0` Present, `1` Planned, `3` Damaged, `4` Destroyed |
| 8 | HQ / TF / Dummy | `0` — not used in the PoC |
| 9-10 | Echelon / mobility | Land Unit (`FOOT`): echelon `11` Team, `12` Squad, `13` Section, `14` Platoon, `15` Company, `16` Battalion, `17` Regiment, `18` Brigade, `21` Division, `22` Corps. Land Equipment (UGV): mobility `32` Wheeled cross-country, `33` Tracked. Air / Sea: `00` (APP-6 has no echelon there) |
| 11-16 | Entity / Type / Subtype | see **Platform mapping** below |
| 17-18 | Modifier 1 | UGV: `24` Robotic; otherwise `00` |
| 19-20 | Modifier 2 | `00` |
| 21-22 | Modifier 1/2 set | `00` (symbol-set modifiers) |
| 23 | Frame shape | `0` (default) |
| 24-30 | Reserved / country | `0000000` |

The builder lives in `frontend/src/symbology/sidc.ts` and is covered by `sidc.test.ts` (one test per positional guarantee, plus a "milsymbol accepts it" roundtrip for every platform).

## Platform mapping

| Internal `platform_type` | Symbol Set | Entity (pos 11-16) | milsymbol icon |
|---|---|---|---|
| `ROTARY_UAV` | `01` Air | `110400` | Vertical-takeoff UAV (VT-UAV) |
| `FIXED_WING_UAV` | `01` Air | `110300` | Unmanned aerial vehicle (generic) |
| `WHEELED_UGV` | `15` Land Equipment | `140100` | Utility vehicle + Robotic (M1 `24`) + Wheeled cross-country (`32`) |
| `TRACKED_UGV` | `15` Land Equipment | `140100` | Utility vehicle + Robotic (M1 `24`) + Tracked (`33`) |
| `USV` | `30` Sea Surface | `120700` | Unmanned surface water vehicle |
| `FOOT` | `10` Land Unit | `121100` | Infantry |

Entity and modifier codes validated against `node_modules/milsymbol/src/numbersidc/sidc/*.js`. APP-6 has no "UGV" entity, so ground robots are an unarmoured utility vehicle marked *Robotic* (unmanned) with a mobility indicator.

## State mapping (internal → APP-6)

| Internal `state` | `link.kind` | SIDC status (pos 7) | What the operator sees |
|---|---|---|---|
| `S`, `T`, `H`, `M`, `R`, `L` | `ok` | `0` Present | Normal glyph |
| `O` (Offline) | `ok` | `0` Present | Normal glyph, field H reads "Offline" |
| any | `lost` / `unk` | `0` Present | Glyph desaturated via CSS `.mk.lost` (no tactical "destroyed" claim) |
| `G` (Fault) | `ok` | `3` Damaged | APP-6 damage mark (`|` diagonal) |
| `G` (Fault) | `lost` | `3` Damaged | Damage + desaturated |

Battery low and GPS weak are not APP-6 conditions: they are appended to field H as `!` (warning) or `!!` (critical).

## Modifiers passed to milsymbol

Per-symbol construction (`frontend/src/symbology/milmarker.ts`):

| milsymbol option | Source |
|---|---|
| `size` | `34` (map marker); `20-22` in the legend |
| `standard` | `"APP6"` (NATO rendering; D vs E lives in the SIDC version digit) |
| `direction` | `drone.hdg` when `drone.spd > 0` |
| `speed` | `"${round(drone.spd)} km/h"` when `drone.spd > 0` |
| `uniqueDesignation` | `drone.callsign ?? drone.id` |
| `higherFormation` | `drone.higherFormation` (from registry) |
| `additionalInformation` | `STATE_LABEL[drone.state]` plus `!`/`!!` when there is an alert |

The marker is placed with `anchor: "top-left"` and an offset of `-getAnchor()`, so the APP-6 position point (not the SVG box centre) sits on the asset. Rendered SVGs are cached by SIDC + options, and the marker DOM is only rewritten when that key changes. Below zoom 6 on the OSM map, `.far .sym-wrap text` hides the text fields.

## Where the metadata comes from

Each asset's APP-6 metadata lives in Postgres (table `uav`, columns added by migration `0005_add_military_metadata`):

- **Zenoh path**: on first `asset/telemetry` from a new asset, `_telemetry` calls `recorder.register_asset` which inserts a `Uav` row with sensible defaults seeded from the telemetry's `asset_type` (`UAV → ROTARY_UAV`, `UGV → WHEELED_UGV`, `USV → USV`, `DIGITAL_TWIN → ROTARY_UAV`), `affiliation: FRIEND`.
- **Sim path**: `sim.initial_metadata()` is preloaded into the in-memory `AssetRegistry`; rows are lazily materialised in Postgres the first time the operator edits one via `PATCH /admin/uavs/{id}`.
- **Operator edits**: Settings screen → *Assets (APP-6 metadata)* table. Changes persist immediately; the next fleet snapshot (1 s cadence) picks them up.

## Testing

```
cd backend && uv run pytest tests/test_asset_registry.py tests/test_migrations.py tests/test_admin.py
cd frontend && pnpm test
```

Vitest covers the SIDC builder (each position, UGV mobility and Robotic modifier, echelon only on Land Units, milsymbol validity for every platform) and the milmarker renderer (direction, callsign fallback, damage bar, alert badge, cache key).
