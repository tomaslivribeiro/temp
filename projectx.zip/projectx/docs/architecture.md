# Architecture

Diagrams follow the C4 model (levels 1 to 3) plus two dynamic flows. Interactive HTML versions are in [`html/`](html/) (open `html/presentation.html` locally for the guided walkthrough); the PNGs below are static exports.

Key decisions:
- The Backend talks to assets only through the **Transport Port**.
- A **driver** is the part of the Backend that translates between the C2 model and an external protocol (Adapter pattern). Drivers run in-process.
- `C2_DRIVER=sim|zenoh|nato` selects the fleet source at startup. `sim` and Zenoh are implemented; NATO is reserved. The selected driver is recorded in `runtime_configuration` when the database is available; otherwise startup logs a warning.
- **Assets** (X-Verse simulator, real drones) share Zenoh topics on the same network. A Zenoh router for 5G is future work.
- Browser to backend: HTTP and WebSocket. Backend to assets: Zenoh pub/sub.
- The API calls the `FleetService`; adapters implement `FleetPort`. Shared command rules live in `domain`, and `main.py` composes the selected adapter at startup.
- In Zenoh mode, events pass through the event-recorder port to the SQLAlchemy repository and are stored in `mission_event` / `uav`. The simulator keeps its state in memory and does not persist events. Details, ICD mapping and the X-Verse mock: [zenoh-driver.md](zenoh-driver.md).

Record new decisions as short files in `docs/adr/` (for example `0001-drivers-in-process.md`).

## Level 1 - Context
![Level 1 - Context](architecture/images/1-context.png)

## Level 2 - Containers
![Level 2 - Containers](architecture/images/2-containers.png)

## Level 3 - Backend components
![Level 3 - Backend components](architecture/images/3-backend-components.png)

## Dynamic 1 - Goto command
![Goto command](architecture/images/4-goto-command.png)

## Dynamic 2 - UAV events to the browser map
![UAV events](architecture/images/5-uav-events.png)

> Topic names and coordinate fields are illustrative until the ICD in `contracts/icd` is agreed with the X-Verse team.
> The diagrams are generated artifacts; to change them, update the source and re-export both the HTML and the PNG.
