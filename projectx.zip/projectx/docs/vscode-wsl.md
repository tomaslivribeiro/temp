# VS Code with WSL

Use VS Code on Windows with its remote extension to edit and run this project inside Ubuntu on WSL 2. Keep the repository and toolchains in the Linux filesystem, such as `/home/<user>/projectx`, rather than under `/mnt/c` or OneDrive.

Official guides:

- [Install WSL](https://learn.microsoft.com/windows/wsl/install)
- [Developing in WSL with Visual Studio Code](https://code.visualstudio.com/docs/remote/wsl)
- Project-specific Windows, WSL and Docker setup: [windows-wsl-setup.md](windows-wsl-setup.md)

## 1. Install and verify WSL

In PowerShell, install WSL and Ubuntu (administrator permissions may be required):

```powershell
wsl --install -d Ubuntu-22.04
```

Restart if Windows asks, open Ubuntu, and create the Linux user. Verify from PowerShell:

```powershell
wsl --status
wsl --list --verbose
```

The Ubuntu distribution should use WSL version `2`. For installation issues, use the [Microsoft WSL installation guide](https://learn.microsoft.com/windows/wsl/install) and the [project WSL setup](windows-wsl-setup.md).

## 2. Install VS Code and connect to Ubuntu

1. Install VS Code on Windows.
2. In VS Code, install the **WSL** extension (`ms-vscode-remote.remote-wsl`).
3. Open the Ubuntu terminal and navigate to the repository in the Linux filesystem:

```sh
cd ~/projectx
code .
```

The VS Code window should show `WSL: Ubuntu-22.04` in its remote indicator. If the repository is not cloned yet, clone it under `~` from Ubuntu, not into `/mnt/c`.

## 3. Install project tools in the WSL environment

Open a VS Code integrated terminal. Confirm it is an Ubuntu shell, then install the tools and backend environment there:

```sh
sudo apt update
sudo apt install -y git make curl
curl -LsSf https://astral.sh/uv/install.sh | sh
source "$HOME/.local/bin/env"
uv sync --project backend --extra dev
```

Use Docker Desktop with WSL integration enabled, or install Docker Engine inside Ubuntu as described in [windows-wsl-setup.md](windows-wsl-setup.md). Install editor extensions in the **WSL** side when prompted: Python, Ruff, Docker and ESLint.

For running the frontend outside Docker, install Node.js 20 or newer, enable Corepack, and install the frontend packages:

```sh
corepack enable
cd ~/projectx/frontend
pnpm install
pnpm dev
```

For Python analysis, run **Python: Select Interpreter** from the Command Palette and choose:

```text
~/projectx/backend/.venv/bin/python
```

Run commands from the WSL terminal so that Git, Python, Docker and file watchers all use the same Linux-side project:

```sh
cd ~/projectx
make test
make up
```

Open the application from the Windows browser at `http://localhost:5173`; API docs are at `http://localhost:8000/docs`.

## Troubleshooting

- If the VS Code window is not connected to WSL, close it, open Ubuntu, run `cd ~/projectx && code .` again, and confirm the remote indicator.
- If `code` is not found in Ubuntu, reinstall/repair VS Code on Windows and ensure the `code` command is available to WSL; see the [official Remote - WSL guide](https://code.visualstudio.com/docs/remote/wsl).
- If Python extensions are installed only on Windows, use **Install in WSL** from the Extensions view.
- If file watching or builds are slow, move the repository out of `/mnt/c` and into the Ubuntu filesystem.
- If Docker is unavailable in Ubuntu, enable Docker Desktop's WSL integration or follow the Docker Engine instructions in [windows-wsl-setup.md](windows-wsl-setup.md).