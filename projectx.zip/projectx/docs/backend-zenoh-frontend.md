# Backend Commands, Zenoh and Frontend Telemetry

This guide explains how a user command reaches an asset and how asset topic messages become frontend updates. The frontend does not connect to Zenoh: the backend owns the Zenoh session and exposes normalized fleet snapshots over WebSocket.

## End-to-end flow

```mermaid
sequenceDiagram
    participant UI as Frontend
    participant API as FastAPI
    participant Service as FleetService
    participant Driver as ZenohFleet
    participant Transport as ZenohTransport
    participant Asset as Asset / X-Verse

    UI->>API: POST /uavs/{id}/commands
    API->>Service: send_command(id, action, destination)
    Service->>Driver: FleetPort.send(...)
    Driver->>Transport: publish(topic, ICD payload)
    Transport->>Asset: c2/mission/command
    Asset-->>Transport: mission/status, asset/telemetry, ...
    Transport-->>Driver: on_message(topic, payload)
    loop every second
        API->>Service: advance() and snapshot()
        API-->>UI: WebSocket fleet.snapshot
    end
```

Relevant implementation points:

| Concern | Code |
|---|---|
| REST request and response | [`backend/src/c2/api/uavs.py`](../backend/src/c2/api/uavs.py) |
| Application use case and port | [`backend/src/c2/services/fleet.py`](../backend/src/c2/services/fleet.py), [`backend/src/c2/ports/fleet.py`](../backend/src/c2/ports/fleet.py) |
| Shared command rules | [`backend/src/c2/domain/commands.py`](../backend/src/c2/domain/commands.py) |
| Zenoh topics and action mappings | [`backend/src/c2/drivers/zenoh/icd.py`](../backend/src/c2/drivers/zenoh/icd.py) |
| Zenoh command encoding and inbound message mapping | [`backend/src/c2/drivers/zenoh/fleet.py`](../backend/src/c2/drivers/zenoh/fleet.py) |
| Zenoh session, subscriptions and publishing | [`backend/src/c2/drivers/zenoh/transport.py`](../backend/src/c2/drivers/zenoh/transport.py) |
| WebSocket envelope and broadcast | [`backend/src/c2/api/ws.py`](../backend/src/c2/api/ws.py), [`backend/src/c2/main.py`](../backend/src/c2/main.py) |
| Browser WebSocket consumer | [`frontend/src/api/wsClient.ts`](../frontend/src/api/wsClient.ts), [`frontend/src/sim/wsFleetSource.ts`](../frontend/src/sim/wsFleetSource.ts) |

## Sending a command

Select the Zenoh driver and start the mock/stack:

```sh
make mock
```

The frontend submits commands to the REST API. For example, with an asset in a state that allows `goto`:

```sh
curl -X POST http://localhost:8000/uavs/UAV-002/commands \
  -H 'Content-Type: application/json' \
  -d '{"action":"goto","waypoints":[{"lon":-9.3,"lat":38.9},{"lon":-8.9,"lat":39.2}]}'
```

The API returns `202` with a command key when submission succeeds. That acknowledges submission, not execution or completion. Progress arrives later in `fleet.snapshot` messages. The HTTP contract and error codes are also available at `/docs` and in the [API reference](api.md).

### Adding a command

1. Add the public action to the `CommandIn.action` literal in `backend/src/c2/api/uavs.py`.
2. Add valid state/action combinations to `COMMAND_MATRIX` in `backend/src/c2/domain/commands.py`. Keep validation shared so the simulator and Zenoh adapter agree on command eligibility.
3. Add the action-to-ICD mapping to `ACTION_TO_COMMAND` in `backend/src/c2/drivers/zenoh/icd.py`. If the ICD has no signal, the Zenoh adapter currently returns `501`; do not invent a wire command without agreement on the contract.
4. Encode any required ICD fields in `ZenohFleet.send`. Keep HTTP/Pydantic concerns out of the driver and keep Zenoh session operations in `ZenohTransport`.
5. Add or update tests: state validation, the published topic and payload, error behavior, and the driver/mock contract. Run `cd backend && uv run pytest` and `cd backend && uv run ruff check src tests`.

For a `goto`, the UI submits an ordered `waypoints` array. The Zenoh adapter maps the route to a sequence of `MOVE` commands, sending each next leg after the previous mission reports `COMPLETED`. The payload for each leg includes `message_id`, `timestamp_utc`, `mission_id`, `asset_id`, `command`, `priority`, `operator_id`, `destination`, `speed_mps`, and `final_state`. The operator sees one logical goto command, completed only when the last waypoint is reached. The exact ICD mapping lives in code and the [Zenoh driver guide](zenoh-driver.md).

## Receiving asset topics

`ZenohTransport.run` subscribes to the topic expressions in `icd.SUBSCRIBE`. Its callback forwards `(topic, raw_payload)` to `ZenohFleet.on_message`, which decodes JSON and dispatches by topic:

| Topic | Driver handling | Frontend-visible effect |
|---|---|---|
| `asset/telemetry` | Discovers assets and updates position, state, speed, heading, trail, actual route and sensor field of view. | Fields in the next `fleet.snapshot`. |
| `asset/health` | Updates battery, GPS and satellite data for a known asset. | Health fields in the next `fleet.snapshot`. |
| `system/heartbeat` | Updates liveness and offline state for a known asset. | Link/state fields in the next `fleet.snapshot`. |
| `mission/status` | Correlates the `mission_id` and updates command stage or final result. | Command progress in the next `fleet.snapshot`. |

### Actual route

Each telemetry position also feeds the asset's actual route (`c2.domain.actual_route.ActualRoute`), drawn on the
map next to the planned route. It is built from positions only, so it does not depend on how the movement was
commanded:

- It starts at the asset's position when a `goto` is sent, but only replaces the previous route once the asset
  accepts it (a rejected goto keeps the old one). Moving without a goto (for example RTB, also right after a
  completed mission) starts a new one where the asset is.
- A vertex is kept wherever the path stops being straight, beyond `TOLERANCE_M` (5 m). This covers turns at
  waypoints, deviations, a `changeb` and curves inside a single goto. Every reported position stays within the
  tolerance of the drawn line. A route longer than `MAX_VERTICES` (500) merges its least significant vertex
  (the one closest to the line between its neighbours); the origin and the latest vertex are always kept.
- It survives hover after the mission. It is cleared on standby (`S`) or power-off (`O`).

The snapshot carries it as `track` (`[lon, lat]` points, origin first, latest position last). The frontend's local
simulator uses a TypeScript port (`frontend/src/domain/actualRoute.ts`); keep both in sync.

Example telemetry payload (the asset publishes it to `asset/telemetry`):

```json
{
  "timestamp_utc": 1800000000,
  "asset_id": "UAV-002",
  "asset_type": "UAV",
  "position": {
    "latitude_deg": 38.9,
    "longitude_deg": -9.3,
    "altitude_m": 420
  },
  "velocity": {"ground_speed_mps": 15},
  "heading_deg": 90,
  "horizontal_fov": 78,
  "visual_los": 1000,
  "current_state": "MOVING",
  "navigation_mode": "MISSION"
}
```

`ZenohFleet` normalizes ICD fields into the UI fleet model. Do that translation in the driver, not in the WebSocket handler or frontend; the same UI model is used by the simulator and Zenoh adapter.

## Forwarding updates to the browser

The backend sends an initial snapshot when a client connects to `ws://localhost:8000/ws`, then broadcasts a new `fleet.snapshot` about once per second. Each message uses:

```json
{
  "type": "fleet.snapshot",
  "payload": {"t": 1, "drones": [], "cmds": []},
  "ts": "2026-10-23T12:00:00+00:00"
}
```

The frontend `connectWs` client parses the envelope and reconnects after a disconnect. `WsFleetSource` applies only `fleet.snapshot` messages and notifies the UI; it sends commands over HTTP. To expose a new asset value, normalize it in the driver snapshot, update the frontend fleet types/consumer, and add tests at both boundaries. Do not open a Zenoh session in the browser or broadcast raw ICD topics as the frontend contract.

Run the complete stack with `make mock`, then inspect both sides with:

```sh
docker compose logs -f backend xverse-mock
```