# ADR 0001: NATO APP-6 E military symbology on the map

- Status: accepted
- Date: 2026-11-12

## Context

The map drew every asset with the same hand-made icon. An operator could not read affiliation, platform type, status, callsign or higher formation from it, which is what a NATO C2 operator expects.

## Decision

- Render every asset as an APP-6 symbol with [`milsymbol`](https://github.com/spatialillusions/milsymbol) 3.x, built from a 30-digit numeric SIDC (`frontend/src/symbology/sidc.ts`).
- Fix the edition to **APP-6 E** (version `13`). No D/E toggle: milsymbol renders D and E identically for our symbols.
- Data the ICD already carries (`asset_type`, `current_state`, speed, heading, battery, GPS) drives the symbol. Data X-Verse does not know (affiliation, callsign, higher formation, echelon, finer platform type) is operator metadata in the `uav` table, edited via `PATCH /admin/uavs/{id}`. The ICD does not change.
- UGVs have no APP-6 entity of their own: they are Land Equipment *utility vehicle* (`140100`) with the *Robotic* modifier and a wheeled/tracked mobility indicator. Echelon is only encoded for Land Units.
- Operational alerts (battery, GPS) are not APP-6 conditions; they go as text in field H (additional information).

## Consequences

- The frontend bundle grows by about 1.4 MB (uncompressed).
- Adding a platform type touches backend validation, frontend types and the SIDC tables; see [symbology-implementation.md](../symbology-implementation.md#add-a-platform-type).
- Hostile/neutral/unknown are encoded but unused: the C2 only shows its own (friend) assets.

## References

- STANAG 2019 / APP-6 edition E.
- [symbology.md](../symbology.md) (SIDC mapping), [publishing-assets.md](../publishing-assets.md) (how to put an asset on the map).
