# Developer onboarding

On Windows, first follow [windows-wsl-setup.md](windows-wsl-setup.md) (WSL2 + Docker + known problems), then [vscode-wsl.md](vscode-wsl.md) to connect the editor to Ubuntu.

## Prerequisites
- Git
- Docker Desktop with Compose v2 (WSL2 backend on Windows)
- Optional, to run outside Docker: Python 3.12 + [uv](https://docs.astral.sh/uv/), Node 20+ with pnpm (`corepack enable`)
- Optional: `make` (on Windows use Git Bash or WSL, or run the `docker compose` commands directly)

## 1. Get the code
```
git clone https://assets.engine.capgemini.com/local-assets/erd-prt-gec/dspe-digital-sw-product-eng/projectx.git
cd projectx
```
Keep the repo outside OneDrive.

## 2. Configure
```
cp .env.example .env
```
Defaults work for local development. Key variables:

| Variable | Meaning |
|---|---|
| `C2_DRIVER` | Fleet source selected at startup: `sim`, `zenoh`, or `nato` (reserved). Empty (default) = `zenoh` if `ZENOH_CONNECT` is set, otherwise `sim` |
| `C2_SIM_DEVIATIONS` | Simulator only: wind drift and random avoidance manoeuvres (`true` by default, `false` flies straight lines) |
| `C2_SIM_WIND_KM_PER_TICK`, `C2_SIM_WIND_FROM_DEG` | Simulator wind: km per 1 s tick (0 to 0.75, default 0.35) and the direction it blows from (0-359, default 300). Invalid values stop the backend at startup |
| `DATABASE_URL` | PostgreSQL connection |
| `ZENOH_CONNECT` | Zenoh endpoints, e.g. `tcp/10.0.0.5:7447`. Empty with the Zenoh driver = discovery by multicast on the network (avoid with real assets) |
| `VITE_*` | Frontend API, WebSocket and map tiles URLs |

## 3. Run
```
docker compose up --build
```

| Service | URL |
|---|---|
| Frontend | http://localhost:5173 |
| Backend API docs | http://localhost:8000/docs |
| OpenAPI schema | http://localhost:8000/openapi.json |
| PostgreSQL | localhost:5432 |

HTTP endpoint reference and WebSocket message examples: [api.md](api.md).

Map markers follow NATO APP-6: see [symbology.md](symbology.md) for the SIDC mapping and the state-to-status table, [ADR 0001](adr/0001-military-symbology-app6.md) for the design rationale, and [symbology-implementation.md](symbology-implementation.md) for how it is wired and how to show ground vehicles. To publish your own assets to the map over Zenoh, see [publishing-assets.md](publishing-assets.md).

Which command to use (`make up`, `make mock`, `make carla`, `make zenoh`, `make down`) is explained in the [README](../README.md#2-pick-the-command-for-your-role). Settings saved in the Settings screen win over these variables until you press **Reset**.

## 4. Verify
- `http://localhost:8000/health` returns `{"status":"ok"}`
- `http://localhost:8000/db/version` returns the current Alembic revision (migrations ran on startup)
- The top bar shows **Server online** and **WS: connected**

## 5. Daily workflow
```
make test      # backend and frontend tests
make lint
make migrate   # apply DB migrations (also runs automatically when the backend starts)
```
- Branch: `feature/<pbi-id>-<short-name>`; open a merge request; one review required.
- Contracts in `contracts/` change only through a merge request.
- Backend dependencies: `api` -> `services` -> `ports`; `drivers` and `repositories` implement ports, while shared business rules and errors live in `domain`. `main.py` composes adapters during application startup.

## 5.1 WebSocket (backend -> frontend)
- Endpoint: `ws://localhost:8000/ws` (`backend/src/c2/api/ws.py`). The frontend reads it from `VITE_WS_URL` (`frontend/src/api/wsClient.ts`: reconnects with backoff up to 15 s, drops a socket with no fleet snapshot for 10 s, and reports the link state in the top bar; see [api.md](api.md#websocket)).
- Live fleet: `C2_DRIVER=sim` (default) selects the backend simulator (`backend/src/c2/drivers/sim.py`), which broadcasts `fleet.snapshot` every second; the UI (`frontend/src/sim/wsFleetSource.ts`) renders it. Commands go over HTTP: `POST /uavs/{id}/commands` (202; 404 unknown UAV, 409 action not allowed in current state, 422 invalid/missing B) and their progress comes back in the snapshots. Set `VITE_FLEET_SOURCE=local` to run the UI with an in-browser simulator and no backend.
- Every message is `{"type": "...", "payload": {...}, "ts": "<ISO UTC>"}`. Today: `hello` (on connect), `fleet.snapshot`, `server.heartbeat` (every `WS_HEARTBEAT_SECONDS`), `pong` (reply to a client `{"type":"ping"}`), `error`.
- Only origins listed in `C2_CORS_ORIGINS` may connect (browsers do not apply CORS to WebSockets, so the server checks `Origin`).
- To push data from the backend: `await manager.broadcast("uav.position", {...})` (`from c2.api.ws import manager`). Live UAV positions from the driver will use this.
- Quick manual check: in the browser console run `new WebSocket("ws://localhost:8000/ws").onmessage = e => console.log(e.data)`.

## 5.2 Database migrations (Alembic)
Models live in `backend/src/c2/models.py`; migrations in `backend/alembic/versions/`. Run these inside the backend container (`docker compose run --rm backend ...`) or in `backend/` with `uv run`:
```
alembic current                                   # revision applied to the DB (read)
alembic history                                   # all revisions
alembic revision --autogenerate -m "add x table"  # write: generate a migration from model changes
alembic upgrade head                              # apply
alembic downgrade -1                              # roll back one revision
alembic check                                     # fails if models and DB differ
```
Flow for a schema change: edit `models.py` -> `alembic revision --autogenerate -m "..."` -> **review the generated file** -> `alembic upgrade head` -> commit model and migration together.
The API exposes the applied revision at `GET /db/version`. Migration `0003` creates `runtime_configuration`, which records the latest driver selected at startup when the database is available. `tests/test_migrations.py` checks upgrade/downgrade on every test run.
Outside Docker, `DATABASE_URL` must point to `localhost`, e.g. `postgresql+psycopg://c2:c2@localhost:5432/c2`.

## 5.3 Zenoh driver and X-Verse mock
`make mock` runs the stack with the backend fed by Zenoh and the X-Verse mock as the asset side (telemetry in, commands out). Full guide, ICD mapping and persisted events: [zenoh-driver.md](zenoh-driver.md).

## 6. Run outside Docker (optional)
Backend:
```
cd backend
uv sync --extra dev
uv run uvicorn c2.main:app --reload
```
Frontend:
```
cd frontend
pnpm install
pnpm dev
```
You still need PostgreSQL: `docker compose up postgres` (use `localhost` in `DATABASE_URL`).

## Troubleshooting
- **Port in use:** stop the other process or change the port mapping in `docker-compose.yml`.
- **Zenoh peers not discovered from Docker:** multicast is not forwarded on the bridge network. Set `ZENOH_CONNECT=tcp/<host>:7447` (`make mock` does it; see [zenoh-driver.md](zenoh-driver.md)).
- **Hot reload not working on Windows:** keep the repo on the WSL2 filesystem or the local disk.
