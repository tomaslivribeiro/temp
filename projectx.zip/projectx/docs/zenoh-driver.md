# Zenoh driver and X-Verse mock

The backend can take its fleet from **Zenoh** instead of the built-in simulator. The **X-Verse mock** (`tools/xverse-mock`) is a separate process that plays the Asset side of the ICD, so the whole chain can be exercised without X-Verse or CARLA.

```
Browser <-- WebSocket fleet.snapshot --  Backend (FastAPI)  --> PostgreSQL (uav, mission_event)
Browser --- POST /uavs/{id}/commands -->   Zenoh driver
                                              |  c2/mission/command      (publish)
                                              |  asset/telemetry, asset/health,
                                              |  system/heartbeat, mission/status   (subscribe)
                                              v
                                         X-Verse mock  (later: X-Verse + CARLA)
```

## Run it
```
cp .env.example .env     # first time only
make mock                # = C2_DRIVER=zenoh ZENOH_CONNECT=tcp/xverse-mock:7447 VITE_MOCK_CONSOLE_URL=http://localhost:5174 docker compose --profile mock up --build
```
Open http://localhost:5173. Four assets appear (UAV-001..004). In mock mode the top bar shows an **X-Verse mock console ↗** link to http://localhost:5174. Watch the traffic:
```
docker compose logs -f xverse-mock      # <- command ... / -> status ...
docker compose logs -f backend          # asset discovered, zenoh connected
```
Try it: select **UAV-002** (standby at ALFA = Capgemini Lisboa, Torre Colombo), pick a point B close to the base and send **Go to**. At real speed (15 m/s) a 10 km hop takes about 11 minutes; for a faster demo use `MOCK_TIME_SCALE=20 make mock`. The command goes through Sent -> Accepted -> Confirmed -> Executing -> Completed and the marker flies there. **UAV-003** has 22 % battery: the mock answers `REJECTED`. `make up` (no mock) keeps using the built-in simulator.


## Run it with a real X-Verse / CARLA
```
make carla
```
The **passive console** (`MOCK_MODE=passive`, http://localhost:5174) listens on **7447**, the same address the mock used, so CARLA/X-Verse connects to `localhost:7447` as before. The backend connects to the console (`tcp/xverse-console:7447`), so CARLA telemetry shows on the map and commands go out on `c2/mission/command` for CARLA to process. The console simulates nothing (no assets, no replies); it only logs the traffic and lets you publish messages by hand, which also reach the C2.

To use another Zenoh node instead (e.g. a router), set `CARLA_ZENOH`: `CARLA_ZENOH=192.168.1.5 make carla`. It accepts a bare IP/host (`tcp/<ip>:7447`), `host:port` or a full endpoint; the console connects to it too. The node must listen on `0.0.0.0`; check with `nc -vz <ip> 7447`.

**Positions.** CARLA sends its local metres in the ICD fields: `position.latitude_deg` = **X** (east), `position.longitude_deg` = **Y** (south), `altitude_m` = Z. `make carla` sets `C2_POSITION_FORMAT=carla` and the backend converts them to the lon/lat the X-Verse map uses (the floorplan sits in Web Mercator around (0, 0)); a `MOVE` destination is converted back, so CARLA receives X in `latitude_deg` and Y in `longitude_deg`. Conversion: `lon = X / 111319.49`, `lat = -Y / 111319.49` (exact form in `icd.carla_to_lonlat`). Example: X=70.7, Y=133.6 -> lon 0.000635109, lat -0.001200149. With the default `geo` (`make mock`, `make up`) nothing is converted.

## Real drones: `make zenoh`
For a real drone (or any Zenoh node that sends real lat/lon) use:
```
ZENOH_CONNECT=192.168.1.5 make zenoh      # bare host = tcp/<host>:7447; a full endpoint also works
```
It starts only the C2 stack with `C2_DRIVER=zenoh` and `C2_POSITION_FORMAT=geo`. Do not use `make carla` for real drones: it converts positions as CARLA metres. The command fails if `ZENOH_CONNECT` is not set, so the backend never falls back to multicast discovery by accident.

If `C2_DRIVER` is empty, the backend picks `zenoh` when `ZENOH_CONNECT` is set and `sim` otherwise (so `ZENOH_CONNECT=... make up` also works). At startup the backend log prints the driver, endpoint and where the settings came from, and warns when `ZENOH_CONNECT` is set but the driver is `sim`.

**How the UI shows a position.** Each drone in the snapshot has a `frame` field: `local` when `C2_POSITION_FORMAT=carla`, otherwise `geo`. For `local`, the UI converts the map lon/lat back to metres and shows `X 70.7 m, Y 133.6 m` (Position, From A, To B and the new point B). For `geo` it shows `lat, lon`. Without this, a CARLA position near (0, 0) is tiny (1 m is about 0.00001 degrees), so five decimals made it look frozen. `frame` exists only between the backend and the UI. **The Zenoh messages (ICD) are not changed.**

Known limit: `C2_POSITION_FORMAT` is one setting for the whole backend, so CARLA assets and real drones cannot be mixed yet. For that, the source of each asset must say how its position is sent. This changes how assets talk to us, so it needs agreement with the whole team first. Also, "Distance to base" still uses the real bases, so it is not meaningful for CARLA assets.

## Mock developer console (http://localhost:5174)
A page served by the mock itself (`MOCK_CONSOLE_PORT`, default 5174; no extra dependency). It is a debugging aid for C2 developers:
- **Message log**, in chronological order, of everything on Zenoh. Blue rows are C2 -> X-Verse (`c2/mission/command`, `c2/mission/cancel`), green rows are X-Verse -> C2. Each row shows the origin: `mock` (the simulation), `console` (sent by you from the page) or `external` (any other Zenoh peer). Click a row to see the JSON. Telemetry, health and heartbeat are hidden by default (checkbox); you can also filter by direction and free text (asset, mission, topic), pause, and clear. The journal keeps the last 20 000 messages in memory.
- **Publish as X-Verse**: pick a template (`mission/status` ACCEPTED / IN_PROGRESS / COMPLETED / REJECTED / FAILED, telemetry, EMERGENCY, low battery, GPS lost, heartbeat, `asset/event`), choose the asset (the mission id defaults to the last command seen for it), edit the JSON and press **Publish**. The topic and body are sent as is, so you can also test unexpected or inconsistent messages.
- **Assets**: change the battery (below 30 % a MOVE gets `REJECTED`), **mute** an asset to stop its telemetry, health and heartbeat (lost link), and remove it with ✕. **Add asset** creates a new one (id, base, READY on the ground or HOVERING in the air, optional lat/lon/alt/battery); the C2 discovers it on its first telemetry. The next real signal of an unmuted asset overrides what you injected, so to hold a scenario, mute the asset first and then publish. Your own published messages are never hidden by the noise filter.

HTTP API (used by the page): `GET /api/messages?after=<seq>`, `GET /api/state`, `POST /api/publish` (`{"topic", "payload"}`), `POST /api/assets/<id>` (`{"battery", "muted"}`), `POST /api/assets` (create), `DELETE /api/assets/<id>`, `POST /api/clear`. The console has no authentication: it is meant for local development only, do not expose port 5174.

Inspect what was saved:
```
docker compose exec postgres psql -U c2 -d c2 -c "select mission_id, asset_id, kind, name, occurred_at from mission_event order by id;"
docker compose exec postgres psql -U c2 -d c2 -c "select * from uav;"
```

## Mock settings (env)
| Variable | Default | Meaning |
|---|---|---|
| `ZENOH_LISTEN` | `tcp/0.0.0.0:7447` | Where the mock listens (published on host port 7447) |
| `ZENOH_CONNECT` | empty | Optional endpoints the mock connects to |
| `MOCK_TIME_SCALE` | `1` | `1` = real time: the asset flies at the commanded `speed_mps` (15 m/s = 54 km/h by default). Set `N` to compress time, e.g. `MOCK_TIME_SCALE=20 make mock` for quick demos. Reported speed stays the real one |
| `MOCK_SPEED_JITTER` | `0.2` | Speed varies ±20 % around the commanded speed (mean-reverting). The current speed is sent in `asset/telemetry.ground_speed_mps` and in `mission/status.current_speed_mps` (optional extension field, to be agreed with X-Verse). The C2 shows the latest speed received and the map marker dead-reckons from it between 1 s snapshots. `0` = constant speed |
| `MOCK_CONSOLE_PORT` | `5174` | Developer console port |

Default bases are Capgemini Portugal offices: ALFA Lisboa (Torre Colombo), BRAVO Porto (Lake Towers), CHARLIE Évora (Rua da Somefe), DELTA Fundão (Centro de Negócios). Coordinates were geocoded from public addresses; elevations are approximate.

Backend side: `C2_DRIVER=zenoh`, `ZENOH_CONNECT=tcp/<host>:7447`, `C2_OPERATOR_ID`, `C2_DEFAULT_SPEED_MPS`. Docker bridge networks do not forward multicast, so peers are connected by explicit endpoint (PBI-28). The driver keeps retrying until the mock is reachable, so start order does not matter. The selected driver is recorded in `runtime_configuration` at startup; if the database is unavailable, the backend logs a warning and continues. Inspect it with `select id, active_driver, updated_at from runtime_configuration;`.

Running the backend on the host (not in Docker): start the mock with `make mock` (or only `docker compose --profile mock up xverse-mock`) and use `ZENOH_CONNECT=tcp/127.0.0.1:7447`.

## Settings screen (C2 top bar -> Settings)

Lets you point the C2 at another Zenoh node (for example an X-Verse machine on the LAN, `tcp/<ip>:7447`) without editing `.env` or restarting.

| Group | Setting | Env default |
|---|---|---|
| Connection | Driver (`sim`, `zenoh`; `nato` is reserved and rejected), Zenoh endpoints | `C2_DRIVER`, `ZENOH_CONNECT` |
| Identity and mission | Operator ID, default speed (m/s) | `C2_OPERATOR_ID`, `C2_DEFAULT_SPEED_MPS` |
| Monitoring | Seconds before an asset is shown as lost | `C2_LOST_AFTER_S` |

- **Access:** the screen asks for the admin token (`C2_ADMIN_TOKEN`, default `dev-admin` in Compose; empty disables the API). It is sent as the `X-Admin-Token` header and kept only in `sessionStorage`. Change it outside local development: whoever has it can redirect where commands go.
- **API:** `GET/PUT/DELETE /admin/config` and `POST /admin/config/test-zenoh` (see `/docs`).
- **Apply without restart:** saving reconnects the fleet source. Switching driver empties the fleet until assets publish again. Zenoh keeps retrying forever, so a wrong endpoint does not fail the save: use **Test connection** first (it opens a throwaway session and reports how many nodes answered within 4 s).
- **Persistence and precedence:** saved values are stored in `runtime_configuration.settings` and **override the environment** on the next start (the screen shows "Settings from: saved in the database"). **Reset to environment** deletes them. So after saving `zenoh`, `make up` will still start Zenoh until you reset.
- **Explicit endpoints:** when endpoints are set, Zenoh multicast scouting is disabled, so only those nodes are used (the test and the real connection behave the same).

## ICD signals used (PoC)
| Signal | Topic | Direction | Used for |
|---|---|---|---|
| mission_command | `c2/mission/command` | C2 -> Asset | UI action as an ICD command |
| mission_cancel | `c2/mission/cancel` | C2 -> Asset | mock handles it; no UI action yet |
| mission_status | `mission/status` | Asset -> C2 | command stages and result |
| asset_telemetry | `asset/telemetry` | Asset -> C2 | position, state, discovery |
| asset_health | `asset/health` | Asset -> C2 | battery, GPS |
| asset_heartbeat | `system/heartbeat` | Asset -> C2 | liveness (`hb` = seconds since last signal; >= 10 s = link lost) |

Payloads are JSON exactly as written in the ICD; asset ids travel in the payload, not in the topic.

### Mappings (`backend/src/c2/drivers/zenoh/icd.py`, `fleet.py`)
| UI action | ICD command |  | ICD status | UI command stage |
|---|---|---|---|---|
| goto, changeb | `MOVE` (+ destination, `final_state: HOVER`) |  | `RECEIVED` | 1 Accepted |
| hold | `HOLD_POSITION` |  | `ACCEPTED` | 2 Confirmed |
| rtb | `RETURN_HOME` |  | `IN_PROGRESS` | 3 Executing |
| land | `LAND` |  | `COMPLETED` | 4 Completed |
| poweroff | `SHUTDOWN` |  | `REJECTED`, `FAILED`, `ABORTED` | final: rejected |
| takeoff, poweron | none: API answers **501** |  | link lost while pending | final: unknown |

`current_state` -> UI state: `OFFLINE`=O, `READY/PARKED/INITIALIZING`=S, `MOVING`=M (R when `navigation_mode=RETURN_HOME`), `RETURNING_HOME`=R, `HOLDING/HOVERING/LOITERING/MISSION_COMPLETE`=H, `LANDING`=L, `EMERGENCY/FAULT`=G.

## What is persisted
- `uav`: one row the first time an asset is seen (discovery).
- `mission_event` (migration `0002`): every command C2 sends and every status an asset answers with, **once** per `(mission_id, asset_id, kind, name)`. Repeated `IN_PROGRESS` updates are not new events. A database failure is logged and never stops the stream.

## Gaps to raise with X-Verse (the ICD does not cover them yet)
1. **Takeoff / power on**: no signal. Those buttons return 501 in Zenoh mode.
2. **Home / base**: not in any signal. The driver assigns the nearest base known to the UI; `RETURN_HOME` goes to the asset's own home.
3. **Rejection reason**: `mission_status` has no reason field; the UI infers "battery too low" from `asset_health`.
4. **GPS quality / satellites**: only in `asset_health`; the mock always sends 14.
5. **Asset names**: `asset_discovery` (`system/discovery`) is not subscribed yet; the UI shows the `asset_id`.

## Tests
```
cd backend && uv run pytest                                   # includes the driver <-> mock contract test
make test-mock                                                # mock unit tests
```
The contract test feeds the mock's real output into the driver, so the two cannot drift apart silently.

## Swapping the source (NATO later)
`c2/ports/fleet.py` defines `FleetPort` (`snapshot`, `tick`, `send`). The simulator and the Zenoh driver implement it; `main._start_source` selects one using `C2_DRIVER=sim|zenoh`. A NATO driver will be another implementation behind `C2_DRIVER=nato`.
