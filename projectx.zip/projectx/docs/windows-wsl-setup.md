# Windows + WSL2 setup guide

Step-by-step guide to set up a Windows machine to build and run ProjectX with WSL2 (Ubuntu 22.04) and Docker.
It includes the problems we already hit, with their fixes (see [Troubleshooting](#troubleshooting-knowledge-base)).

> Rule of thumb: run everything (git, uv, pnpm, docker, VS Code terminal) **inside Ubuntu**, and keep the repo in the **Linux filesystem** (`~/projectx`), never in `/mnt/c` or OneDrive.

## 1. Install WSL2 and Ubuntu 22.04
PowerShell as administrator:
```
wsl --install -d Ubuntu-22.04
```
Reboot if asked, then open "Ubuntu 22.04" and create your Linux user and password.

Open Ubuntu from PowerShell: `wsl -d Ubuntu-22.04` (or `wsl -d Ubuntu-22.04 --cd ~/projectx`). Restart WSL: `wsl --shutdown`.

## 2. Install base tools (inside Ubuntu)
```
sudo apt update && sudo apt install -y make git curl ca-certificates
curl -LsSf https://astral.sh/uv/install.sh | sh
source $HOME/.local/bin/env
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo corepack enable
```
Check: `uv --version`, `node -v`, `git --version`.

Ubuntu 22.04 ships Python 3.10. The project needs 3.12; `uv` downloads it automatically, so do not install Python with `apt`.

## 3. Install Docker
Choose one.

**A. Docker Desktop** (check your company licence policy): enable *Settings > Resources > WSL integration > Ubuntu-22.04*.

**B. Docker Engine inside Ubuntu** (no Desktop). Do not use `sudo apt install docker.io` or `podman-docker`; use the official packages:
```
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo $VERSION_CODENAME) stable" | sudo tee /etc/apt/sources.list.d/docker.list
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo usermod -aG docker $USER
printf "[boot]\nsystemd=true\n" | sudo tee /etc/wsl.conf
```
Then in **PowerShell**: `wsl --shutdown`. Reopen Ubuntu and test:
```
docker run hello-world
docker compose version
```

## 4. Git access to GitLab
Use SSH so Git never asks for a password:
```
git config --global user.name "Your Name"
git config --global user.email "you@company.com"
ssh-keygen -t ed25519 -C "you@company.com"
cat ~/.ssh/id_ed25519.pub
```
Add the key in GitLab > *Preferences > SSH Keys*, then use the *Clone with SSH* URL.
With HTTPS you must use a Personal Access Token (`read_repository`, `write_repository`) as the password, and `git config --global credential.helper store` to remember it.

## 5. Clone the repo (Linux filesystem)
```
cd ~
git clone <ssh-url-of-projectx> projectx
cd projectx
git checkout <branch>
```

## 6. VS Code
For the VS Code Remote - WSL workflow, see the focused [VS Code with WSL guide](vscode-wsl.md).

1. Install VS Code on Windows and the **WSL** extension.
2. In Ubuntu: `cd ~/projectx && code .`. The bottom-left corner must show **WSL: Ubuntu-22.04**.
3. Install extensions "in WSL": Python, Ruff, Docker, ESLint.
4. Create the backend environment and select it:
```
cd backend
uv sync --extra dev
```
*Ctrl+Shift+P > Python: Select Interpreter > Enter interpreter path* and use `~/projectx/backend/.venv/bin/python` (full path, for example `/home/<user>/projectx/backend/.venv/bin/python`).

Validate: `cd backend && uv run pytest` (2 tests must pass).

## 7. Build and run
```
cd ~/projectx
cp .env.example .env
docker compose up --build
```
| What | URL (from the Windows browser) |
|---|---|
| Frontend | http://localhost:5173 |
| API docs | http://localhost:8000/docs |
| Health | http://localhost:8000/health |

Stop with `Ctrl+C`, remove containers with `docker compose down`. Start the X-Verse mock with `docker compose --profile mock up --build`.

## Troubleshooting (knowledge base)

| Symptom | Cause | Fix |
|---|---|---|
| `uv: command not found` | uv not installed or PATH not loaded | Run the uv installer, then `source $HOME/.local/bin/env`; persist with `echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc` |
| VS Code interpreter list shows only Python 3.10 or 3.15 | No project venv yet, or not detected | Run `uv sync --extra dev --python 3.12` in `backend/`, reload the list, or enter `.../backend/.venv/bin/python` manually. Avoid system 3.10 and 3.15 (too new for `eclipse-zenoh`) |
| `docker: command not found` and Ubuntu suggests `docker.io` / `podman-docker` | Docker not installed | Do not use those. Install Docker Desktop with WSL integration, or the official Docker Engine (section 3B) |
| `permission denied ... /var/run/docker.sock` | User not in the `docker` group in this session | `sudo usermod -aG docker $USER`, then `wsl --shutdown` from PowerShell and reopen. Temporary: `newgrp docker` |
| Git asks for user and password on every command | Remote uses HTTPS | Switch to SSH: `git remote set-url origin <ssh-url>`; or HTTPS + token + `credential.helper store` |
| `docker compose up` fails with `ERR_PNPM_IGNORED_BUILDS ... esbuild` | pnpm 10+ blocks dependency build scripts by default | The project pins `"packageManager": "pnpm@9.15.9"` in `frontend/package.json`. Make sure it is present and rebuild |
| Backend build shows `CANCELED` | Compose cancels parallel builds when another one fails | Fix the real `ERROR` (for example the frontend) and run again; the backend is not the cause |
| Hot reload is slow or does not work | Repo in `/mnt/c` or OneDrive | Clone inside `~` (Linux filesystem) |
| Zenoh peers not discovered from containers | Multicast is not forwarded by Docker bridge/WSL | Use host networking or set `ZENOH_CONNECT` with explicit endpoints (PBI-28) |
| Shell prompt shows `(c2)` or `(.venv)` | A Python venv is active in the terminal | Harmless for Docker; run `deactivate` if confusing |
| `wsl --install` shows "no installed distribution" | No distro yet | `wsl --list --online`, then `wsl --install -d Ubuntu-22.04` |

## Handy commands
```
wsl -d Ubuntu-22.04            # open Ubuntu from PowerShell
wsl --shutdown                 # restart WSL (apply group or wsl.conf changes)
docker compose logs -f backend # follow backend logs
docker compose down -v         # stop and remove containers and the database volume
```

## Adding to this guide
Hit a new problem? Add a row to the Troubleshooting table with symptom, cause and fix, in the same merge request that fixes it.
