# APP-6 E military symbology: technical implementation

How NATO APP-6 E symbology is implemented in the C2, how to use it, and how to show ground vehicles or add new platform types. The decision is in [ADR 0001](adr/0001-military-symbology-app6.md); the SIDC code table is in [symbology.md](symbology.md).

## Overview

Every asset on the map is drawn as a NATO APP-6 E symbol, generated in the browser by [milsymbol](https://github.com/spatialillusions/milsymbol) 3.0.5 from a 30-digit SIDC (Symbol Identification Code). The military metadata (affiliation, platform type, callsign, higher formation, echelon) lives in the backend, in the `uav` table, and reaches the frontend inside the fleet snapshot.

The ICD with X-Verse does not change. Telemetry still carries only `asset_type` (`UAV`, `UGV`, `USV`, `DIGITAL_TWIN`), which only decides the initial platform type. Everything else belongs to the C2 and is edited by the operator.

Data path, on every 1 s tick:

```mermaid
flowchart LR
  subgraph Backend["Backend (FastAPI)"]
    driver["Driver (sim / zenoh)<br/>snapshot: t, drones, cmds"]
    fleet["FleetService.snapshot()<br/>adds metadata to each drone"]
    ws["WebSocket /ws<br/>fleet.snapshot every 1 s"]
    table["uav table<br/>affiliation, platform_type…"]
    registry["AssetRegistry<br/>cache: get, preload, upsert"]
    admin["Admin API<br/>GET / PATCH /admin/uavs"]
    driver --> fleet --> ws
    driver -- "first sighting (Zenoh)" --> table
    table --> registry --> fleet
    admin --> registry
  end
  subgraph Frontend["Frontend (React + MapLibre)"]
    map["MapView<br/>one marker per drone"]
    build["buildMilsymbol<br/>SIDC + fields T, M, H, Z, Q"]
    ms["milsymbol<br/>SVG inside the MapLibre marker"]
    map --> build --> ms
  end
  ws --> map
```

The driver produces the snapshot, `FleetService` adds the `AssetRegistry` metadata to it, and the browser only turns each drone into a SIDC and an SVG. The `uav` table receives data from two places: the first Zenoh sighting and the admin API.

## Backend

The metadata are columns of the `uav` table, read through a cached registry and merged into the snapshot by `FleetService`.

### Data model (migration `0005`)

| Column | Type | Default | Values |
| --- | --- | --- | --- |
| `affiliation` | `String(16)`, not null | `FRIEND` | `FRIEND`, `HOSTILE`, `NEUTRAL`, `UNKNOWN` |
| `platform_type` | `String(32)` | backfilled from `domain` | `ROTARY_UAV`, `FIXED_WING_UAV`, `WHEELED_UGV`, `TRACKED_UGV`, `USV`, `FOOT` |
| `callsign` | `String(64)` | `NULL` (falls back to `id`) | free text |
| `higher_formation` | `String(64)` | `NULL` | free text |
| `echelon` | `String(16)` | `NULL` | `TEAM` … `CORPS` |

Existing rows are backfilled as: `air` → `ROTARY_UAV`, `ground` → `WHEELED_UGV`, `water` → `USV`, anything else → `ROTARY_UAV`.

### `AssetRegistry` (`backend/src/c2/services/asset_registry.py`)

- `get(asset_id)`: returns the cached `AssetMetadata`. On a miss it reads the row from the DB and caches it. With no row it returns `DEFAULT` (FRIEND, ROTARY_UAV) without caching, so the row is picked up once it is created.
- `preload(entries)`: fills the cache without touching the DB. The simulator uses it.
- `upsert(asset_id, **fields)`: writes to the DB and invalidates the entry. If the row does not exist (a sim asset) it creates one from the cached values.
- `all()`: merges the DB rows with entries that only exist in the cache.
- With no `engine` it works in memory only.

The instance is created in `main.py` (`AssetRegistry(db.engine)`) and passed to `Runtime`, which exposes it as `runtime.registry` and hands it to `FleetService`.

### Snapshot enrichment (`backend/src/c2/services/fleet.py`)

`FleetService.snapshot()` runs `drone.update(meta.to_snapshot())` for every drone. The fields reach the frontend in camelCase:

```json
{"id": "GAMA", "state": "H", "lon": -9.14, "lat": 38.72,
 "affiliation": "FRIEND", "platformType": "ROTARY_UAV",
 "callsign": "GAMA", "higherFormation": "1 ESQAV", "echelon": "SECTION"}
```

### Where the platform type comes from

- **Zenoh**: on an asset's first telemetry, `ZenohFleet` calls `register_asset(id, asset_type, base)`. `SqlAlchemyFleetEventRepository.ensure_uav` creates the row with `platform_type` mapped from `asset_type`: `UAV` → `ROTARY_UAV`, `UGV` → `WHEELED_UGV`, `USV` → `USV`, `DIGITAL_TWIN` → `ROTARY_UAV`. This only happens when the row is created; afterwards only the operator changes the value.
- **Sim**: `sim.initial_metadata()` gives the 10 assets FRIEND, ROTARY_UAV, a callsign equal to the name, `1 ESQAV` and `SECTION`. `Runtime._build` loads them with `preload` whenever the `sim` driver is built.

## Frontend

The symbol is built in two steps: `buildSidc` turns the metadata into a 30-digit code, and `buildMilsymbol` passes that code and the text fields to `milsymbol`.

### SIDC (`frontend/src/symbology/sidc.ts`)

| Positions | Field | Value |
| --- | --- | --- |
| 1-2 | Version | `13` (APP-6 E), fixed |
| 3 | Context | `0` (reality) |
| 4 | Standard identity (affiliation) | `3` Friend, `6` Hostile, `4` Neutral, `1` Unknown |
| 5-6 | Symbol set | `01` Air, `10` Land unit, `15` Land equipment, `30` Sea surface |
| 7 | Status | `0` Present, `1` Planned, `3` Damaged, `4` Destroyed |
| 8 | HQ / TF / Dummy | `0` |
| 9-10 | Echelon / mobility | `FOOT`: echelon (`11` Team … `22` Corps); UGV: mobility (`32` wheeled, `33` tracked); everything else `00` |
| 11-16 | Entity | per platform (table below) |
| 17-18 | Modifier 1 | UGV: `24` Robotic; everything else `00` |
| 19-30 | Modifier 2, extensions, frame shape, reserved | zeros |

| `platformType` | Symbol set | Entity | FRIEND frame |
| --- | --- | --- | --- |
| `ROTARY_UAV` | `01` Air | `110400` VT-UAV | dome |
| `FIXED_WING_UAV` | `01` Air | `110300` UAV | dome |
| `WHEELED_UGV` | `15` Land equipment | `140100` utility vehicle + Robotic + wheeled | circle |
| `TRACKED_UGV` | `15` Land equipment | `140100` utility vehicle + Robotic + tracked | circle |
| `USV` | `30` Sea surface | `120700` USV | circle |
| `FOOT` | `10` Land unit | `121100` infantry | rectangle |

Frames and codes were checked against the installed `milsymbol` (`isValid()` and `getMetadata().mobility`). APP-6 has no "UGV" entity: an unarmoured utility vehicle is used, with the *Robotic* modifier (unmanned) and the mobility indicator below the symbol.

### Status (`frontend/src/symbology/status.ts`)

- C2 state `G` (fault) → status `DAMAGED` (damage mark on the symbol).
- Everything else → `PRESENT`.
- Lost or unknown link: the symbol stays `PRESENT`; the marker's `.lost` class fades it (opacity 0.55, saturation 0.35).

### Text fields (`frontend/src/symbology/milmarker.ts`)

| APP-6 field | milsymbol option | Value | Air | Ground (equipment) |
| --- | --- | --- | --- | --- |
| T | `uniqueDesignation` | `callsign ?? id` | right, 1st line | left |
| M | `higherFormation` | `higherFormation` | not drawn | right |
| H | `additionalInformation` | state label + `!`/`!!` when there is an alert | right, 5th line | right |
| Z | `speed` | `"65 km/h"`, only if `spd > 0` | right, 4th line | left |
| Q | `direction` | `hdg`, only if `spd > 0` | arrow | arrow |

Positions are the ones `milsymbol` defines in `src/symbolfunctions/textfields.js`. The Air layout is a simplification in the library (there is a TODO in its code). The alert badge uses `alertsOf`/`maxSeverity` from `domain/link.ts`, the same functions as the fleet list.

### Map and legend

- `MapView.tsx` puts only `<span class="sym-wrap">{svg}</span>` in the marker. The old C2 label (`.mk-lb`) was removed.
- The marker uses `anchor: "top-left"` and `setOffset(-anchor)`, so the APP-6 position point sits on the asset's position even when text fields or the arrow change the SVG size.
- `buildMilsymbol` returns a `key` (SIDC + fields) and caches the SVGs; `MapView` only rewrites the marker when the `key` changes (hover and selection no longer regenerate symbols).
- Below zoom 6 on the OSM map, the `.far` class hides the text fields (`.sym-wrap text`), leaving only the symbol and the arrow.
- `SymbologyLegend.tsx` shows five FRIEND examples in the map corner: rotary, fixed-wing, UGV, USV and a damaged rotary.
- `VITE_FLEET_SOURCE=local` (in-browser simulator) sends no metadata, so every asset appears with the defaults (FRIEND, ROTARY_UAV, id as designation).

## How to use

The operator edits the metadata in the Settings screen; scripts and integrations use the admin API. Changes show on the map in the next snapshot (about 1 s).

### In the Settings screen

1. Top bar → **Settings**.
2. Enter the admin token (`C2_ADMIN_TOKEN`, default `dev-admin`) → **Unlock**.
3. **Assets (APP-6 metadata)** card: one row per asset, with platform, callsign, higher formation and echelon.
4. Each field saves on blur. There is no need to click **Save and apply**.

Until the PATCH bug is fixed, only `callsign` and `echelon` save from this screen (see [Known limitations](#known-limitations)).

### Through the admin API

All routes require the `X-Admin-Token` header. The PATCH body uses snake_case.

```bash
# List assets and metadata
curl -s -H 'X-Admin-Token: dev-admin' http://localhost:8000/admin/uavs

# Change platform, callsign and higher formation of an asset
curl -s -X PATCH -H 'X-Admin-Token: dev-admin' -H 'Content-Type: application/json' \
  -d '{"platform_type": "WHEELED_UGV", "callsign": "BRAVO-1", "higher_formation": "2 CMDT"}' \
  http://localhost:8000/admin/uavs/GAMA
```

| Response | When |
| --- | --- |
| `200` + the updated record | success |
| `422` | value not allowed (`affiliation`, `platform_type`, `echelon`) or text longer than 64 characters |
| `401` / `503` | wrong token / admin API disabled (`C2_ADMIN_TOKEN` empty) |

Interactive documentation is at `http://localhost:8000/docs`, Admin section.

## Showing ground vehicles and other types

For an asset to appear as a UGV, its `platform_type` must be `WHEELED_UGV` or `TRACKED_UGV`. No code change is needed: these types already exist end to end. There are three ways, depending on where the asset comes from.

### 1. Real asset or digital twin (Zenoh)

X-Verse publishes `asset_type: "UGV"` in telemetry (`asset/telemetry`). The first time the asset appears, its `uav` row is created with `domain = ground` and `platform_type = WHEELED_UGV`. A tracked UGV then needs a PATCH to `TRACKED_UGV`.

To test with the mock (`make mock`):

- The mock always publishes `"asset_type": "UAV"` (`tools/xverse-mock/xverse_mock/world.py`, lines 318 and 350). To generate UGVs, that value has to be made configurable per asset.
- Alternatively, publish telemetry from the mock console (`:5174`) with `asset_type: "UGV"` and a new `asset_id`.

The `asset_type` mapping only applies when the row is **created**. An asset already registered as a UAV does not change by itself if X-Verse starts sending `UGV`; use the PATCH in that case.

### 2. Any already registered asset (PATCH)

```bash
curl -s -X PATCH -H 'X-Admin-Token: dev-admin' -H 'Content-Type: application/json' \
  -d '{"platform_type": "TRACKED_UGV"}' http://localhost:8000/admin/uavs/UGV-01
```

In the Settings screen this only works once the camelCase/snake_case bug is fixed (see [Known limitations](#known-limitations)).

### 3. Simulator

Edit `initial_metadata()` in `backend/src/c2/drivers/sim.py`, for example:

```python
GROUND = {"ZARCO", "CABRAL"}

def initial_metadata() -> dict[str, AssetMetadata]:
    return {
        name: AssetMetadata(
            affiliation="FRIEND",
            platform_type="WHEELED_UGV" if name in GROUND else "ROTARY_UAV",
            callsign=name, higher_formation="1 ESQAV",
            echelon=None if name in GROUND else "SECTION",
        )
        for name in (...)
    }
```

The simulator still moves these assets like drones (altitude, takeoff). Only the symbol changes.

### What changes on the map

| | UAV | UGV | USV |
| --- | --- | --- | --- |
| FRIEND frame | dome | circle | circle |
| T (callsign) | right | left | left |
| M (higher formation) | not shown | right | right |
| H (state + alert) | right | right | right |
| Z (speed) | right | left | left |

**Echelon:** in APP-6, echelon only applies to units (`FOOT`). It is ignored for UAV and USV; for UGVs, positions 9-10 carry the mobility indicator (wheeled or tracked, from `platformType`), so a stored echelon does not change the symbol.

### Other affiliations

`affiliation` accepts `HOSTILE`, `NEUTRAL` and `UNKNOWN` through the PATCH, and the SIDC already encodes them (diamond, square, clover). The Settings table does not have this field yet, and there is no source of external tracks: C2 assets are FRIEND by definition.

## Add a platform type

A new type (for example `QUADRUPED_UGV` or `LOITERING_MUNITION`) touches six places. The list of values is repeated in several files and there is no single source.

1. **Choose the APP-6 E code**: the symbol set (positions 5-6) and the entity (11-16). Check that `milsymbol` draws it: `new ms.Symbol(sidc).isValid()` and look at the SVG.
2. **Backend, allowed values**: add it to `PlatformType` and `PLATFORMS` in `backend/src/c2/services/asset_registry.py`. The PATCH validates against this tuple. No migration is needed: the column is `String(32)` with no constraint.
3. **Backend, first sighting** (only if there is a new ICD `asset_type`): add it to `PLATFORMS` and `DOMAINS` in `backend/src/c2/repositories/events.py`. A new `asset_type` in the ICD has to be agreed with X-Verse.
4. **Frontend, types**: add it to `PlatformType` in `frontend/src/symbology/sidc.ts`, `frontend/src/domain/types.ts` and `UavAdminRecord` in `frontend/src/api/client.ts`.
5. **Frontend, codes**: add the type to `SYMBOL_SET` and `ENTITY_CODE` in `sidc.ts` (and to `MODIFIER_1` / `MOBILITY` for land equipment), and to `PLATFORM_OPTIONS` in `SettingsView.tsx` so it appears in the select.
6. **Tests and docs**: add the case to `sidc.test.ts` ("maps every platform type" and "produces SIDCs that milsymbol accepts"), the row in `docs/symbology.md` and, if it makes sense, an entry in `SymbologyLegend.tsx`.

A new affiliation or echelon follows the same path, with `AFFILIATION_DIGIT` / `ECHELON_DIGITS` in `sidc.ts` and `AFFILIATIONS` / `ECHELONS` in `asset_registry.py`.

## Known limitations

The first three affect the Assets table in Settings and are the most urgent.

- [ ] The PATCH ignores `platformType` and `higherFormation` coming from Settings: the frontend sends camelCase and the backend expects snake_case, and Pydantic drops unknown fields with a `200`. Through the API (snake_case) it works.
- [ ] The PATCH cannot clear fields: `null` values are dropped before the `upsert`.
- [ ] Sim mode: `preload` runs on every `_build` and overrides edits saved in the DB, after a restart or "Save and apply".
- [ ] The registry cache is not cleared when the driver is swapped: in Zenoh mode, `GET /admin/uavs` still lists the sim assets.
- [ ] Editing a sim asset creates a `uav` row, although persistence was reserved for Zenoh mode.
- [ ] The alert badge in field H is text (`!`/`!!`) and has no colour.
- [ ] While a Zenoh asset has no DB row, every tick runs a synchronous `SELECT` inside the async loop.
- [ ] `milsymbol` adds about 1.4 MB (uncompressed) to the bundle.
