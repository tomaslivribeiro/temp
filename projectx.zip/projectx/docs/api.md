# API Reference

The backend generates its OpenAPI 3 schema from the FastAPI route and Pydantic model definitions. Use:

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`
- OpenAPI JSON: `http://localhost:8000/openapi.json`

The generated OpenAPI describes HTTP endpoints. The `/ws` WebSocket contract is documented below because OpenAPI does not define WebSocket operations.

For the implementation flow from REST commands through Zenoh to frontend snapshots, see [Backend Commands, Zenoh and Frontend Telemetry](backend-zenoh-frontend.md).

## HTTP

### `GET /health`

Checks whether the API process responds. It does not check database or Zenoh connectivity.

Successful response (`200`):

```json
{"status":"ok"}
```

### `GET /version`

Returns the API version and active fleet source. `sim` means the in-memory simulator; `zenoh` means the Zenoh adapter. The selection is configured with `C2_DRIVER` and its latest startup value is persisted in `runtime_configuration`.

Successful response (`200`):

```json
{"version":"0.1.0","driver":"sim"}
```

### `GET /db/version`

Returns the Alembic revision currently applied to the configured database. A `null` revision means that the database has not been migrated yet.

Successful response (`200`):

```json
{"revision":"0002"}
```

Error response (`503`): database unavailable.

```json
{"detail":"database unavailable"}
```

### `POST /uavs/{uav_id}/commands`

Submits a command to a known UAV. The `202 Accepted` response means the command was submitted; it does not mean the UAV completed it. Progress and final state arrive through `fleet.snapshot` WebSocket messages.

Request body:

```json
{"action":"goto","b":{"lon":-9.14,"lat":38.72}}
```

Supported actions: `poweron`, `takeoff`, `goto`, `changeb`, `hold`, `rtb`, `land`, `poweroff`. `b` is required by `goto` and `changeb`. Coordinates are longitude and latitude in decimal degrees (WGS 84).

Successful response (`202`):

```json
{"key":1}
```

Possible errors use the standard FastAPI error response shape:

| Status | Meaning |
|---|---|
| `404` | UAV identifier is unknown. |
| `409` | Command is not allowed in the UAV's current state. |
| `422` | Request validation failed or a required destination is missing. |
| `501` | Active driver does not implement the requested command. |
| `503` | Fleet transport is unavailable; command was not sent. |

```json
{"detail":"unknown UAV UAV-999"}
```

## WebSocket

Connect to `ws://localhost:8000/ws`. The server checks the browser `Origin` against `C2_CORS_ORIGINS`. Messages share this envelope:

```json
{"type":"hello","payload":{"driver":"sim"},"ts":"2026-10-23T12:00:00+00:00"}
```

| Type | Direction | Payload |
|---|---|---|
| `hello` | server to client, on connect | Active `driver`. |
| `fleet.snapshot` | server to client, on connect and every second | `t`, `drones`, and `cmds`; snapshot shape is consumed by the frontend. Each drone has `frame` (`geo` or `local`): it tells the UI to show lat/lon or CARLA metres (see [Zenoh driver](zenoh-driver.md)). It also has `track`, the actual route flown (see [Actual route](backend-zenoh-frontend.md#actual-route)). |
| `server.heartbeat` | server to client, every `WS_HEARTBEAT_SECONDS` | Connected WebSocket `clients` count. |
| `ping` | client to server | Empty object. |
| `pong` | server to client | Empty object, in response to `ping`. |
| `error` | server to client | `detail`, for example invalid JSON. |

Client heartbeat example:

```json
{"type":"ping","payload":{}}
```

The server currently accepts `ping`; UAV commands are sent over HTTP rather than through the WebSocket.

The frontend client (`frontend/src/api/wsClient.ts`) reconnects with exponential backoff (1 s, 2 s, 4 s ... up to 15 s, ±20%) and treats a socket with no `fleet.snapshot` for 10 s as dead, so a half-open link or a dead feed also recovers (`server.heartbeat` does not count). Coming back online or to the tab retries at once, also replacing a socket quiet for 3 s. Every new connection receives a full `fleet.snapshot`, and the link only counts as connected (and the attempts reset) once it arrives. The top bar shows the state: `connected`, or for the whole outage `disconnected · retry in Ns (attempt N)` / `disconnected · retrying now (attempt N)`, plus the age of the last fleet data. While not connected, commands are blocked and each UAV's telemetry age keeps growing, so it goes to `Delayed` and `No contact`.