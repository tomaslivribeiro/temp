# Contracts

Shared contracts for the backend, frontend and the X-Verse team. Change only through a merge request.

| File | Purpose | Status |
|---|---|---|
| Backend `/openapi.json` | Generated OpenAPI 3 schema for implemented HTTP endpoints; interactive docs at `/docs` | Available |
| `../docs/api.md` | HTTP endpoint usage and WebSocket messages (`type`, `payload`, `ts`) | Available |
| `icd/` | Zenoh topics and message fields shared with X-Verse | PBI-09 |

The FastAPI application is the source of truth for HTTP schemas. The WebSocket contract is documented separately because OpenAPI does not describe WebSocket operations.
