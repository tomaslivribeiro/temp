import json

import pytest
from xverse_mock.console import Hub, validate_publish
from xverse_mock.world import World


def test_hub_orders_messages_and_tags_direction_and_noise():
    hub = Hub()
    hub.record("c2/mission/command", b'{"asset_id": "UAV-001"}')
    hub.record("asset/telemetry", b'{"asset_id": "UAV-001"}')
    first, second = hub.since()
    assert (first["seq"], first["direction"], first["noise"]) == (1, "c2->xverse", False)
    assert (second["seq"], second["direction"], second["noise"]) == (2, "xverse->c2", True)
    assert [i["seq"] for i in hub.since(after=1)] == [2]


def test_hub_attributes_loopback_to_the_publisher_once():
    hub = Hub()
    raw = json.dumps({"a": 1}).encode()
    hub.expect("mission/status", raw, "console")
    assert hub.record("mission/status", raw)["origin"] == "console"
    assert hub.record("mission/status", raw)["origin"] == "external"


def test_hub_keeps_non_json_payload_as_text_and_drops_oldest():
    hub = Hub(capacity=2)
    hub.record("x", b"not json")
    hub.record("x", b"{}")
    hub.record("x", b"{}")
    assert [i["seq"] for i in hub.since()] == [2, 3]
    assert Hub().record("x", b"not json")["payload"] == "not json"


def test_validate_publish_accepts_object_and_rejects_bad_input():
    assert validate_publish({"topic": "mission/status", "payload": {"a": 1}}) == (
        "mission/status",
        b'{"a": 1}',
    )
    for bad in ({"topic": "", "payload": {}}, {"topic": "a b", "payload": {}}, {"topic": "a"}, []):
        with pytest.raises(ValueError):
            validate_publish(bad)


def test_add_asset_defaults_to_the_base_and_validates():
    w = World()
    assert w.add_asset({"id": "uav-005", "base": "bravo"}) == "UAV-005"
    a = w.assets["UAV-005"]
    assert (a.lon, a.lat, a.state, a.battery) == (-8.6392, 41.1415, "READY", 100)
    topics = [p["asset_id"] for t, p in w.step(1.0, 1000) if t == "asset/telemetry"]
    assert "UAV-005" in topics
    for bad in ({"id": "UAV-005"}, {"id": "x"}, {"id": "UAV-9", "base": "ZULU"}, {"id": "UAV-9", "lat": 120}):
        with pytest.raises(ValueError):
            w.add_asset(bad)
    assert w.remove_asset("UAV-005") and not w.remove_asset("UAV-005")


def test_console_messages_are_never_hidden_as_noise():
    hub = Hub()
    raw = b'{"asset_id": "UAV-001"}'
    hub.expect("system/heartbeat", raw, "console")
    assert hub.record("system/heartbeat", raw)["noise"] is False
    assert hub.record("system/heartbeat", raw)["noise"] is True


def test_speed_varies_around_the_commanded_speed_and_is_reported_in_status():
    w = World(time_scale=1, speed_jitter=0.2, seed=1)
    dest = {"latitude_deg": 39.5, "longitude_deg": -8.0, "altitude_m": 300}
    w.handle_command({"mission_id": "M", "asset_id": "UAV-002", "command": "MOVE",
                      "destination": dest, "speed_mps": 15}, 1000)
    speeds = []
    for i in range(60):
        for topic, p in w.step(1.0, 1001 + i):
            if topic == "mission/status" and p["status"] == "IN_PROGRESS":
                speeds.append(p["current_speed_mps"])
    assert len(set(speeds)) > 10
    assert all(15 * 0.8 <= s <= 15 * 1.2 for s in speeds)


def test_speed_is_constant_without_jitter():
    w = World(time_scale=1)
    dest = {"latitude_deg": 39.5, "longitude_deg": -8.0, "altitude_m": 300}
    w.handle_command({"mission_id": "M", "asset_id": "UAV-002", "command": "MOVE",
                      "destination": dest, "speed_mps": 15}, 1000)
    speeds = {p["current_speed_mps"] for i in range(10) for t, p in w.step(1.0, 1001 + i)
              if t == "mission/status" and p["status"] == "IN_PROGRESS"}
    assert speeds == {15.0}


def test_muted_asset_stops_publishing_signals_but_keeps_state():
    w = World()
    assert w.tweak("UAV-001", battery=15, muted=True)
    topics = [p["asset_id"] for t, p in w.step(1.0, 1000) if t == "system/heartbeat"]
    assert "UAV-001" not in topics and len(topics) == 3
    assert next(a for a in w.describe() if a["id"] == "UAV-001")["battery"] < 15.1
    assert not w.tweak("NOPE", muted=True)
