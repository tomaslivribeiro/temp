from xverse_mock.world import MIN_MISSION_BATTERY, World


def command(asset: str, name: str, **extra):
    return {"mission_id": "MIS-1", "asset_id": asset, "command": name, **extra}


def statuses(msgs):
    return [p["status"] for t, p in msgs if t == "mission/status"]


def run(world: World, until, limit=300):
    out = []
    for i in range(limit):
        out += world.step(1.0, 1000 + i)
        if until(out):
            return out
    raise AssertionError("condition not reached")


def test_publishes_telemetry_health_and_heartbeat_for_every_asset():
    topics = [t for t, _ in World().step(1.0, 1000)]
    for t in ("asset/telemetry", "asset/health", "system/heartbeat"):
        assert topics.count(t) == 4


def test_telemetry_includes_horizontal_fov_and_visual_los():
    telemetry = [payload for topic, payload in World().step(1.0, 1000) if topic == "asset/telemetry"]
    assert telemetry
    assert all(payload["horizontal_fov"] == 78 for payload in telemetry)
    assert all(payload["visual_los"] == 1000 for payload in telemetry)


def test_move_goes_received_accepted_in_progress_completed():
    w = World(time_scale=100)
    dest = {"latitude_deg": 38.9, "longitude_deg": -9.3, "altitude_m": 150}
    seen = statuses(w.handle_command(command("UAV-002", "MOVE", destination=dest), 1000))
    seen += statuses(run(w, lambda out: "COMPLETED" in statuses(out)))
    assert seen[:2] == ["RECEIVED", "ACCEPTED"]
    assert "IN_PROGRESS" in seen and seen[-1] == "COMPLETED"
    a = w.assets["UAV-002"]
    assert (a.state, round(a.lat, 1)) == ("HOVERING", 38.9)


def test_move_is_rejected_when_battery_is_low():
    w = World()
    dest = {"latitude_deg": 38.0, "longitude_deg": -8.0}
    assert w.assets["UAV-003"].battery < MIN_MISSION_BATTERY
    w.handle_command(command("UAV-003", "MOVE", destination=dest), 1000)
    assert "REJECTED" in statuses(w.step(1.0, 1001))


def test_return_home_lands_in_ready_at_base():
    w = World(time_scale=1000)
    w.handle_command(command("UAV-001", "RETURN_HOME"), 1000)
    run(w, lambda out: "COMPLETED" in statuses(out))
    a = w.assets["UAV-001"]
    assert a.state == "READY" and a.alt == a.home[2]


def test_unknown_asset_is_ignored_and_cancel_aborts():
    w = World(time_scale=10)
    assert w.handle_command(command("NOPE", "MOVE"), 1000) == []
    dest = {"latitude_deg": 41.0, "longitude_deg": -8.0}
    w.handle_command(command("UAV-001", "MOVE", destination=dest), 1000)
    w.step(1.0, 1001)
    out = w.handle_cancel({"mission_id": "MIS-1", "asset_id": "UAV-001"}, 1002)
    assert statuses(out) == ["ABORTED"] and w.assets["UAV-001"].state == "HOVERING"


def test_world_without_assets_stays_silent_and_ignores_commands():
    world = World(assets=[])
    assert world.step(1.0, 0.0) == []
    assert world.handle_command(command("UAV-001", "MOVE"), 0.0) == []
