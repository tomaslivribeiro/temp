"""World model of the X-Verse mock. No Zenoh in here, so it can be unit tested.

The mock plays the Asset side of the ICD: it publishes telemetry, health and heartbeat for a few
assets, consumes `c2/mission/command` and answers with `mission/status`. Movement is time compressed
by `time_scale` so a demo flight across the country takes seconds, not hours.
"""

import math
import random
import re
from dataclasses import dataclass
from typing import Any

TOPIC_COMMAND = "c2/mission/command"
TOPIC_CANCEL = "c2/mission/cancel"
TOPIC_STATUS = "mission/status"
TOPIC_TELEMETRY = "asset/telemetry"
TOPIC_HEALTH = "asset/health"
TOPIC_HEARTBEAT = "system/heartbeat"

MIN_MISSION_BATTERY = 30
CLIMB_PER_STEP_M = 60.0
DESCENT_PER_STEP_M = 80.0
AIRBORNE = {"MOVING", "HOVERING", "HOLDING", "LOITERING", "LANDING"}

# Same bases the C2 UI knows (lon, lat, elevation m).
BASES = {
    # Capgemini Portugal offices (same as the C2): ALFA Lisboa, BRAVO Porto, CHARLIE Evora, DELTA Fundao.
    "ALFA": (-9.1869, 38.7542, 100.0),
    "BRAVO": (-8.6392, 41.1415, 30.0),
    "CHARLIE": (-7.9008, 38.5640, 280.0),
    "DELTA": (-7.5022, 40.1375, 450.0),
}

Msg = tuple[str, dict[str, Any]]


def distance_m(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    la = math.radians((lat1 + lat2) / 2)
    return math.hypot((lon2 - lon1) * 111_320 * math.cos(la), (lat2 - lat1) * 110_570)


def bearing_deg(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    la = math.radians(lat1)
    deg = math.degrees(math.atan2((lon2 - lon1) * math.cos(la), lat2 - lat1))
    return (deg + 360) % 360


@dataclass
class Mission:
    id: str
    command: str
    phase: str = "received"  # received -> active (accepted) -> done
    dest: tuple[float, float, float] | None = None
    speed_mps: float = 15.0
    final_state: str = "HOVER"
    total_m: float = 0.0
    landing: bool = False


@dataclass
class Asset:
    id: str
    lon: float
    lat: float
    alt: float
    base: str
    battery: float
    state: str = "READY"
    nav: str = "HOLD"
    hdg: float = 0.0
    speed: float = 0.0
    uptime: float = 0.0
    mission: Mission | None = None
    muted: bool = False  # no telemetry/health/heartbeat: simulates a lost link
    factor: float = 1.0  # current speed as a fraction of the commanded speed (wind, load, terrain)

    @property
    def home(self) -> tuple[float, float, float]:
        return BASES[self.base]


def default_assets() -> list[Asset]:
    return [
        Asset("UAV-001", -9.1, 38.95, 420, "ALFA", 87.2, "HOVERING", "HOLD"),
        Asset("UAV-002", BASES["ALFA"][0], BASES["ALFA"][1], BASES["ALFA"][2], "ALFA", 96),
        # Low battery: MOVE gets REJECTED.
        Asset("UAV-003", BASES["BRAVO"][0], BASES["BRAVO"][1], BASES["BRAVO"][2], "BRAVO", 22),
        Asset("UAV-004", -7.75, 38.8, 300, "CHARLIE", 72, "HOVERING", "HOLD"),
    ]


class World:
    def __init__(
        self,
        time_scale: float = 1.0,
        assets: list[Asset] | None = None,
        speed_jitter: float = 0.0,
        seed: int | None = None,
    ) -> None:
        """`speed_jitter` is the maximum deviation from the commanded speed (0.2 = +/-20 %)."""
        self.time_scale = time_scale
        self.speed_jitter = speed_jitter
        self._rng = random.Random(seed)
        self.assets = {a.id: a for a in (assets if assets is not None else default_assets())}

    def _vary_speed(self, a: Asset) -> None:
        """Mean-reverting random walk, so the speed drifts like real conditions instead of jumping."""
        if self.speed_jitter <= 0:
            return
        j = self.speed_jitter
        a.factor += (1 - a.factor) * 0.1 + self._rng.gauss(0, j / 3)
        a.factor = max(1 - j, min(1 + j, a.factor))

    # ---- Inbound ---------------------------------------------------------------------------
    def handle_command(self, msg: dict[str, Any], now: float) -> list[Msg]:
        asset = self.assets.get(msg.get("asset_id", ""))
        if asset is None:
            return []
        out: list[Msg] = []
        if asset.mission and asset.mission.phase != "done":
            out.append(self._status(asset, asset.mission, "ABORTED", now))
        dest = msg.get("destination")
        asset.mission = Mission(
            id=msg["mission_id"],
            command=msg["command"],
            dest=(dest["longitude_deg"], dest["latitude_deg"], dest.get("altitude_m", asset.alt))
            if dest
            else None,
            speed_mps=float(msg.get("speed_mps", 15.0)),
            final_state=msg.get("final_state", "HOVER"),
        )
        out.append(self._status(asset, asset.mission, "RECEIVED", now))
        return out

    def handle_cancel(self, msg: dict[str, Any], now: float) -> list[Msg]:
        asset = self.assets.get(msg.get("asset_id", ""))
        m = asset.mission if asset else None
        if asset is None or m is None or m.id != msg.get("mission_id") or m.phase == "done":
            return []
        m.phase = "done"
        asset.speed = 0
        asset.state, asset.nav = "HOVERING", "HOLD"
        return [self._status(asset, m, "ABORTED", now)]

    # ---- Time ------------------------------------------------------------------------------
    def step(self, dt: float, now: float) -> list[Msg]:
        out: list[Msg] = []
        for a in self.assets.values():
            a.uptime += dt
            if a.mission:
                out.extend(self._advance(a, a.mission, dt, now))
            if a.state in AIRBORNE:
                a.battery = max(0.0, a.battery - 0.05 * dt)
            if not a.muted:
                out.extend(self._signals(a, now))
        return out

    # ---- Console controls ------------------------------------------------------------------
    def describe(self) -> list[dict[str, Any]]:
        return [
            {
                "id": a.id,
                "state": a.state,
                "battery": round(a.battery, 1),
                "muted": a.muted,
                "mission": a.mission.id if a.mission and a.mission.phase != "done" else None,
            }
            for a in self.assets.values()
        ]

    def tweak(self, asset_id: str, battery: float | None = None, muted: bool | None = None) -> bool:
        a = self.assets.get(asset_id)
        if a is None:
            return False
        if battery is not None:
            a.battery = max(0.0, min(100.0, float(battery)))
        if muted is not None:
            a.muted = bool(muted)
        return True

    def add_asset(self, spec: dict[str, Any]) -> str:
        """Creates an asset from a console form. Raises ValueError with a readable message."""
        asset_id = str(spec.get("id", "")).strip().upper()
        if not re.fullmatch(r"[A-Z0-9][A-Z0-9_\-]{1,31}", asset_id):
            raise ValueError("id must be 2-32 chars: letters, digits, '-' or '_'")
        if asset_id in self.assets:
            raise ValueError(f"asset {asset_id} already exists")
        base = str(spec.get("base", "ALFA")).upper()
        if base not in BASES:
            raise ValueError(f"base must be one of {', '.join(BASES)}")
        state = str(spec.get("state", "READY")).upper()
        if state not in ("READY", "HOVERING"):
            raise ValueError("state must be READY or HOVERING")
        try:
            blon, blat, belev = BASES[base]
            lat = float(spec["lat"]) if spec.get("lat") not in (None, "") else blat
            lon = float(spec["lon"]) if spec.get("lon") not in (None, "") else blon
            alt = float(spec["alt"]) if spec.get("alt") not in (None, "") else (
                belev if state == "READY" else 300.0
            )
            battery = float(spec.get("battery", 100))
        except (TypeError, ValueError) as exc:
            raise ValueError("lat, lon, alt and battery must be numbers") from exc
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise ValueError("lat must be in [-90, 90] and lon in [-180, 180]")
        self.assets[asset_id] = Asset(
            asset_id, lon, lat, alt, base, max(0.0, min(100.0, battery)), state, "HOLD"
        )
        return asset_id

    def remove_asset(self, asset_id: str) -> bool:
        return self.assets.pop(asset_id, None) is not None

    def _advance(self, a: Asset, m: Mission, dt: float, now: float) -> list[Msg]:
        if m.phase == "received":
            return self._accept_or_reject(a, m, now)
        if m.phase != "active":
            return []
        if m.command in ("HOLD_POSITION", "SHUTDOWN"):
            m.phase = "done"
        elif m.landing:
            self._descend(a, m)
        else:
            self._fly(a, m, dt)
        status = "COMPLETED" if m.phase == "done" else "IN_PROGRESS"
        return [self._status(a, m, status, now)]

    def _accept_or_reject(self, a: Asset, m: Mission, now: float) -> list[Msg]:
        supported = {"MOVE", "HOLD_POSITION", "RETURN_HOME", "LAND", "SHUTDOWN"}
        if m.command not in supported or (
            m.command == "MOVE" and (m.dest is None or a.battery < MIN_MISSION_BATTERY)
        ):
            m.phase = "done"
            return [self._status(a, m, "REJECTED", now)]
        m.phase = "active"
        if m.command == "MOVE":
            assert m.dest is not None
            m.total_m = distance_m(a.lon, a.lat, m.dest[0], m.dest[1])
            a.state, a.nav, a.speed = "MOVING", "MISSION", m.speed_mps
        elif m.command == "RETURN_HOME":
            hlon, hlat, helev = a.home
            m.dest = (hlon, hlat, helev)
            m.total_m = distance_m(a.lon, a.lat, hlon, hlat)
            a.state, a.nav, a.speed = "MOVING", "RETURN_HOME", m.speed_mps
        elif m.command == "HOLD_POSITION":
            a.state, a.nav, a.speed = "HOLDING", "HOLD", 0
        elif m.command == "LAND":
            m.landing = True
            a.state, a.nav, a.speed = "LANDING", "HOLD", 0
        elif m.command == "SHUTDOWN":
            a.state, a.nav, a.speed = "OFFLINE", "HOLD", 0
        return [self._status(a, m, "ACCEPTED", now)]

    def _fly(self, a: Asset, m: Mission, dt: float) -> None:
        assert m.dest is not None
        lon, lat, alt = m.dest
        self._vary_speed(a)
        a.speed = round(m.speed_mps * a.factor, 2)
        step = a.speed * self.time_scale * dt
        remaining = distance_m(a.lon, a.lat, lon, lat)
        if remaining > 0:
            a.hdg = bearing_deg(a.lon, a.lat, lon, lat)
        a.alt += max(-CLIMB_PER_STEP_M, min(CLIMB_PER_STEP_M, alt - a.alt))
        if remaining > step:
            f = step / remaining
            a.lon += (lon - a.lon) * f
            a.lat += (lat - a.lat) * f
            return
        a.lon, a.lat, a.speed = lon, lat, 0
        if m.command == "RETURN_HOME" or m.final_state == "LAND":
            m.landing = True
            a.state, a.nav = "LANDING", "HOLD"
        elif m.final_state == "SHUTDOWN":
            a.state, a.nav, m.phase = "OFFLINE", "HOLD", "done"
        elif m.final_state == "LOITER":
            a.state, a.nav, m.phase = "LOITERING", "LOITER", "done"
        else:
            a.state, a.nav, m.phase = "HOVERING", "HOLD", "done"

    def _descend(self, a: Asset, m: Mission) -> None:
        at_home = distance_m(a.lon, a.lat, a.home[0], a.home[1]) < 800
        ground = a.home[2] if at_home else 0.0
        a.alt = max(ground, a.alt - DESCENT_PER_STEP_M)
        if a.alt <= ground:
            a.state, a.nav, a.speed, m.phase = "READY", "HOLD", 0, "done"

    # ---- Outbound --------------------------------------------------------------------------
    def _status(self, a: Asset, m: Mission, status: str, now: float) -> Msg:
        remaining = 0.0
        if m.dest and m.phase != "done":
            remaining = distance_m(a.lon, a.lat, m.dest[0], m.dest[1])
        if status == "COMPLETED":
            pct = 100
        else:
            pct = round(100 * (1 - remaining / m.total_m)) if m.total_m else 0
        mps = a.speed * self.time_scale
        return TOPIC_STATUS, {
            "timestamp_utc": int(now),
            "asset_id": a.id,
            "mission_id": m.id,
            "status": status,
            "completion_percent": max(0, min(100, pct)),
            "remaining_distance_m": round(remaining),
            "estimated_arrival_s": round(remaining / mps) if mps else 0,
            "current_speed_mps": a.speed,
        }

    def _signals(self, a: Asset, now: float) -> list[Msg]:
        ts = int(now)
        active = a.mission.id if a.mission and a.mission.phase != "done" else None
        return [
            (
                TOPIC_TELEMETRY,
                {
                    "timestamp_utc": ts,
                    "asset_id": a.id,
                    "asset_type": "UAV",
                    "position": {
                        "latitude_deg": round(a.lat, 6),
                        "longitude_deg": round(a.lon, 6),
                        "altitude_m": round(a.alt, 1),
                    },
                    "velocity": {"ground_speed_mps": a.speed, "vertical_speed_mps": 0},
                    "heading_deg": round(a.hdg, 1),
                    # Camera geometry consumed by the C2 map to draw the UAV's visible sector.
                    "horizontal_fov": 78,
                    "visual_los": 1000,
                    "current_state": a.state,
                    "navigation_mode": a.nav,
                    "active_mission_id": active,
                },
            ),
            (
                TOPIC_HEALTH,
                {
                    "timestamp_utc": ts,
                    "asset_id": a.id,
                    "health_status": "OK",
                    "battery_percent": round(a.battery, 1),
                    "gps_fix": True,
                    "satellite_count": 14,
                    "communication_link_percent": 100,
                    "cpu_usage_percent": 35,
                    "memory_usage_percent": 41,
                },
            ),
            (
                TOPIC_HEARTBEAT,
                {
                    "timestamp_utc": ts,
                    "asset_id": a.id,
                    "asset_type": "UAV",
                    "status": "OFFLINE" if a.state == "OFFLINE" else "ONLINE",
                    "uptime_s": int(a.uptime),
                },
            ),
        ]
