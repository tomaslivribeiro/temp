"""Developer console of the X-Verse mock: a message log plus a publisher, served over plain HTTP.

`Hub` is the thread-safe message journal (no Zenoh, unit tested). `serve` exposes it with the stdlib
HTTP server, so the mock needs no extra dependency.
"""

import json
import re
import threading
import time
from collections import deque
from collections.abc import Callable
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from xverse_mock import world as w

C2_TOPICS = {w.TOPIC_COMMAND, w.TOPIC_CANCEL}
NOISE_TOPICS = {w.TOPIC_TELEMETRY, w.TOPIC_HEALTH, w.TOPIC_HEARTBEAT}
PAGE = Path(__file__).with_name("console.html")


class Hub:
    """Chronological journal of every message seen on Zenoh, newest last."""

    def __init__(self, capacity: int = 20_000) -> None:
        self._items: deque[dict[str, Any]] = deque(maxlen=capacity)
        self._seq = 0
        self._origins: dict[tuple[str, bytes], list[str]] = {}
        self._lock = threading.Lock()

    def expect(self, topic: str, raw: bytes, origin: str) -> None:
        """Tags a message we are about to publish so its loopback is attributed correctly."""
        with self._lock:
            self._origins.setdefault((topic, raw), []).append(origin)

    def record(self, topic: str, raw: bytes) -> dict[str, Any]:
        try:
            payload: Any = json.loads(raw)
        except ValueError:
            payload = raw.decode(errors="replace")
        with self._lock:
            tags = self._origins.get((topic, raw))
            origin = tags.pop(0) if tags else "external"
            if tags == []:
                del self._origins[(topic, raw)]
            self._seq += 1
            item = {
                "seq": self._seq,
                "ts": time.time(),
                "topic": topic,
                "direction": "c2->xverse" if topic in C2_TOPICS else "xverse->c2",
                "origin": origin,
                "noise": topic in NOISE_TOPICS and origin != "console",  # your own messages are never hidden
                "payload": payload,
            }
            self._items.append(item)
            return item

    def since(self, after: int = 0, limit: int = 1000) -> list[dict[str, Any]]:
        with self._lock:
            items = [i for i in self._items if i["seq"] > after]
        return items[-limit:] if after == 0 else items[:limit]

    def clear(self) -> None:
        with self._lock:
            self._items.clear()


def validate_publish(body: Any) -> tuple[str, bytes]:
    """Returns (topic, raw json) or raises ValueError with a message for the developer."""
    if not isinstance(body, dict):
        raise ValueError("body must be a JSON object")  # noqa: TRY004
    topic = body.get("topic")
    if not isinstance(topic, str) or not re.fullmatch(r"[A-Za-z0-9_\-]+(/[A-Za-z0-9_\-]+)*", topic):
        raise ValueError("topic must be a Zenoh key such as 'mission/status'")
    payload = body.get("payload")
    if not isinstance(payload, dict):
        raise ValueError("payload must be a JSON object")  # noqa: TRY004
    return topic, json.dumps(payload).encode()


def serve(
    port: int,
    hub: Hub,
    publish: Callable[[str, bytes], None],
    describe: Callable[[], list[dict[str, Any]]],
    tweak: Callable[[str, float | None, bool | None], bool],
    create: Callable[[dict[str, Any]], str],
    remove: Callable[[str], bool],
    time_scale: float,
) -> ThreadingHTTPServer:
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args: Any) -> None:  # keep container logs for Zenoh traffic only
            pass

        def _send(self, code: int, body: Any, ctype: str = "application/json") -> None:
            data = body if isinstance(body, bytes) else json.dumps(body).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(data)

        def _body(self) -> Any:
            length = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(length) or b"{}")

        def do_OPTIONS(self) -> None:
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.end_headers()

        def do_GET(self) -> None:
            path, _, query = self.path.partition("?")
            if path == "/":
                self._send(200, PAGE.read_bytes(), "text/html; charset=utf-8")
            elif path == "/api/messages":
                m = re.search(r"after=(\d+)", query)
                self._send(200, hub.since(int(m.group(1)) if m else 0))
            elif path == "/api/state":
                self._send(200, {"assets": describe(), "time_scale": time_scale})
            else:
                self._send(404, {"detail": "not found"})

        def do_POST(self) -> None:
            try:
                body = self._body()
                if self.path == "/api/publish":
                    topic, raw = validate_publish(body)
                    hub.expect(topic, raw, "console")
                    publish(topic, raw)
                    self._send(200, {"ok": True})
                elif self.path == "/api/clear":
                    hub.clear()
                    self._send(200, {"ok": True})
                elif self.path == "/api/assets":
                    if not isinstance(body, dict):
                        raise ValueError("body must be a JSON object")
                    self._send(200, {"ok": True, "id": create(body)})
                elif m := re.fullmatch(r"/api/assets/([\w\-]+)", self.path):
                    ok = tweak(m.group(1), body.get("battery"), body.get("muted"))
                    self._send(200 if ok else 404, {"ok": ok})
                else:
                    self._send(404, {"detail": "not found"})
            except ValueError as exc:
                self._send(422, {"detail": str(exc)})

        def do_DELETE(self) -> None:
            m = re.fullmatch(r"/api/assets/([\w\-]+)", self.path)
            ok = bool(m) and remove(m.group(1))
            self._send(200 if ok else 404, {"ok": ok})

    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    threading.Thread(target=server.serve_forever, daemon=True, name="mock-console").start()
    return server
