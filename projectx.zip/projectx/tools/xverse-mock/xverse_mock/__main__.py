"""Runs the X-Verse mock: `python -m xverse_mock`.

Env: ZENOH_LISTEN (default tcp/0.0.0.0:7447), ZENOH_CONNECT (optional), MOCK_TIME_SCALE (default 1 = real time),
MOCK_SPEED_JITTER (default 0.2 = speed varies +/-20 % around the commanded speed; 0 = constant), MOCK_CONSOLE_PORT,
MOCK_MODE (sim = default, simulates assets; passive = console only: no assets, no replies to commands, for a real X-Verse/CARLA).
"""

import json
import logging
import os
import threading
import time

import zenoh

from xverse_mock import console
from xverse_mock import world as w

log = logging.getLogger("xverse-mock")


def _endpoints(name: str, default: str = "") -> list[str]:
    return [e.strip() for e in os.environ.get(name, default).split(",") if e.strip()]


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    conf = zenoh.Config()
    conf.insert_json5("listen/endpoints", json.dumps(_endpoints("ZENOH_LISTEN", "tcp/0.0.0.0:7447")))
    if connect := _endpoints("ZENOH_CONNECT"):
        conf.insert_json5("connect/endpoints", json.dumps(connect))
    session = zenoh.open(conf)

    passive = os.environ.get("MOCK_MODE", "sim") == "passive"
    world = w.World(
        assets=[] if passive else None,
        time_scale=float(os.environ.get("MOCK_TIME_SCALE", "1")),
        speed_jitter=float(os.environ.get("MOCK_SPEED_JITTER", "0.2")),
    )
    lock = threading.Lock()
    hub = console.Hub()

    def put(topic: str, raw: bytes) -> None:
        session.put(topic, raw)

    def publish(msgs: list[w.Msg]) -> None:
        for topic, payload in msgs:
            raw = json.dumps(payload).encode()
            hub.expect(topic, raw, "mock")
            put(topic, raw)
            if topic == w.TOPIC_STATUS:
                log.info("-> %s %s %s", payload["asset_id"], payload["mission_id"], payload["status"])

    def on_any(sample: zenoh.Sample) -> None:
        hub.record(str(sample.key_expr), sample.payload.to_bytes())

    def tweak(asset_id: str, battery: float | None, muted: bool | None) -> bool:
        with lock:
            return world.tweak(asset_id, battery, muted)

    def describe() -> list[dict]:
        with lock:
            return world.describe()

    def create(spec: dict) -> str:
        with lock:
            return world.add_asset(spec)

    def remove(asset_id: str) -> bool:
        with lock:
            return world.remove_asset(asset_id)

    def on_command(sample: zenoh.Sample) -> None:
        msg = json.loads(sample.payload.to_bytes())
        log.info("<- command %s %s %s", msg.get("asset_id"), msg.get("mission_id"), msg.get("command"))
        with lock:
            publish(world.handle_command(msg, time.time()))

    def on_cancel(sample: zenoh.Sample) -> None:
        msg = json.loads(sample.payload.to_bytes())
        log.info("<- cancel %s %s", msg.get("asset_id"), msg.get("mission_id"))
        with lock:
            publish(world.handle_cancel(msg, time.time()))

    session.declare_subscriber("**", on_any)
    if not passive:
        session.declare_subscriber(w.TOPIC_COMMAND, on_command)
        session.declare_subscriber(w.TOPIC_CANCEL, on_cancel)
    port = int(os.environ.get("MOCK_CONSOLE_PORT", "5174"))
    console.serve(port, hub, put, describe, tweak, create, remove, world.time_scale)
    log.info("X-Verse mock up (%s): %d assets, time scale x%s", "passive" if passive else "sim", len(world.assets), world.time_scale)
    log.info("Developer console: http://localhost:%d", port)

    while True:
        time.sleep(1)
        with lock:
            publish(world.step(1.0, time.time()))


if __name__ == "__main__":
    main()
