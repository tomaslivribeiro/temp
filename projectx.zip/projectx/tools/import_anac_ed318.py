"""Loads an ANAC "VOA na Boa" ED-318 geozones file into the C2 database.

The file is the full picture for ANAC: zones that are no longer in it are deleted from the
database (and so from the map).

This is an adapter: the C2 core only knows its own zone model (see c2.domain.geozones). Other
sources get their own adapter that calls the same repository methods.

    cd backend && uv run python ../tools/import_anac_ed318.py ../tools/data/anac/ed318-20261120.json

Uses DATABASE_URL like the backend (default: the docker-compose Postgres on localhost).

Download (no CORS, regenerated on every request, hence the manual step for now):
    https://dnt.anac.pt/index.php?action=download-json
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

SOURCE_ID = "anac"
SOURCE_NAME = "ANAC - Voa na Boa (geozonas UAS, ED-318)"
SOURCE_URL = "https://dnt.anac.pt/voa-na-boa/"
ATTRIBUTION = "Fonte: ANAC / AAN (dnt.anac.pt)"
LICENSE_NOTE = (
    "A fonte não declara licença nem termos de reutilização. Uso interno; apoio à decisão, "
    "não substitui a fonte oficial."
)

RESTRICTIONS = {
    "PROHIBITED": "PROHIBITED",
    "REQ_AUTHORIZATION": "REQUIRES_AUTHORISATION",
    "CONDITIONAL": "CONDITIONAL",
    "NO_RESTRICTION": "NO_RESTRICTION",
}


def _text(values: list[dict[str, str]] | None, lang: str = "PT") -> str | None:
    """ED-318 localised text: [{"text": ..., "lang": "PT"}, ...]."""
    if not values:
        return None
    for value in values:
        if value.get("lang") == lang:
            return value["text"]
    return values[0]["text"]


def _time(value: str | None) -> datetime | None:
    return datetime.fromisoformat(value) if value else None


_TO_METRES = {"m": 1.0, "ft": 0.3048}


def _metres(value: float | None, unit: str) -> float | None:
    """Altitude in metres. ANAC mixes "m", "M" and "ft" in `uom`."""
    if value is None:
        return None
    factor = _TO_METRES.get(unit.lower())
    if factor is None:
        raise ValueError(f"unsupported altitude unit: {unit}")
    return round(value * factor, 2)


def _shape(geometry: dict[str, Any]) -> dict[str, Any]:
    kind = geometry["type"]
    if kind == "Point":
        extent = geometry.get("extent") or {}
        if extent.get("subType") != "Circle" or not extent.get("radius"):
            raise ValueError("Point without a circle extent")
        return {"type": "circle", "center": geometry["coordinates"][:2], "radius_m": extent["radius"]}
    if kind == "Polygon":
        return {"type": "polygon", "rings": geometry["coordinates"]}
    if kind == "MultiPolygon":
        return {"type": "multipolygon", "polygons": geometry["coordinates"]}
    raise ValueError(f"unsupported geometry: {kind}")


def map_feature(feature: dict[str, Any]) -> dict[str, Any]:
    """One ED-318 feature -> the dict `upsert_zones` takes. Raises ValueError if unusable."""
    props, geometry = feature["properties"], feature["geometry"]
    layer = geometry.get("layer") or {}
    unit = layer.get("uom", "m")
    if props["type"] not in RESTRICTIONS:
        raise ValueError(f"unknown restriction: {props['type']}")
    window = (props.get("limitedApplicability") or [{}])[0]
    extended = props.get("extendedProperties") or {}
    return {
        "external_id": props["identifier"],
        "name": _text(props.get("name")) or props["identifier"],
        "restriction": RESTRICTIONS[props["type"]],
        "reason": (props.get("reason") or [None])[0],
        "message": _text(props.get("message")),
        "shape": _shape(geometry),
        "lower_m": _metres(layer.get("lower"), unit),
        "upper_m": _metres(layer.get("upper"), unit),
        "lower_ref": layer.get("lowerReference"),
        "upper_ref": layer.get("upperReference"),
        "valid_from": _time(window.get("startDateTime")),
        "valid_to": _time(window.get("endDateTime")),
        "properties": {
            key: value
            for key, value in {
                "zone_authority": props.get("zoneAuthority"),
                "schedule": window.get("schedule"),
                "color": extended.get("color"),
                "notam": extended.get("notam_inf"),
            }.items()
            if value
        },
    }


def map_collection(document: dict[str, Any]) -> tuple[list[dict[str, Any]], list[str]]:
    zones, skipped = [], []
    for feature in document["features"]:
        try:
            zones.append(map_feature(feature))
        except (KeyError, ValueError) as exc:
            skipped.append(f"{feature.get('properties', {}).get('identifier', '?')}: {exc}")
    return zones, skipped


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("file", type=Path, help="ED-318 JSON downloaded from ANAC")
    args = parser.parse_args()

    # The adapter lives outside the backend package: make `c2` importable from any directory.
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend" / "src"))
    from c2 import db
    from c2.repositories.geozones import SqlAlchemyGeozoneRepository

    document = json.loads(args.file.read_text(encoding="utf-8"))
    zones, skipped = map_collection(document)
    metadata = document.get("metadata") or {}
    if not zones:
        print(f"no usable zones in {args.file.name}: database left unchanged", file=sys.stderr)
        return 1
    # Everything the file still publishes, including features we could not map.
    published = {f.get("properties", {}).get("identifier") for f in document["features"]}
    repository = SqlAlchemyGeozoneRepository(db.engine)
    repository.upsert_source(
        SOURCE_ID,
        name=SOURCE_NAME,
        url=SOURCE_URL,
        attribution=ATTRIBUTION,
        license_note=LICENSE_NOTE,
        dataset_version=f"ED-318 emitido em {metadata.get('issued', 'desconhecido')}",
        retrieved_at=_time(metadata.get("issued")),
    )
    removed = repository.replace_zones(SOURCE_ID, zones, keep=published - {None})
    print(
        f"imported {len(zones)} zones from {args.file.name}; "
        f"removed {removed} no longer published; skipped {len(skipped)}"
    )
    for line in skipped:
        print(f"  skipped {line}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
