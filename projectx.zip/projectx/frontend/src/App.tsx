import { useMemo, useState } from "react";
import { useBackendStatus } from "./api/useBackendStatus";
import { CommandPanel } from "./components/CommandPanel";
import { DroneHeader, TelemetryPanel } from "./components/DroneInfo";
import { FleetList } from "./components/FleetList";
import { MapView } from "./components/MapView";
import { SettingsView } from "./components/SettingsView";
import { Tabs } from "./components/Tabs";
import { TopBar } from "./components/TopBar";
import { alertsOf, linkOf } from "./domain/link";
import type { ActionId, LonLat } from "./domain/types";
import { createSource } from "./sim/createSource";
import { useFleet } from "./sim/useFleet";

const MAX_TABS = 6;

export function App() {
  const backend = useBackendStatus();
  const { snap, link, feedDown, send } = useFleet(createSource);
  const [active, setActive] = useState("fleet");
  const [tabs, setTabs] = useState<string[]>(["GAMA", "GOMES"]);
  const [hover, setHover] = useState<string | null>(null);
  const [picking, setPicking] = useState(false);
  const [draft, setDraft] = useState<LonLat | null>(null);
  const [limit, setLimit] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const alertCount = useMemo(() => snap.drones.filter((d) => alertsOf(d, linkOf(d)).length > 0).length, [snap.drones]);
  const drone = snap.drones.find((d) => d.id === active);

  const go = (id: string) => {
    setActive(id);
    setPicking(false);
    setDraft(null);
  };
  const open = (id: string) => {
    if (!tabs.includes(id)) {
      if (tabs.length >= MAX_TABS) return setLimit(true);
      setTabs([...tabs, id]);
    }
    setLimit(false);
    go(id);
  };
  const close = (id: string) => {
    setTabs(tabs.filter((t) => t !== id));
    if (active === id) go("fleet");
  };
  const onSend = (a: ActionId, b: LonLat | null) => {
    send(active, a, b);
    setPicking(false);
    setDraft(null);
  };

  return (
    <div className="app">
      <TopBar
        backend={backend}
        ws={link}
        uavCount={snap.drones.length}
        alertCount={alertCount}
        settingsOpen={settingsOpen}
        onToggleSettings={() => setSettingsOpen(!settingsOpen)}
      />
      {settingsOpen ? (
        <SettingsView />
      ) : (
        <>
      <Tabs active={active} tabs={tabs} drones={snap.drones} onSelect={go} onClose={close} />
      {limit && <p className="note">Tab limit reached ({MAX_TABS}). Close one to open another UAV.</p>}
      {drone ? (
        <div className="lay drone">
          <DroneHeader d={drone} />
          <TelemetryPanel d={drone} />
          <MapView
            key={drone.id}
            drones={snap.drones}
            followId={drone.id}
            picking={picking}
            draft={draft}
            onSelect={open}
            onPick={setDraft}
            onCancelPick={() => setPicking(false)}
            predict={link !== "local"}
          />
          <CommandPanel
            drone={drone}
            cmds={snap.cmds}
            profile="OPERATOR"
            feedDown={feedDown}
            picking={picking}
            draft={draft}
            onStartPick={() => setPicking(true)}
            onCancelPick={() => {
              setPicking(false);
              setDraft(null);
            }}
            onSend={onSend}
          />
        </div>
      ) : (
        <div className="lay fleet">
          <FleetList drones={snap.drones} openTabs={tabs} onOpen={open} onHover={setHover} />
          <MapView
            key="fleet"
            drones={snap.drones}
            hoverId={hover}
            onSelect={open}
            predict={link !== "local"}
          />
        </div>
      )}
        </>
      )}
    </div>
  );
}
