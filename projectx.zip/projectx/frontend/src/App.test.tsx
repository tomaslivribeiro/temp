// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { App } from "./App";
import type { Drone } from "./domain/types";

// MapLibre needs WebGL, which jsdom lacks: only how many maps are on screen matters here.
vi.mock("./components/MapView", () => ({ MapView: () => <div data-testid="map" /> }));
vi.mock("./api/useBackendStatus", () => ({ useBackendStatus: () => ({ state: "offline" }) }));
vi.mock("./sim/useFleet", () => {
  const drone = (id: string) =>
    ({
      id, state: "H", base: "ALFA", lon: -9, lat: 38.8, alt: 100, spd: 0, hdg: 0, bat: 80, hb: 0,
      flaky: false, lost: false, gps: "good", sats: 14, trail: [], a: null, b: null, timer: 0,
    }) as Drone;
  const snap = { t: 0, drones: [drone("GAMA"), drone("GOMES")], cmds: [] };
  return { useFleet: () => ({ snap, link: "local", feedDown: false, send: () => {} }) };
});

describe("App views", () => {
  afterEach(cleanup);

  it("keeps one map and only the panels of the view shown while moving between tabs", () => {
    const { container } = render(<App />);
    const tab = (name: RegExp) => fireEvent.click(screen.getAllByRole("button", { name })[0]);
    const layout = () => [...container.querySelector(".lay")!.children].map((c) => c.getAttribute("data-testid") ?? c.className);
    const fleet = ["panel a-list", "map"];
    const drone = ["dhead a-head", "panel a-tel", "map", "panel a-cmd"];

    expect(layout()).toEqual(fleet);
    for (const id of [/GAMA/, /GOMES/, /GAMA/]) {
      tab(id);
      expect(layout()).toEqual(drone);
    }
    tab(/^Fleet/);
    expect(layout()).toEqual(fleet);
  });
});
