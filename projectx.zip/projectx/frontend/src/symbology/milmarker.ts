import ms from "milsymbol";

import { STATE_LABEL } from "../domain/constants";
import { alertsOf, maxSeverity } from "../domain/link";
import type { Drone, Link } from "../domain/types";
import { buildSidc, type Affiliation, type Echelon, type PlatformType } from "./sidc";
import { sidcStatusOf } from "./status";

export interface MilSymbolResult {
  /** SIDC plus text fields; equal keys render the same SVG. */
  key: string;
  svg: string;
  anchor: { x: number; y: number };
  size: { width: number; height: number };
}

// Rendered symbols by key; the fleet loop asks for the same symbols every second.
const cache = new Map<string, MilSymbolResult>();
const CACHE_LIMIT = 500;

/**
 * Renders the APP-6 symbol for a drone as an SVG string, ready to drop into the HTMLElement marker
 * that MapView already manages. The anchor is the symbol's position point in SVG pixels (it moves
 * as text fields and the direction arrow grow the SVG), so the marker must be offset by it.
 */
export function buildMilsymbol(drone: Drone, link: Link, size = 34): MilSymbolResult {
  const affiliation: Affiliation = (drone.affiliation as Affiliation | undefined) ?? "FRIEND";
  const platformType: PlatformType = (drone.platformType as PlatformType | undefined) ?? "ROTARY_UAV";
  const echelon = (drone.echelon as Echelon | null | undefined) ?? null;
  const status = sidcStatusOf(drone, link);
  const sidc = buildSidc({ affiliation, platformType, status, echelon });
  const sev = maxSeverity(alertsOf(drone, link));
  // Field H: state plus the alert badge ("!" warning, "!!" critical); APP-6 has no alert field.
  const info = sev ? `${STATE_LABEL[drone.state]} ${sev === 2 ? "!!" : "!"}` : STATE_LABEL[drone.state];

  const options = {
    size,
    // milsymbol switches NATO vs US rendering via "APP6" vs "2525"; the edition (E) is encoded in
    // the SIDC version digits built by buildSidc.
    standard: "APP6",
    direction: drone.spd > 0 ? drone.hdg : undefined,
    speed: drone.spd > 0 ? `${Math.round(drone.spd)} km/h` : undefined,
    uniqueDesignation: drone.callsign ?? drone.id,
    higherFormation: drone.higherFormation ?? undefined,
    additionalInformation: info,
    infoFields: true,
  };
  const key = `${sidc}|${JSON.stringify(options)}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const symbol = new ms.Symbol(sidc, options);
  const result = { key, svg: symbol.asSVG(), anchor: symbol.getAnchor(), size: symbol.getSize() };
  if (cache.size >= CACHE_LIMIT) cache.clear();
  cache.set(key, result);
  return result;
}
