import type { Drone, Link } from "../domain/types";
import type { SidcStatus } from "./sidc";

/**
 * Translates the internal C2 state + link quality into an APP-6 status digit.
 *
 * - `G` (fault) always surfaces as `DAMAGED` so the operator sees the APP-6 damage mark.
 * - Lost / unknown link keeps `PRESENT` on the symbol because the asset is not destroyed; the
 *   marker's `.lost` CSS wrapper dessaturates the glyph to convey "no contact".
 * - Everything else is `PRESENT`.
 */
export function sidcStatusOf(drone: Drone, link: Link): SidcStatus {
  if (drone.state === "G") return "DAMAGED";
  return "PRESENT";
}
