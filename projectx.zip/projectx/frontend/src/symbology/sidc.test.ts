import { describe, expect, it } from "vitest";
import ms from "milsymbol";
import { buildSidc } from "./sidc";

describe("buildSidc", () => {
  it("builds a 30-character SIDC for a friend rotary UAV", () => {
    const sidc = buildSidc({
      affiliation: "FRIEND",
      platformType: "ROTARY_UAV",
      status: "PRESENT",
    });
    expect(sidc).toHaveLength(30);
    expect(sidc.slice(0, 2)).toBe("13"); // version APP-6 E
    expect(sidc[2]).toBe("0");            // context: reality
    expect(sidc[3]).toBe("3");            // affiliation: Friend
    expect(sidc.slice(4, 6)).toBe("01"); // symbol set: Air
    expect(sidc[6]).toBe("0");            // status: present
    expect(sidc.slice(8, 10)).toBe("00");// no echelon
    expect(sidc.slice(10, 16)).toBe("110400"); // VT-UAV
  });

  it("encodes affiliation in position 4", () => {
    const hostile = buildSidc({ affiliation: "HOSTILE", platformType: "FIXED_WING_UAV", status: "PRESENT" });
    const neutral = buildSidc({ affiliation: "NEUTRAL", platformType: "FIXED_WING_UAV", status: "PRESENT" });
    const unknown = buildSidc({ affiliation: "UNKNOWN", platformType: "FIXED_WING_UAV", status: "PRESENT" });
    expect(hostile[3]).toBe("6");
    expect(neutral[3]).toBe("4");
    expect(unknown[3]).toBe("1");
  });

  it("maps every platform type to the correct symbol set", () => {
    expect(buildSidc({ affiliation: "FRIEND", platformType: "ROTARY_UAV", status: "PRESENT" }).slice(4, 6)).toBe("01");
    expect(buildSidc({ affiliation: "FRIEND", platformType: "FIXED_WING_UAV", status: "PRESENT" }).slice(4, 6)).toBe("01");
    expect(buildSidc({ affiliation: "FRIEND", platformType: "WHEELED_UGV", status: "PRESENT" }).slice(4, 6)).toBe("15");
    expect(buildSidc({ affiliation: "FRIEND", platformType: "TRACKED_UGV", status: "PRESENT" }).slice(4, 6)).toBe("15");
    expect(buildSidc({ affiliation: "FRIEND", platformType: "USV", status: "PRESENT" }).slice(4, 6)).toBe("30");
    expect(buildSidc({ affiliation: "FRIEND", platformType: "FOOT", status: "PRESENT" }).slice(4, 6)).toBe("10");
  });

  it("encodes status in position 7", () => {
    const damaged = buildSidc({ affiliation: "FRIEND", platformType: "ROTARY_UAV", status: "DAMAGED" });
    const destroyed = buildSidc({ affiliation: "FRIEND", platformType: "ROTARY_UAV", status: "DESTROYED" });
    const planned = buildSidc({ affiliation: "FRIEND", platformType: "ROTARY_UAV", status: "PLANNED" });
    expect(damaged[6]).toBe("3");
    expect(destroyed[6]).toBe("4");
    expect(planned[6]).toBe("1");
  });

  it("encodes echelon in positions 9-10", () => {
    const platoon = buildSidc({ affiliation: "FRIEND", platformType: "FOOT", status: "PRESENT", echelon: "PLATOON" });
    const squad = buildSidc({ affiliation: "FRIEND", platformType: "FOOT", status: "PRESENT", echelon: "SQUAD" });
    expect(platoon.slice(8, 10)).toBe("14");
    expect(squad.slice(8, 10)).toBe("12");
  });

  it("ignores echelon outside Land Units, where APP-6 has none", () => {
    const air = buildSidc({ affiliation: "FRIEND", platformType: "ROTARY_UAV", status: "PRESENT", echelon: "SECTION" });
    const sea = buildSidc({ affiliation: "FRIEND", platformType: "USV", status: "PRESENT", echelon: "SECTION" });
    expect(air.slice(8, 10)).toBe("00");
    expect(sea.slice(8, 10)).toBe("00");
  });

  it("encodes UGVs as robotic utility vehicles with a mobility indicator", () => {
    const wheeled = buildSidc({ affiliation: "FRIEND", platformType: "WHEELED_UGV", status: "PRESENT", echelon: "SECTION" });
    const tracked = buildSidc({ affiliation: "FRIEND", platformType: "TRACKED_UGV", status: "PRESENT" });
    expect(wheeled.slice(10, 16)).toBe("140100"); // Utility vehicle
    expect(wheeled.slice(16, 18)).toBe("24");     // Modifier 1: Robotic
    expect(wheeled.slice(8, 10)).toBe("32");      // Wheeled cross-country (echelon dropped)
    expect(tracked.slice(8, 10)).toBe("33");      // Tracked
    const meta = new ms.Symbol(tracked, { size: 30 }).getMetadata();
    expect(meta.mobility).toBe("Tracked");
  });

  it("produces SIDCs that milsymbol accepts as valid", () => {
    const platforms = ["ROTARY_UAV", "FIXED_WING_UAV", "WHEELED_UGV", "TRACKED_UGV", "USV", "FOOT"] as const;
    for (const platform of platforms) {
      const sidc = buildSidc({ affiliation: "FRIEND", platformType: platform, status: "PRESENT" });
      const symbol = new ms.Symbol(sidc, { size: 30 });
      expect(symbol.isValid()).toBeTruthy();
      expect(symbol.asSVG()).toMatch(/<svg/);
    }
  });
});
