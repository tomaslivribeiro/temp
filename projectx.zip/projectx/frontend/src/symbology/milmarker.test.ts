import { describe, expect, it } from "vitest";
import type { Drone, Link } from "../domain/types";
import { buildMilsymbol } from "./milmarker";

function drone(over: Partial<Drone> = {}): Drone {
  return {
    id: "UAV-01", state: "H", base: "ALFA", lon: -9.14, lat: 38.72,
    alt: 120, spd: 0, hdg: 0, bat: 85, hb: 0, flaky: false, lost: false,
    gps: "good", sats: 12, trail: [], a: null, b: null, timer: 0,
    ...over,
  };
}

const OK_LINK: Link = { kind: "ok", label: "Live", short: "Live" };
const LOST_LINK: Link = { kind: "lost", label: "No contact", short: "No contact" };

describe("buildMilsymbol", () => {
  it("renders an SVG and exposes anchor plus size", () => {
    const out = buildMilsymbol(drone(), OK_LINK);
    expect(out.svg).toMatch(/^<svg[\s\S]*<\/svg>$/);
    expect(out.anchor.x).toBeGreaterThan(0);
    expect(out.size.width).toBeGreaterThan(0);
  });

  it("uses callsign over id as unique designation when available", () => {
    const withCallsign = buildMilsymbol(
      drone({ callsign: "ALPHA-1" }),
      OK_LINK,
    );
    expect(withCallsign.svg).toContain("ALPHA-1");
  });

  it("falls back to id when the asset has no callsign", () => {
    const out = buildMilsymbol(drone({ id: "GAMA" }), OK_LINK);
    expect(out.svg).toContain("GAMA");
  });

  it("adds the direction and speed leader when the asset is moving", () => {
    const moving = buildMilsymbol(drone({ spd: 65, hdg: 90 }), OK_LINK);
    const still = buildMilsymbol(drone({ spd: 0 }), OK_LINK);
    // The direction arrow drawing instruction produces extra <path> elements.
    expect(moving.svg.length).toBeGreaterThan(still.svg.length);
  });

  it("renders a damaged asset with a condition bar (status G)", () => {
    const fault = buildMilsymbol(drone({ state: "G" }), OK_LINK);
    const ok = buildMilsymbol(drone({ state: "H" }), OK_LINK);
    expect(fault.svg).not.toEqual(ok.svg);
  });

  it("treats missing affiliation/platformType as FRIEND rotary UAV defaults", () => {
    const out = buildMilsymbol(drone(), OK_LINK);
    // Friend NATO glyph is a rectangle (box outline). Just make sure it draws something.
    expect(out.svg).toMatch(/<svg/);
  });

  it("returns the same key for an unchanged asset and a new one when a field changes", () => {
    const a = buildMilsymbol(drone(), OK_LINK);
    const b = buildMilsymbol(drone(), OK_LINK);
    const moved = buildMilsymbol(drone({ spd: 40, hdg: 10 }), OK_LINK);
    expect(b.key).toBe(a.key);
    expect(moved.key).not.toBe(a.key);
  });

  it("appends the alert badge to the additional information field", () => {
    const critical = buildMilsymbol(drone({ state: "H", bat: 10 }), OK_LINK);
    const warning = buildMilsymbol(drone({ state: "H", bat: 25 }), OK_LINK);
    const clean = buildMilsymbol(drone({ state: "H", bat: 85 }), OK_LINK);
    expect(critical.svg).toContain("!!");
    expect(warning.svg).toMatch(/[^!]![^!]/);
    expect(clean.svg).not.toContain("!");
  });

  it("renders when the link is lost (status still PRESENT, dessaturation is CSS)", () => {
    const out = buildMilsymbol(drone(), LOST_LINK);
    expect(out.svg).toMatch(/<svg/);
  });
});
