/**
 * NATO APP-6 / 2525 SIDC (Symbol Identification Code) builder.
 *
 * 30-character numeric SIDC, fixed to APP-6 E. Positions follow the APP-6 D/E convention as implemented by
 * `milsymbol` (see `node_modules/milsymbol/src/numbersidc/metadata.js`):
 *
 *   01-02  Version          "13" (APP-6 E)
 *   03     Context          0=Reality, 1=Exercise, 2=Simulation
 *   04     Standard Identity 1=Unknown, 3=Friend, 4=Neutral, 6=Hostile
 *   05-06  Symbol Set       01=Air, 10=Land Unit, 15=Land Equipment, 30=Sea Surface
 *   07     Status           0=Present, 1=Planned, 3=Damaged, 4=Destroyed
 *   08     HQ / TF / Dummy  0 (none)
 *   09-10  Amplifier        Land Unit: echelon (11=Team ... 22=Corps); Land Equipment: mobility
 *                           (32=Wheeled cross-country, 33=Tracked); "00" elsewhere (no echelon in Air/Sea)
 *   11-16  Entity / Type / Subtype   platform-specific (see ENTITY_CODE below)
 *   17-18  Modifier 1       UGV: "24" Robotic; "00" elsewhere
 *   19-20  Modifier 2       "00"
 *   21-22  Modifier 1/2 set "00" (symbol-set modifiers, not the common ones)
 *   23     Frame shape      "0" (default for the symbol set)
 *   24-30  reserved / country "0000000"
 */

export type Affiliation = "FRIEND" | "HOSTILE" | "NEUTRAL" | "UNKNOWN";
export type PlatformType =
  | "ROTARY_UAV"
  | "FIXED_WING_UAV"
  | "WHEELED_UGV"
  | "TRACKED_UGV"
  | "USV"
  | "FOOT";
export type Echelon =
  | "TEAM"
  | "SQUAD"
  | "SECTION"
  | "PLATOON"
  | "COMPANY"
  | "BATTALION"
  | "REGIMENT"
  | "BRIGADE"
  | "DIVISION"
  | "CORPS";
export type SidcStatus = "PRESENT" | "PLANNED" | "DAMAGED" | "DESTROYED";
// APP-6 E, the current NATO edition. milsymbol renders D ("10") and E identically for our symbols.
const VERSION = "13";

const AFFILIATION_DIGIT: Record<Affiliation, string> = {
  UNKNOWN: "1",
  FRIEND: "3",
  NEUTRAL: "4",
  HOSTILE: "6",
};

const SYMBOL_SET: Record<PlatformType, string> = {
  ROTARY_UAV: "01",
  FIXED_WING_UAV: "01",
  WHEELED_UGV: "15",
  TRACKED_UGV: "15",
  USV: "30",
  FOOT: "10",
};

// Positions 11-16 of the SIDC (entity + type + subtype). Codes validated against
// milsymbol's own icon tables (src/numbersidc/sidc/*.js).
const ENTITY_CODE: Record<PlatformType, string> = {
  ROTARY_UAV: "110400",     // Vertical-takeoff UAV (VT-UAV)
  FIXED_WING_UAV: "110300", // Generic UAV (fixed-wing silhouette)
  WHEELED_UGV: "140100",    // Utility vehicle; unmanned via MODIFIER_1, wheels/tracks via MOBILITY
  TRACKED_UGV: "140100",
  USV: "120700",            // Unmanned surface water vehicle
  FOOT: "121100",            // Infantry
};

// Positions 17-18: Land Equipment "Robotic" sector 1 modifier marks the vehicle as unmanned.
const MODIFIER_1: Partial<Record<PlatformType, string>> = {
  WHEELED_UGV: "24",
  TRACKED_UGV: "24",
};

// Positions 9-10 for Land Equipment: mobility indicator instead of echelon.
const MOBILITY: Partial<Record<PlatformType, string>> = {
  WHEELED_UGV: "32", // Wheeled cross-country
  TRACKED_UGV: "33", // Tracked
};

const STATUS_DIGIT: Record<SidcStatus, string> = {
  PRESENT: "0",
  PLANNED: "1",
  DAMAGED: "3",
  DESTROYED: "4",
};

const ECHELON_DIGITS: Record<Echelon, string> = {
  TEAM: "11",
  SQUAD: "12",
  SECTION: "13",
  PLATOON: "14",
  COMPANY: "15",
  BATTALION: "16",
  REGIMENT: "17",
  BRIGADE: "18",
  DIVISION: "21",
  CORPS: "22",
};

export interface SidcInput {
  affiliation: Affiliation;
  platformType: PlatformType;
  status: SidcStatus;
  echelon?: Echelon | null;
}

export function buildSidc(input: SidcInput): string {
  const version = VERSION;
  const context = "0"; // reality
  const si = AFFILIATION_DIGIT[input.affiliation];
  const symbolSet = SYMBOL_SET[input.platformType];
  const status = STATUS_DIGIT[input.status];
  const hqTfDummy = "0";
  // Echelon only exists for Land Units; Land Equipment reuses the slot for mobility.
  const amplifier =
    symbolSet === "10" && input.echelon
      ? ECHELON_DIGITS[input.echelon]
      : (MOBILITY[input.platformType] ?? "00");
  const entity = ENTITY_CODE[input.platformType];
  const modifiers = (MODIFIER_1[input.platformType] ?? "00") + "00"; // modifier 1 + modifier 2
  const reserved = "0000000000"; // positions 21-30
  const sidc =
    version + context + si + symbolSet + status + hqTfDummy + amplifier + entity + modifiers + reserved;
  if (sidc.length !== 30) throw new Error(`built SIDC with wrong length: ${sidc.length}`);
  return sidc;
}
