import { useEffect, useState } from "react";
import { api, type VersionResponse } from "./client";

export type BackendStatus =
  | { state: "checking" }
  | { state: "online"; info: VersionResponse | null }
  | { state: "offline"; error: string };

/** Polls GET /health; on success also reads /version (app version and active driver). */
export function useBackendStatus(intervalMs = 5000): BackendStatus {
  const [status, setStatus] = useState<BackendStatus>({ state: "checking" });

  useEffect(() => {
    let active = true;
    const check = async () => {
      try {
        await api.health();
        const info = await api.version().catch(() => null);
        if (active) setStatus({ state: "online", info });
      } catch (e) {
        if (active) setStatus({ state: "offline", error: e instanceof Error ? e.message : String(e) });
      }
    };
    void check();
    const id = setInterval(check, intervalMs);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, [intervalMs]);

  return status;
}
