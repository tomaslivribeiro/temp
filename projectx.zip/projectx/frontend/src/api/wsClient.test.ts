import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { backoffMs, connectWs, FLEET_SNAPSHOT, parseMessage, type WsLink } from "./wsClient";

describe("websocket helpers", () => {
  it("parses the backend envelope and rejects garbage", () => {
    const m = parseMessage('{"type":"hello","payload":{"driver":"zenoh"},"ts":"2026-01-01T00:00:00Z"}');
    expect(m?.type).toBe("hello");
    expect(parseMessage("nope")).toBeNull();
    expect(parseMessage('{"payload":{}}')).toBeNull();
  });

  it("backs off exponentially up to 15 s", () => {
    expect([0, 1, 2, 3].map(backoffMs)).toEqual([1000, 2000, 4000, 8000]);
    expect(backoffMs(10)).toBe(15000);
  });
});

/** Minimal browser WebSocket: tests drive it with emit/raw/drop. */
class FakeWebSocket {
  static all: FakeWebSocket[] = [];
  onmessage: ((ev: { data: string }) => void) | null = null;
  onclose: (() => void) | null = null;
  closed = false;

  constructor(readonly url: string) {
    FakeWebSocket.all.push(this);
  }
  close() {
    this.closed = true;
  }
  emit(type: string) {
    this.raw(JSON.stringify({ type, payload: {}, ts: "" }));
  }
  raw(data: string) {
    this.onmessage?.({ data });
  }
  drop() {
    this.onclose?.();
  }
}

const last = () => FakeWebSocket.all[FakeWebSocket.all.length - 1];

describe("connectWs", () => {
  let links: WsLink[];
  let stop: () => void;
  const state = () => links[links.length - 1];

  const start = () => {
    stop = connectWs({ url: "ws://test", staleMs: 10000, onMessage: () => {}, onStatus: (l) => links.push(l) });
  };
  const live = () => last().emit(FLEET_SNAPSHOT);

  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(0);
    vi.stubGlobal("WebSocket", FakeWebSocket);
    vi.spyOn(Math, "random").mockReturnValue(0.5); // no jitter
    FakeWebSocket.all = [];
    links = [];
  });

  afterEach(() => {
    stop?.();
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
    vi.useRealTimers();
  });

  it("reconnects with backoff and resets the attempts once data flows", () => {
    start();
    live();
    for (const delay of [1000, 2000, 4000]) {
      last().drop();
      const closed = state();
      expect(closed.state === "closed" && closed.retryAt).toBe(Date.now() + delay);
      vi.advanceTimersByTime(delay - 1);
      expect(state().state).toBe("closed");
      vi.advanceTimersByTime(1);
      expect(state().state).toBe("connecting");
    }
    expect(FakeWebSocket.all).toHaveLength(4);
    live();
    expect(state()).toMatchObject({ state: "open", attempt: 0 });
  });

  it("spreads retries by up to 20% either way", () => {
    start();
    vi.mocked(Math.random).mockReturnValue(0);
    last().drop();
    expect(state()).toMatchObject({ retryAt: 800 });
    vi.advanceTimersByTime(800);
    vi.mocked(Math.random).mockReturnValue(1);
    last().drop();
    expect(state()).toMatchObject({ retryAt: 800 + 2400 });
  });

  it("keeps backing off against a peer that accepts and then closes", () => {
    start();
    for (const delay of [1000, 2000, 4000, 8000]) {
      last().emit("hello");
      last().drop();
      expect(state().state).toBe("closed");
      vi.advanceTimersByTime(delay);
    }
    expect(state()).toMatchObject({ state: "connecting", attempt: 4 });
  });

  it("is not connected until the first snapshot", () => {
    start();
    last().emit("hello");
    expect(state().state).toBe("connecting");
    vi.advanceTimersByTime(10000);
    expect(state()).toMatchObject({ state: "closed", attempt: 1 });
  });

  it("drops a silent socket and keeps a talking one", () => {
    start();
    for (let i = 0; i < 20; i++) {
      vi.advanceTimersByTime(1000);
      live();
    }
    expect(state().state).toBe("open");

    vi.advanceTimersByTime(10000);
    expect(state()).toMatchObject({ state: "closed", attempt: 1, lastDataAt: 20000 });
    expect(FakeWebSocket.all[0].closed).toBe(true);
    vi.advanceTimersByTime(1000);
    expect(FakeWebSocket.all).toHaveLength(2);
  });

  it("does not let heartbeats or garbage hide a dead feed", () => {
    start();
    live();
    for (let i = 0; i < 9; i++) {
      vi.advanceTimersByTime(1000);
      last().emit("server.heartbeat");
      last().raw("garbage");
    }
    vi.advanceTimersByTime(1000);
    expect(state()).toMatchObject({ state: "closed", lastDataAt: 0 });
  });

  it("passes every parsed message on and skips garbage", () => {
    const seen: string[] = [];
    stop = connectWs({ url: "ws://test", onMessage: (m) => seen.push(m.type) });
    last().emit("hello");
    last().raw("garbage");
    live();
    expect(seen).toEqual(["hello", FLEET_SNAPSHOT]);
  });

  it("gives up on a socket that never opens", () => {
    start();
    vi.advanceTimersByTime(10000);
    expect(state().state).toBe("closed");
  });

  it("keeps retrying when the socket cannot be created", () => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    let fail = true;
    vi.stubGlobal(
      "WebSocket",
      class extends FakeWebSocket {
        constructor(url: string) {
          if (fail) throw new SyntaxError("bad url");
          super(url);
        }
      },
    );
    start();
    expect(state()).toMatchObject({ state: "closed", attempt: 1 });
    fail = false;
    vi.advanceTimersByTime(1000);
    expect(FakeWebSocket.all).toHaveLength(1);
    expect(state().state).toBe("connecting");
  });

  it("ignores the old socket after stop", () => {
    start();
    const old = last();
    stop();
    const count = links.length;
    old.drop();
    vi.advanceTimersByTime(60000);
    expect(links).toHaveLength(count);
    expect(FakeWebSocket.all).toHaveLength(1);
    expect(old.closed).toBe(true);
  });

  it("cancels the pending retry on stop", () => {
    start();
    last().drop();
    stop();
    vi.advanceTimersByTime(60000);
    expect(FakeWebSocket.all).toHaveLength(1);
  });

  describe("waking up", () => {
    let win: EventTarget;
    let doc: EventTarget & { visibilityState: string };
    const online = () => win.dispatchEvent(new Event("online"));
    const visibility = (s: string) => {
      doc.visibilityState = s;
      doc.dispatchEvent(new Event("visibilitychange"));
    };

    beforeEach(() => {
      win = new EventTarget();
      doc = Object.assign(new EventTarget(), { visibilityState: "visible" });
      vi.stubGlobal("window", win);
      vi.stubGlobal("document", doc);
    });

    it("retries at once when the browser comes back online", () => {
      start();
      last().drop();
      vi.advanceTimersByTime(500);
      online();
      expect(FakeWebSocket.all).toHaveLength(2);
      expect(state().state).toBe("connecting");
    });

    it("replaces the pending retry instead of adding a socket", () => {
      start();
      last().drop();
      online();
      vi.advanceTimersByTime(1000); // when the old retry was due
      expect(FakeWebSocket.all).toHaveLength(2);
    });

    it("retries when the tab becomes visible, not when it hides", () => {
      start();
      last().drop();
      visibility("hidden");
      expect(FakeWebSocket.all).toHaveLength(1);
      visibility("visible");
      expect(FakeWebSocket.all).toHaveLength(2);
    });

    it("leaves a healthy socket and a fresh attempt alone", () => {
      start();
      vi.advanceTimersByTime(2999);
      online();
      expect(FakeWebSocket.all).toHaveLength(1);
      live();
      vi.advanceTimersByTime(2999);
      visibility("visible");
      online();
      expect(FakeWebSocket.all).toHaveLength(1);
      expect(state().state).toBe("open");
    });

    it("replaces a socket that went quiet without waiting for the stale timeout", () => {
      start();
      live();
      const old = last();
      vi.advanceTimersByTime(3000);
      visibility("visible");
      expect(old.closed).toBe(true);
      expect(FakeWebSocket.all).toHaveLength(2);
      expect(state()).toMatchObject({ state: "connecting", attempt: 1 });
      old.drop();
      expect(FakeWebSocket.all).toHaveLength(2);
    });

    it("replaces an attempt hanging when the network returns", () => {
      start();
      vi.advanceTimersByTime(3000);
      online();
      expect(FakeWebSocket.all[0].closed).toBe(true);
      expect(FakeWebSocket.all).toHaveLength(2);
    });

    it("stops listening after stop", () => {
      start();
      last().drop();
      stop();
      online();
      visibility("visible");
      expect(FakeWebSocket.all).toHaveLength(1);
    });
  });
});
