export const WS_URL: string = import.meta.env.VITE_WS_URL ?? "ws://localhost:8000/ws";

/** The only message that proves the fleet feed is alive: heartbeats keep flowing if the feed dies. */
export const FLEET_SNAPSHOT = "fleet.snapshot";

/** Without a snapshot for this long the socket is treated as dead (the backend sends one every second). */
const STALE_MS = 10000;

/** Coming back online or to the tab replaces a socket that has been quiet for this long. */
const WAKE_QUIET_MS = 3000;

type WsPhase = { state: "connecting" | "open" } | { state: "closed"; retryAt: number };

/** Connection state shown in the status bar. `open` means fleet data is flowing, not just a handshake. */
export type WsLink = WsPhase & {
  /** Consecutive failed attempts; 0 once fleet data arrives. */
  attempt: number;
  /** Last fleet snapshot received (epoch ms). */
  lastDataAt: number | null;
};

export const INITIAL_LINK: WsLink = { state: "connecting", attempt: 0, lastDataAt: null };

/** Same envelope the backend sends: {type, payload, ts}. */
export interface WsMessage {
  type: string;
  payload: Record<string, unknown>;
  ts: string;
}

export function parseMessage(raw: string): WsMessage | null {
  try {
    const m = JSON.parse(raw) as Partial<WsMessage>;
    return typeof m.type === "string" ? { type: m.type, payload: m.payload ?? {}, ts: m.ts ?? "" } : null;
  } catch {
    return null;
  }
}

export function backoffMs(attempt: number): number {
  return Math.min(15000, 1000 * 2 ** attempt);
}

/**
 * Keeps one WebSocket open and reconnects with exponential backoff (±20% so consoles don't retry in
 * step). A socket with no fleet snapshot for `staleMs` (half-open link: network drop, sleep, frozen
 * server, dead feed) is dropped and replaced. Coming back online or to the tab retries at once
 * instead of waiting for the backoff or the stale timeout. Returns a close function.
 */
export function connectWs(handlers: {
  onMessage: (m: WsMessage) => void;
  onStatus?: (l: WsLink) => void;
  url?: string;
  staleMs?: number;
}): () => void {
  const staleMs = handlers.staleMs ?? STALE_MS;
  let ws: WebSocket | null = null;
  let retryTimer: ReturnType<typeof setTimeout> | undefined;
  let staleTimer: ReturnType<typeof setTimeout> | undefined;
  let link = INITIAL_LINK;
  let attempt = 0;
  let lastDataAt: number | null = null;
  // Start of the current attempt or last snapshot, whichever is newer.
  let heardAt = 0;

  const emit = (phase: WsPhase) => {
    link = { ...phase, attempt, lastDataAt };
    handlers.onStatus?.(link);
  };

  const watch = () => {
    heardAt = Date.now();
    clearTimeout(staleTimer);
    staleTimer = setTimeout(drop, staleMs);
  };

  // Detaches the socket first so its late events are ignored.
  const release = () => {
    clearTimeout(staleTimer);
    if (!ws) return;
    ws.onmessage = ws.onclose = null;
    ws.close();
    ws = null;
  };

  function drop() {
    release();
    const delay = Math.round(backoffMs(attempt) * (0.8 + Math.random() * 0.4));
    attempt += 1;
    emit({ state: "closed", retryAt: Date.now() + delay });
    retryTimer = setTimeout(connect, delay);
  }

  function connect() {
    clearTimeout(retryTimer);
    emit({ state: "connecting" });
    try {
      ws = new WebSocket(handlers.url ?? WS_URL);
    } catch (e) {
      // Bad URL, or ws:// from an https page.
      console.error("WebSocket could not be created", e);
      drop();
      return;
    }
    watch();
    ws.onmessage = (ev) => {
      const m = parseMessage(String(ev.data));
      if (!m) return;
      if (m.type === FLEET_SNAPSHOT) {
        watch();
        attempt = 0;
        lastDataAt = Date.now();
        // Later snapshots are carried by the next status change; not worth a re-render per message.
        if (link.state !== "open") emit({ state: "open" });
      }
      handlers.onMessage(m);
    };
    ws.onclose = drop;
  }

  const wake = () => {
    if (globalThis.document?.visibilityState === "hidden") return;
    if (ws) {
      if (Date.now() - heardAt < WAKE_QUIET_MS) return;
      release();
      attempt += 1;
    }
    connect();
  };
  globalThis.window?.addEventListener("online", wake);
  globalThis.document?.addEventListener("visibilitychange", wake);

  connect();

  return () => {
    clearTimeout(retryTimer);
    release();
    globalThis.window?.removeEventListener("online", wake);
    globalThis.document?.removeEventListener("visibilitychange", wake);
  };
}
