export const API_URL: string = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

export interface HealthResponse {
  status: string;
}

export interface VersionResponse {
  version: string;
  driver: "sim" | "zenoh" | "nato";
}

export interface RuntimeSettings {
  driver: "sim" | "zenoh" | "nato";
  zenoh_connect: string;
  operator_id: string;
  default_speed_mps: number;
  lost_after_s: number;
}

export interface UavAdminRecord {
  id: string;
  name: string;
  domain: string | null;
  baseId: string | null;
  affiliation: "FRIEND" | "HOSTILE" | "NEUTRAL" | "UNKNOWN";
  platformType:
    | "ROTARY_UAV"
    | "FIXED_WING_UAV"
    | "WHEELED_UGV"
    | "TRACKED_UGV"
    | "USV"
    | "FOOT";
  callsign: string | null;
  higherFormation: string | null;
  echelon:
    | "TEAM" | "SQUAD" | "SECTION" | "PLATOON" | "COMPANY"
    | "BATTALION" | "REGIMENT" | "BRIGADE" | "DIVISION" | "CORPS"
    | null;
}

export type UavMetadataPatch = Partial<Omit<UavAdminRecord, "id" | "name" | "domain" | "baseId">>;

export interface AdminConfig {
  settings: RuntimeSettings;
  defaults: RuntimeSettings;
  origin: "environment" | "saved";
  status: {
    driver: string;
    connected: boolean;
    peers: number | null;
    assets: number;
    last_message_s: number | null;
  };
  persisted?: boolean;
}

export interface ProbeResult {
  ok: boolean;
  peers: number;
  detail: string;
}

async function get<T>(path: string, timeoutMs = 3000): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, { signal: AbortSignal.timeout(timeoutMs) });
  if (!res.ok) throw new Error(`${path} returned HTTP ${res.status}`);
  return (await res.json()) as T;
}

/** FastAPI errors are either {detail: "text"} or {detail: [{loc, msg}]} for validation. */
export function errorText(body: unknown, status: number): string {
  const detail = (body as { detail?: unknown } | null)?.detail;
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    return detail
      .map((d: { loc?: unknown[]; msg?: string }) => `${String(d.loc?.at(-1) ?? "")}: ${d.msg ?? "invalid"}`)
      .join("; ");
  }
  return `HTTP ${status}`;
}

async function admin<T>(token: string, method: string, path: string, body?: unknown, timeoutMs = 10000): Promise<T> {
  const res = await fetch(`${API_URL}/admin${path}`, {
    method,
    headers: { "X-Admin-Token": token, ...(body === undefined ? {} : { "Content-Type": "application/json" }) },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(timeoutMs),
  });
  const data: unknown = await res.json().catch(() => null);
  if (!res.ok) throw new Error(errorText(data, res.status));
  return data as T;
}

export const api = {
  health: () => get<HealthResponse>("/health"),
  version: () => get<VersionResponse>("/version"),
  getConfig: (token: string) => admin<AdminConfig>(token, "GET", "/config"),
  saveConfig: (token: string, s: RuntimeSettings) => admin<AdminConfig>(token, "PUT", "/config", s),
  resetConfig: (token: string) => admin<AdminConfig>(token, "DELETE", "/config"),
  testZenoh: (token: string, zenoh_connect: string) =>
    admin<ProbeResult>(token, "POST", "/config/test-zenoh", { zenoh_connect }, 15000),
  listUavs: (token: string) => admin<{ uavs: UavAdminRecord[] }>(token, "GET", "/uavs"),
  patchUav: (token: string, assetId: string, body: UavMetadataPatch) =>
    admin<UavAdminRecord>(token, "PATCH", `/uavs/${encodeURIComponent(assetId)}`, body),
};
