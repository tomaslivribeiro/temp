import type { ActionId, Base, BaseId, StateCode } from "./types";

export const STATE_LABEL: Record<StateCode, string> = {
  O: "Off · at base",
  S: "Standby · ready",
  T: "Taking off",
  H: "Hovering",
  M: "Mission",
  R: "Returning to base",
  L: "Landing",
  G: "Grounded · away from base",
};

export const STATE_ORDER: StateCode[] = ["M", "R", "T", "L", "H", "G", "S", "O"];
export const AIRBORNE: StateCode[] = ["T", "H", "M", "R", "L"];

export const BASES: Record<BaseId, Base> = {
  // Capgemini Portugal offices (coordinates geocoded from the public addresses; elevations approximate).
  ALFA: { id: "ALFA", name: "LISBOA · COLOMBO", lon: -9.1869, lat: 38.7542, elev: 100 },
  BRAVO: { id: "BRAVO", name: "PORTO · LAKE TOWERS", lon: -8.6392, lat: 41.1415, elev: 30 },
  CHARLIE: { id: "CHARLIE", name: "ÉVORA · SOMEFE", lon: -7.9008, lat: 38.564, elev: 280 },
  DELTA: { id: "DELTA", name: "FUNDÃO · CENTRO DE NEGÓCIOS", lon: -7.5022, lat: 40.1375, elev: 450 },
};

export const DISTRICTS: [string, number, number][] = [
  ["Viana do Castelo", -8.6, 41.85], ["Braga", -8.3, 41.6], ["Vila Real", -7.6, 41.4],
  ["Bragança", -6.8, 41.6], ["Porto", -8.45, 41.2], ["Aveiro", -8.5, 40.7],
  ["Viseu", -7.9, 40.75], ["Guarda", -7.2, 40.6], ["Coimbra", -8.3, 40.2],
  ["Castelo Branco", -7.4, 39.9], ["Leiria", -8.8, 39.7], ["Santarém", -8.5, 39.3],
  ["Portalegre", -7.6, 39.2], ["Lisboa", -9.15, 38.95], ["Setúbal", -8.7, 38.3],
  ["Évora", -7.9, 38.6], ["Beja", -7.9, 37.9], ["Faro", -8.1, 37.2],
  ["Madeira", -16.95, 32.75], ["Açores", -27.0, 38.5],
];

export const MAP_PRESETS = [
  { id: "all", label: "ALL", center: [-8.0, 39.6] as [number, number], zoom: 5.6 },
  { id: "lis", label: "LISBOA", center: [-9.1869, 38.7542] as [number, number], zoom: 9.5 },
  { id: "opo", label: "PORTO", center: [-8.6392, 41.1415] as [number, number], zoom: 9.5 },
  { id: "evo", label: "ÉVORA", center: [-7.9008, 38.564] as [number, number], zoom: 9.5 },
  { id: "fun", label: "FUNDÃO", center: [-7.5022, 40.1375] as [number, number], zoom: 9.5 },
];

export interface CommandDef {
  id: ActionId;
  label: string;
  hint: string;
}

export const COMMANDS: CommandDef[] = [
  { id: "poweron", label: "Power on", hint: "Start drone systems remotely" },
  { id: "takeoff", label: "Take off", hint: "Climb and hold position" },
  { id: "goto", label: "Go to route", hint: "Add route waypoints on the map" },
  { id: "changeb", label: "Change B", hint: "Pick a new point B on the map" },
  { id: "hold", label: "Hold", hint: "Stop and hold current position" },
  { id: "rtb", label: "Return to base", hint: "Fly back to home base" },
  { id: "land", label: "Land", hint: "Land at current position" },
  { id: "poweroff", label: "Power off", hint: "Shut down at base" },
];

export const ACTION_LABEL = Object.fromEntries(COMMANDS.map((c) => [c.id, c.label])) as Record<ActionId, string>;

/** Which commands are allowed in each drone state. */
export const COMMAND_MATRIX: Record<StateCode, ActionId[]> = {
  O: ["poweron"],
  S: ["takeoff", "goto", "poweroff"],
  T: ["hold"],
  H: ["goto", "rtb", "land"],
  M: ["hold", "changeb", "rtb", "land"],
  R: ["hold", "goto"],
  L: ["hold"],
  G: ["takeoff"],
};

export const STAGES = ["Sent", "Accepted by server", "Confirmed by drone", "Executing", "Completed"];

export const MAP_PICK_ACTIONS: ActionId[] = ["goto", "changeb"];
export const MIN_BATTERY_FOR_MISSION = 30;
