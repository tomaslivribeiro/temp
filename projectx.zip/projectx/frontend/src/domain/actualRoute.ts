import type { StateCode } from "./types";

/**
 * Actual route flown by an asset, built only from its reported positions.
 *
 * Port of `backend/src/c2/domain/actual_route.py`, used by the in-browser LocalSimulator so the dev mode
 * matches the backend. Keep both in sync: same tolerances, same lifecycle, same tests.
 *
 * Online "opening window" simplification: while every point stays within `toleranceM` of the line from the
 * last vertex to the newest point, nothing is committed. When a new point breaks that, the previous point
 * becomes a vertex. Turns at waypoints, deviations and curves inside a single goto all become vertices.
 * Past `maxVertices`, the interior vertex whose removal changes the line least is merged into its neighbours.
 */
export type Point = [number, number];

const M_PER_DEG_LAT = 110_570;
const M_PER_DEG_LON = 111_320;

const CLEARS_ROUTE: StateCode[] = ["S", "O"];
const STARTS_ROUTE: StateCode[] = ["M", "R"];

function toXY(p: Point, origin: Point): [number, number] {
  const cosLat = Math.cos((origin[1] * Math.PI) / 180);
  return [(p[0] - origin[0]) * M_PER_DEG_LON * cosLat, (p[1] - origin[1]) * M_PER_DEG_LAT];
}

export function distanceM(a: Point, b: Point): number {
  return Math.hypot(...toXY(b, a));
}

/** Distance in metres from `p` to the segment `a`-`b`. */
export function distanceToSegmentM(p: Point, a: Point, b: Point): number {
  const [px, py] = toXY(p, a);
  const [bx, by] = toXY(b, a);
  const length2 = bx * bx + by * by;
  const t = length2 === 0 ? 0 : Math.max(0, Math.min(1, (px * bx + py * by) / length2));
  return Math.hypot(px - t * bx, py - t * by);
}

export interface ActualRouteOptions {
  toleranceM?: number;
  minStepM?: number;
  maxVertices?: number;
  maxPending?: number;
}

export class ActualRoute {
  readonly toleranceM: number;
  private readonly minStepM: number;
  private readonly maxVertices: number;
  private readonly maxPending: number;
  vertices: Point[] = [];
  private pending: Point[] = [];
  private lastState: StateCode | null = null;
  private fresh = false; // reset() since the asset last moved (a goto already set the new origin)

  constructor({ toleranceM = 5, minStepM = 1, maxVertices = 500, maxPending = 200 }: ActualRouteOptions = {}) {
    this.toleranceM = toleranceM;
    this.minStepM = minStepM;
    this.maxVertices = maxVertices;
    this.maxPending = maxPending;
  }

  get active(): boolean {
    return this.vertices.length > 0;
  }

  reset(origin: Point): void {
    this.vertices = [[origin[0], origin[1]]];
    this.pending = [];
    this.fresh = true;
  }

  clear(): void {
    this.vertices = [];
    this.pending = [];
  }

  markVertex(p: Point): void {
    if (!this.active) {
      this.reset(p);
      return;
    }
    if (distanceM(this.vertices[this.vertices.length - 1], p) < this.minStepM) return;
    this.pending = [];
    this.addVertex(p);
  }

  update(p: Point): void {
    if (!this.active) {
      this.reset(p);
      return;
    }
    const last = this.pending.at(-1) ?? this.vertices[this.vertices.length - 1];
    if (distanceM(last, p) < this.minStepM) return;
    const point: Point = [p[0], p[1]];
    const anchor = this.vertices[this.vertices.length - 1];
    if (this.pending.some((q) => distanceToSegmentM(q, anchor, point) > this.toleranceM)) {
      // Every pending point fitted the line to the previous point, so that point is the vertex.
      this.addVertex(this.pending[this.pending.length - 1]);
      this.pending = [];
    }
    this.pending.push(point);
    if (this.pending.length > this.maxPending) {
      this.addVertex(point);
      this.pending = [];
    }
  }

  /** Applies the lifecycle for one position report in UI state `state`. */
  observe(state: StateCode, p: Point): void {
    const previous = this.lastState;
    this.lastState = state;
    if (CLEARS_ROUTE.includes(state)) {
      this.clear();
      return;
    }
    const moving = STARTS_ROUTE.includes(state);
    const restart = previous !== null && !STARTS_ROUTE.includes(previous) && this.active && !this.fresh;
    // Moving again after a stop without a goto (for example RTB after the mission): a new route from here.
    // A H -> M transition can be the next leg of the same goto, so extend that route instead of restarting it.
    if (state === "R" && restart) this.reset(p);
    else if (this.active || moving) this.update(p);
    if (moving) this.fresh = false;
  }

  /** Vertices plus the real points not yet confirmed as a vertex; the last one is the latest position. */
  polyline(): Point[] {
    return [...this.vertices, ...this.pending];
  }

  /** Drone fields for the snapshot: the polyline (origin first, latest position last). */
  snapshotFields(): { track: Point[] } {
    return { track: this.polyline() };
  }

  private addVertex(p: Point): void {
    this.vertices.push(p);
    if (this.vertices.length <= this.maxVertices) return;
    // Merge the least significant interior vertex (smallest distance to the line between its neighbours).
    const v = this.vertices;
    let best = 1;
    let bestErr = Infinity;
    for (let k = 1; k < v.length - 1; k++) {
      const err = distanceToSegmentM(v[k], v[k - 1], v[k + 1]);
      if (err < bestErr) [best, bestErr] = [k, err];
    }
    v.splice(best, 1);
  }
}
