/** No-fly zones as served by the backend (`GET /geozones`): GeoJSON polygons plus their sources. */

export type Restriction = "PROHIBITED" | "REQUIRES_AUTHORISATION" | "CONDITIONAL" | "NO_RESTRICTION";
export type AltitudeRef = "AGL" | "AMSL";

export interface GeozoneProperties {
  id: number;
  external_id: string;
  source_id: string;
  name: string;
  restriction: Restriction;
  reason: string | null;
  message: string | null;
  lower_m: number | null;
  upper_m: number | null;
  lower_ref: AltitudeRef | null;
  upper_ref: AltitudeRef | null;
  valid_from: string | null;
  valid_to: string | null;
  shape_type: "circle" | "rectangle" | "polygon" | "multipolygon";
}

export interface GeozoneSource {
  id: string;
  name: string;
  url: string | null;
  attribution: string;
  license_note: string | null;
  dataset_version: string | null;
  retrieved_at: string | null;
}

export interface GeozoneCollection {
  type: "FeatureCollection";
  features: {
    type: "Feature";
    id: number;
    geometry: { type: "Polygon" | "MultiPolygon"; coordinates: unknown };
    properties: GeozoneProperties;
  }[];
  sources: GeozoneSource[];
}

/** Colour and label per restriction, shared by the map layers (MapView) and the legend. Listed from most to least severe. */
export const GEOZONE_STYLES: Record<Restriction, { color: string; fillOpacity: number; label: string }> = {
  PROHIBITED: { color: "#E5484D", fillOpacity: 0.28, label: "Flights prohibited" },
  REQUIRES_AUTHORISATION: { color: "#F5A524", fillOpacity: 0.2, label: "Authorisation required" },
  CONDITIONAL: { color: "#E6D84A", fillOpacity: 0.16, label: "Conditions apply" },
  NO_RESTRICTION: { color: "#46B07A", fillOpacity: 0.08, label: "No restriction" },
};

const SEVERITY = Object.keys(GEOZONE_STYLES);

/** Most severe first (red → orange → yellow → green); unknown restrictions go last. Returns a new array. */
export function sortBySeverity<T>(items: T[], restrictionOf: (item: T) => Restriction): T[] {
  const rank = (item: T) => {
    const i = SEVERITY.indexOf(restrictionOf(item));
    return i === -1 ? SEVERITY.length : i;
  };
  return [...items].sort((a, b) => rank(a) - rank(b));
}

/** MapLibre `match` expression picking a per-restriction value from `properties.restriction`. */
export function byRestriction<T extends string | number>(pick: (s: (typeof GEOZONE_STYLES)[Restriction]) => T, fallback: T) {
  const entries = (Object.keys(GEOZONE_STYLES) as Restriction[]).flatMap((r) => [r, pick(GEOZONE_STYLES[r])]);
  return ["match", ["get", "restriction"], ...entries, fallback] as unknown as T;
}

function limit(m: number | null, ref: AltitudeRef | null, ground: string): string {
  if (m === null) return "—";
  return m === 0 && ref === "AGL" ? ground : `${Math.round(m)} m ${ref ?? ""}`.trim();
}

/** "GND – 120 m AGL"; "—" when the source gives no limits. */
export function describeAltitude(p: Pick<GeozoneProperties, "lower_m" | "upper_m" | "lower_ref" | "upper_ref">): string {
  if (p.lower_m === null && p.upper_m === null) return "—";
  return `${limit(p.lower_m, p.lower_ref, "GND")} – ${limit(p.upper_m, p.upper_ref, "unlimited")}`;
}

const stamp = (iso: string) => iso.slice(0, 16).replace("T", " ") + " UTC";

/** Validity window in UTC; "" for a permanent zone. */
export function describeValidity(p: Pick<GeozoneProperties, "valid_from" | "valid_to">): string {
  if (p.valid_from && p.valid_to) return `${stamp(p.valid_from)} → ${stamp(p.valid_to)}`;
  if (p.valid_from) return `from ${stamp(p.valid_from)}`;
  if (p.valid_to) return `until ${stamp(p.valid_to)}`;
  return "";
}

/** Credit line shown while the layer is visible, built from the sources the backend returned. */
export function geozonesNotice(sources: GeozoneSource[]): string {
  if (sources.length === 0) return "";
  const credit = sources
    .map((s) => (s.dataset_version ? `${s.attribution} · ${s.dataset_version}` : s.attribution))
    .join(" | ");
  return `${credit}. Decision support only: does not replace the official source.`;
}
