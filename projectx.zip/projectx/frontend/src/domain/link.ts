import type { WsLink } from "../api/wsClient";
import { mmss } from "./format";
import type { Alert, Drone, FleetSnapshot, Link } from "./types";

/** Telemetry freshness: how long since the last message from the drone. */
export function linkOf(d: Drone): Link {
  if (d.state === "O") return { kind: "off", label: "Powered off", short: "Off" };
  if (d.hb >= 10) return { kind: "lost", label: `No contact · ${mmss(d.hb)}`, short: "No contact" };
  if (d.hb >= 3) return { kind: "delayed", label: `Delayed · ${d.hb} s`, short: `Delayed ${d.hb}s` };
  return { kind: "ok", label: "Live", short: "Live" };
}

/** Telemetry stops with the feed, so while it is down every drone's `hb` keeps growing by the feed's age. */
export function ageSnapshot(snap: FleetSnapshot, ageS: number): FleetSnapshot {
  if (ageS <= 0) return snap;
  return { ...snap, drones: snap.drones.map((d) => ({ ...d, hb: d.hb + ageS })) };
}

/** Seconds since the last fleet data (0 if none has arrived yet). */
export function dataAgeS(ws: WsLink, now: number): number {
  return ws.lastDataAt === null ? 0 : Math.max(0, Math.floor((now - ws.lastDataAt) / 1000));
}

/** Top bar status of the fleet feed at time `now`. */
export function wsLinkOf(ws: WsLink, now: number): Pick<Link, "kind" | "label"> {
  if (ws.state === "open") return { kind: "ok", label: "WS: connected" };
  if (ws.state === "connecting" && ws.attempt === 0) return { kind: "off", label: "WS: connecting…" };
  const s = dataAgeS(ws, now);
  const age = ws.lastDataAt === null ? "" : ` · data ${s >= 60 ? mmss(s) : `${s}s`} old`;
  // The retry stays visible for the whole outage: counting down while waiting, "now" while an attempt runs.
  const retry =
    ws.state === "closed" ? `retry in ${Math.max(0, Math.ceil((ws.retryAt - now) / 1000))}s` : "retrying now";
  return { kind: "lost", label: `WS: disconnected · ${retry} (attempt ${ws.attempt})${age}` };
}

export function alertsOf(d: Drone, link: Link): Alert[] {
  const out: Alert[] = [];
  if (link.kind === "lost") out.push({ sev: 2, text: `No contact for ${mmss(d.hb)}. Showing last known state.` });
  if (link.kind === "delayed") out.push({ sev: 1, text: `Telemetry delayed ${d.hb} s.` });
  if (d.state !== "O") {
    if (d.bat < 15) out.push({ sev: 2, text: `Battery critical (${Math.round(d.bat)}%).` });
    else if (d.bat < 30) out.push({ sev: 1, text: `Battery low (${Math.round(d.bat)}%).` });
    if (d.gps === "weak") out.push({ sev: 1, text: `Position unreliable: GPS weak (${d.sats} satellites).` });
  }
  return out;
}

export function maxSeverity(alerts: Alert[]): 0 | 1 | 2 {
  return alerts.reduce<0 | 1 | 2>((m, a) => (a.sev > m ? a.sev : m), 0);
}
