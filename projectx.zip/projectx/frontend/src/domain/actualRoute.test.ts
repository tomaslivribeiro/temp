import { describe, expect, it } from "vitest";
import { ActualRoute, distanceToSegmentM, type Point } from "./actualRoute";

/** Local metres (x east, y north) to [lon, lat] around (0, 0). */
const pt = (x: number, y: number): Point => [x / 111_320, y / 110_570];

function feed(route: ActualRoute, points: Point[]): void {
  route.reset(points[0]);
  for (const p of points.slice(1)) route.update(p);
}

const range = (n: number) => Array.from({ length: n }, (_, i) => i);

describe("ActualRoute", () => {
  it("has no polyline before it starts", () => {
    const route = new ActualRoute();
    expect(route.active).toBe(false);
    expect(route.polyline()).toEqual([]);
  });

  it("keeps only the origin as vertex on a straight flight", () => {
    const route = new ActualRoute();
    feed(route, range(30).map((i) => pt(i * 15, 0)));
    expect(route.vertices).toEqual([pt(0, 0)]);
    expect(route.polyline().at(-1)).toEqual(pt(29 * 15, 0));
  });

  it("creates a vertex at a corner", () => {
    const route = new ActualRoute();
    feed(route, [...range(11).map((i) => pt(i * 15, 0)), ...range(10).map((j) => pt(150, (j + 1) * 15))]);
    expect(route.vertices).toEqual([pt(0, 0), pt(150, 0)]);
  });

  it("creates a vertex on a lateral deviation and none for jitter", () => {
    const deviated = new ActualRoute();
    feed(deviated, [...range(10).map((i) => pt(i * 15, 0)), pt(150, 20), ...range(9).map((i) => pt(165 + i * 15, 0))]);
    expect(deviated.vertices).toContainEqual(pt(150, 20));

    const jitter = new ActualRoute();
    feed(jitter, range(40).map((i) => pt(i * 15, i % 2 ? 2 : -2)));
    expect(jitter.vertices).toHaveLength(1);
  });

  it("follows a curve inside a single goto within the tolerance", () => {
    const route = new ActualRoute();
    const arc = range(37).map((i) => {
      const a = (i * 5 * Math.PI) / 180;
      return pt(100 * Math.sin(a), 100 * (1 - Math.cos(a)));
    });
    feed(route, arc);
    const line = route.polyline();
    expect(route.vertices.length).toBeGreaterThanOrEqual(3);
    for (const p of arc) {
      const nearest = Math.min(...line.slice(1).map((b, i) => distanceToSegmentM(p, line[i], b)));
      expect(nearest).toBeLessThanOrEqual(route.toleranceM + 1e-6);
    }
  });

  it("ignores tiny moves and caps vertices keeping the origin", () => {
    const still = new ActualRoute();
    feed(still, [pt(0, 0), pt(0.2, 0.1), pt(0.1, 0.3)]);
    expect(still.polyline()).toEqual([pt(0, 0)]);

    const capped = new ActualRoute({ maxVertices: 5 });
    feed(capped, range(30).map((i) => pt(i * 50, i % 2 ? 50 : 0)));
    expect(capped.vertices).toHaveLength(5);
    expect(capped.vertices[0]).toEqual(pt(0, 0));
  });

  it("on overflow drops the smallest wiggle, not a real turn", () => {
    const route = new ActualRoute({ toleranceM: 5, maxVertices: 6 });
    const east = range(11).map((i) => pt(i * 100, i % 2 ? 10 : 0));
    const north = range(10).map((i) => pt(1000 + ((i + 1) % 2 ? 10 : 0), (i + 1) * 100));
    feed(route, [...east, ...north]);
    expect(route.vertices).toHaveLength(6);
    const d = (v: Point) => Math.hypot(v[0] - pt(1000, 0)[0], v[1] - pt(1000, 0)[1]) * 111_320;
    expect(Math.min(...route.vertices.map(d))).toBeLessThan(150);
  });

  it("starts a new route when moving again after a stop (RTB after the mission)", () => {
    const route = new ActualRoute();
    route.observe("M", pt(0, 0));
    route.observe("M", pt(500, 0));
    route.observe("H", pt(500, 0));
    route.observe("R", pt(500, 0));
    route.observe("R", pt(400, 0));
    expect(route.polyline()).toEqual([pt(500, 0), pt(400, 0)]);
  });

  it("extends the same route across a hover between mission legs", () => {
    const route = new ActualRoute();
    route.observe("M", pt(0, 0));
    route.observe("M", pt(15, 0));
    route.observe("H", pt(15, 0));
    route.observe("M", pt(30, 0));
    expect(route.polyline()).toEqual([pt(0, 0), pt(15, 0), pt(30, 0)]);
  });

  it("follows the asset lifecycle", () => {
    const route = new ActualRoute();
    route.observe("M", pt(0, 0));
    route.observe("M", pt(15, 0));
    expect(route.polyline()).toEqual([pt(0, 0), pt(15, 0)]);
    route.observe("H", pt(15, 0));
    expect(route.active).toBe(true);
    route.observe("S", pt(15, 0));
    expect(route.active).toBe(false);
    route.observe("H", pt(15, 0));
    expect(route.active).toBe(false);
  });

  it("exposes only the polyline", () => {
    const route = new ActualRoute();
    feed(route, [pt(0, 0), pt(15, 0), pt(30, 0), pt(30, 15), pt(30, 30)]);
    expect(route.snapshotFields()).toEqual({ track: [pt(0, 0), pt(30, 0), pt(30, 15), pt(30, 30)] });
  });
});
