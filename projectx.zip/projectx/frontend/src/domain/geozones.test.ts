import { describe, expect, it } from "vitest";
import {
  GEOZONE_STYLES,
  byRestriction,
  describeAltitude,
  describeValidity,
  geozonesNotice,
  sortBySeverity,
  type GeozoneSource,
  type Restriction,
} from "./geozones";

const source: GeozoneSource = {
  id: "anac",
  name: "ANAC",
  url: null,
  attribution: "Fonte: ANAC",
  license_note: null,
  dataset_version: "ED-318 2026-11-20",
  retrieved_at: null,
};

describe("describeAltitude", () => {
  it("writes ground-to-ceiling limits with their reference", () => {
    expect(describeAltitude({ lower_m: 0, upper_m: 120, lower_ref: "AGL", upper_ref: "AGL" })).toBe("GND – 120 m AGL");
    expect(describeAltitude({ lower_m: 0, upper_m: 762.4, lower_ref: "AMSL", upper_ref: "AMSL" })).toBe("0 m AMSL – 762 m AMSL");
  });
  it("shows a dash when the source gives no limits", () => {
    expect(describeAltitude({ lower_m: null, upper_m: null, lower_ref: null, upper_ref: null })).toBe("—");
  });
});

describe("describeValidity", () => {
  it("is empty for a permanent zone and spells out a window otherwise", () => {
    expect(describeValidity({ valid_from: null, valid_to: null })).toBe("");
    expect(describeValidity({ valid_from: "2026-11-20T06:00:00+00:00", valid_to: "2026-11-22T22:00:00+00:00" })).toBe(
      "2026-11-20 06:00 UTC → 2026-11-22 22:00 UTC",
    );
    expect(describeValidity({ valid_from: null, valid_to: "2027-12-31T00:00:00+00:00" })).toBe("until 2027-12-31 00:00 UTC");
  });
});

describe("geozonesNotice", () => {
  it("is built from the sources and says it does not replace the official source", () => {
    expect(geozonesNotice([source])).toBe(
      "Fonte: ANAC · ED-318 2026-11-20. Decision support only: does not replace the official source.",
    );
    expect(geozonesNotice([])).toBe("");
  });
});

describe("byRestriction", () => {
  it("builds a match expression covering every restriction", () => {
    const expr = byRestriction((s) => s.color, "#888") as unknown as unknown[];
    expect(expr.slice(0, 2)).toEqual(["match", ["get", "restriction"]]);
    for (const [restriction, style] of Object.entries(GEOZONE_STYLES)) {
      expect(expr).toContain(restriction);
      expect(expr).toContain(style.color);
    }
  });
});

describe("sortBySeverity", () => {
  it("orders zones from red to green, keeping the order within a colour", () => {
    const zones: { id: string; restriction: Restriction }[] = [
      { id: "green", restriction: "NO_RESTRICTION" },
      { id: "orange-1", restriction: "REQUIRES_AUTHORISATION" },
      { id: "yellow", restriction: "CONDITIONAL" },
      { id: "red", restriction: "PROHIBITED" },
      { id: "orange-2", restriction: "REQUIRES_AUTHORISATION" },
    ];
    expect(sortBySeverity(zones, (z) => z.restriction).map((z) => z.id)).toEqual(["red", "orange-1", "orange-2", "yellow", "green"]);
    expect(zones[0].id).toBe("green");
  });
  it("puts an unknown restriction last", () => {
    const zones = [{ restriction: "OTHER" as Restriction }, { restriction: "NO_RESTRICTION" as Restriction }];
    expect(sortBySeverity(zones, (z) => z.restriction).map((z) => z.restriction)).toEqual(["NO_RESTRICTION", "OTHER"]);
  });
});
