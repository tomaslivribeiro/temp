import { describe, expect, it } from "vitest";
import { actionStates, blockedReason } from "./commands";
import { COMMAND_MATRIX } from "./constants";
import { fmtPosition } from "./format";
import { advance, km } from "./geo";
import { ageSnapshot, alertsOf, dataAgeS, linkOf, wsLinkOf } from "./link";
import type { WsLink } from "../api/wsClient";
import type { Drone } from "./types";

describe("advance", () => {
  it("moves along the heading by the requested distance", () => {
    const from = { lon: -9, lat: 38.8 };
    for (const hdg of [0, 90, 135, 270]) {
      expect(km(from, advance(from, hdg, 1000))).toBeCloseTo(1, 2);
    }
    expect(advance(from, 0, 1000).lat).toBeGreaterThan(from.lat);
    expect(advance(from, 90, 1000).lon).toBeGreaterThan(from.lon);
  });
});

const drone = (over: Partial<Drone> = {}): Drone => ({
  id: "X", state: "H", base: "ALFA", lon: -9, lat: 38.8, alt: 100, spd: 0, hdg: 0, bat: 80, hb: 0,
  flaky: false, lost: false, gps: "good", sats: 14, trail: [], a: null, b: null, timer: 0, ...over,
});

describe("link", () => {
  it("derives status from heartbeat age", () => {
    expect(linkOf(drone({ hb: 0 })).kind).toBe("ok");
    expect(linkOf(drone({ hb: 3 })).kind).toBe("delayed");
    expect(linkOf(drone({ hb: 10 })).kind).toBe("lost");
    expect(linkOf(drone({ state: "O", hb: 50 })).kind).toBe("off");
  });

  it("raises battery and GPS alerts", () => {
    const d = drone({ bat: 12, gps: "weak", sats: 4 });
    const a = alertsOf(d, linkOf(d));
    expect(a.map((x) => x.sev).sort()).toEqual([1, 2]);
  });
});

describe("feed outage", () => {
  const ws = (l: Partial<WsLink> = {}) => ({ state: "open", attempt: 0, lastDataAt: null, ...l }) as WsLink;

  it("ages telemetry so drones go delayed and then lost", () => {
    const snap = { t: 0, startMs: 0, drones: [drone({ hb: 1 })], cmds: [] };
    expect(ageSnapshot(snap, 0)).toBe(snap);
    expect(linkOf(ageSnapshot(snap, 3).drones[0]).kind).toBe("delayed");
    const lost = ageSnapshot(snap, 24).drones[0];
    expect(linkOf(lost).kind).toBe("lost");
    expect(alertsOf(lost, linkOf(lost))[0].text).toContain("00:25");
    expect(snap.drones[0].hb).toBe(1);
  });

  it("measures the age of the last data", () => {
    expect(dataAgeS(ws(), 5000)).toBe(0);
    expect(dataAgeS(ws({ lastDataAt: 1000 }), 3999)).toBe(2);
    expect(dataAgeS(ws({ lastDataAt: 1000 }), 0)).toBe(0);
  });

  it("describes each connection state", () => {
    expect(wsLinkOf(ws(), 0)).toEqual({ kind: "ok", label: "WS: connected" });
    expect(wsLinkOf(ws({ state: "connecting" }), 0)).toEqual({ kind: "off", label: "WS: connecting…" });
    expect(wsLinkOf(ws({ state: "closed", attempt: 2, retryAt: 4000 }), 1500)).toEqual({
      kind: "lost",
      label: "WS: disconnected · retry in 3s (attempt 2)",
    });
  });

  it("keeps the retry visible while an attempt is running", () => {
    expect(wsLinkOf(ws({ state: "connecting", attempt: 3 }), 0)).toEqual({
      kind: "lost",
      label: "WS: disconnected · retrying now (attempt 3)",
    });
  });

  it("adds the age of the last data while not connected", () => {
    expect(wsLinkOf(ws({ state: "closed", attempt: 1, retryAt: 1000, lastDataAt: 0 }), 12000).label).toBe(
      "WS: disconnected · retry in 0s (attempt 1) · data 12s old",
    );
    expect(wsLinkOf(ws({ state: "connecting", attempt: 1, lastDataAt: 0 }), 75000).label).toBe(
      "WS: disconnected · retrying now (attempt 1) · data 01:15 old",
    );
    expect(wsLinkOf(ws({ lastDataAt: 0 }), 75000).label).toBe("WS: connected");
  });
});

describe("commands", () => {
  it("only enables commands allowed by the state matrix", () => {
    const d = drone({ state: "M" });
    const enabled = actionStates(d, false).filter((a) => !a.disabled).map((a) => a.id).sort();
    expect(enabled).toEqual([...COMMAND_MATRIX.M].sort());
  });

  it("blocks goto when GPS is weak and takeoff when battery is critical", () => {
    const h = actionStates(drone({ state: "H", gps: "weak" }), false);
    expect(h.find((a) => a.id === "goto")?.disabled).toBe(true);
    const s = actionStates(drone({ state: "S", bat: 10 }), false);
    expect(s.find((a) => a.id === "takeoff")?.disabled).toBe(true);
  });

  it("blocks everything for observers, lost link and in-flight commands", () => {
    const d = drone();
    const link = linkOf(d);
    expect(blockedReason(d, link, false, "OBSERVER")).not.toBe("");
    expect(blockedReason(d, link, true, "OPERATOR")).not.toBe("");
    expect(blockedReason(d, linkOf(drone({ hb: 20 })), false, "OPERATOR")).not.toBe("");
    expect(blockedReason(d, link, false, "OPERATOR")).toBe("");
    expect(blockedReason(d, link, false, "OPERATOR", true)).toContain("Connection to the server lost");
    expect(blockedReason(drone({ state: "O", hb: 0 }), linkOf(drone({ state: "O" })), false, "OPERATOR", true)).not.toBe("");
  });
});

describe("fmtPosition", () => {
  it("shows lat/lon for a geo position", () => {
    expect(fmtPosition({ lon: -9.1, lat: 38.95 })).toBe("38.95000, -9.10000");
  });

  it("shows CARLA metres for a local position, so 1 m is visible", () => {
    const p = { lon: 0.000635109, lat: -0.001200149 };
    expect(fmtPosition(p, "local")).toBe("X 70.7 m, Y 133.6 m");
    expect(fmtPosition({ lon: 0.000635109 + 1 / 111319.49, lat: p.lat }, "local")).toBe("X 71.7 m, Y 133.6 m");
  });
});
