import { BASES, COMMANDS, COMMAND_MATRIX, POINT_B_ACTIONS, STATE_LABEL } from "./constants";
import type { ActionId, Drone, Link } from "./types";

export interface ActionState {
  id: ActionId;
  label: string;
  sub: string;
  disabled: boolean;
}

export type Profile = "OPERATOR" | "OBSERVER";

/** Why the operator cannot send any command to this drone right now ("" = can send). */
export function blockedReason(
  d: Drone,
  link: Link,
  hasActiveCommand: boolean,
  profile: Profile,
  feedDown = false,
): string {
  if (profile === "OBSERVER") return "Your profile (Observer) can view but not send commands.";
  if (feedDown) return "Connection to the server lost. Commands are blocked until live data is restored.";
  if (link.kind === "lost") return `No contact with ${d.id}. Commands are blocked until contact is restored.`;
  if (hasActiveCommand) return `A command is in progress for ${d.id}. Wait for it to finish.`;
  return "";
}

/** Per-command availability for the selected drone, enabled commands first. */
export function actionStates(d: Drone, blocked: boolean): ActionState[] {
  const base = BASES[d.base];
  const list = COMMANDS.map((c): ActionState => {
    let reason: string | null = null;
    if (!COMMAND_MATRIX[d.state].includes(c.id)) reason = `Not available while ${STATE_LABEL[d.state].toLowerCase()}`;
    else if (POINT_B_ACTIONS.includes(c.id) && d.gps === "weak") reason = "Position unreliable (GPS weak)";
    else if ((POINT_B_ACTIONS.includes(c.id) || c.id === "takeoff") && d.bat < 15) {
      reason = `Battery critical (${Math.round(d.bat)}%)`;
    }
    return {
      id: c.id,
      label: c.label,
      sub: reason ?? (c.id === "rtb" ? `Fly back to ${base.name}` : c.hint),
      disabled: blocked || reason !== null,
    };
  });
  return [...list.filter((a) => !a.disabled), ...list.filter((a) => a.disabled)];
}
