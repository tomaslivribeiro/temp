import { DISTRICTS } from "./constants";
import type { LonLat } from "./types";

/** Approximate distance in km (equirectangular; fine at fleet scale). */
export function km(a: LonLat, b: LonLat): number {
  const la = ((a.lat + b.lat) / 2) * (Math.PI / 180);
  return Math.hypot((b.lon - a.lon) * 111.32 * Math.cos(la), (b.lat - a.lat) * 110.57);
}

/** Bearing in degrees [0, 360). */
export function bearing(from: LonLat, to: LonLat): number {
  const la = from.lat * (Math.PI / 180);
  const deg = Math.atan2((to.lon - from.lon) * 111.32 * Math.cos(la), (to.lat - from.lat) * 110.57);
  return ((deg * 180) / Math.PI + 360) % 360;
}

/** Point reached moving `meters` from `from` along `headingDeg` (0 = north). */
export function advance(from: LonLat, headingDeg: number, meters: number): LonLat {
  const h = (headingDeg * Math.PI) / 180;
  const la = from.lat * (Math.PI / 180);
  return {
    lon: from.lon + (meters * Math.sin(h)) / (111_320 * Math.cos(la)),
    lat: from.lat + (meters * Math.cos(h)) / 110_570,
  };
}

export function regionOf(p: LonLat): string {
  let best = DISTRICTS[0][0];
  let bestKm = Infinity;
  for (const [name, lon, lat] of DISTRICTS) {
    const d = km(p, { lon, lat });
    if (d < bestKm) {
      bestKm = d;
      best = name;
    }
  }
  return best;
}
