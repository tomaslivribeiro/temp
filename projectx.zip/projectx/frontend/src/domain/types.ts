import type { WsLink } from "../api/wsClient";

export type StateCode = "O" | "S" | "T" | "H" | "M" | "R" | "L" | "G";
export type BaseId = "ALFA" | "BRAVO" | "CHARLIE" | "DELTA";
export type ActionId =
  | "poweron"
  | "takeoff"
  | "goto"
  | "changeb"
  | "hold"
  | "rtb"
  | "land"
  | "poweroff";

export interface LonLat {
  lon: number;
  lat: number;
}

export interface Base extends LonLat {
  id: BaseId;
  name: string;
  elev: number;
}

export type Affiliation = "FRIEND" | "HOSTILE" | "NEUTRAL" | "UNKNOWN";
export type PlatformType =
  | "ROTARY_UAV"
  | "FIXED_WING_UAV"
  | "WHEELED_UGV"
  | "TRACKED_UGV"
  | "USV"
  | "FOOT";
export type Echelon =
  | "TEAM"
  | "SQUAD"
  | "SECTION"
  | "PLATOON"
  | "COMPANY"
  | "BATTALION"
  | "REGIMENT"
  | "BRIGADE"
  | "DIVISION"
  | "CORPS";

export interface Drone extends LonLat {
  id: string;
  state: StateCode;
  base: BaseId;
  alt: number;
  spd: number;
  hdg: number;
  /** Optional sensor sector dimensions: opening angle in degrees and range in meters. */
  horizontal_fov?: number | null;
  visual_los?: number | null;
  bat: number;
  /** Seconds since the last telemetry message. */
  hb: number;
  flaky: boolean;
  lost: boolean;
  gps: "good" | "weak";
  sats: number;
  trail: [number, number][];
  /** Actual route flown as `[lon, lat]` vertices: origin first, latest position last. Empty when inactive. */
  track?: [number, number][];
  a: LonLat | null;
  b: LonLat | null;
  timer: number;
  /** How the operator reads this position: `local` = map metres (CARLA), `geo` (default) = lat/lon. */
  frame?: "geo" | "local";
  /** NATO APP-6 metadata. Optional until the backend migration is deployed; defaults applied client-side. */
  affiliation?: Affiliation;
  platformType?: PlatformType;
  callsign?: string | null;
  higherFormation?: string | null;
  echelon?: Echelon | null;
}

export type LinkKind = "ok" | "delayed" | "lost" | "off" | "unk";

export interface Link {
  kind: LinkKind;
  label: string;
  short: string;
}

export interface Alert {
  sev: 1 | 2;
  text: string;
}

export type CommandOutcome = "completed" | "rejected" | "unknown";

export interface Command {
  key: number;
  droneId: string;
  action: ActionId;
  b: LonLat | null;
  /** Index into STAGES. */
  stage: number;
  times: string[];
  final?: CommandOutcome;
  reason?: string;
}

export interface FleetSnapshot {
  /** Simulation seconds since start. */
  t: number;
  startMs: number;
  drones: Drone[];
  cmds: Command[];
}

/** Where fleet data comes from: the backend (WebSocket + REST) or the local simulator. */
export interface FleetSource {
  readonly kind: "ws" | "local";
  snapshot(): FleetSnapshot;
  start(listener: (s: FleetSnapshot) => void, onStatus?: (s: WsLink) => void): () => void;
  send(droneId: string, action: ActionId, b?: LonLat | null): void;
}
