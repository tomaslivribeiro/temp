const p2 = (v: number) => String(v).padStart(2, "0");
const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

/** Date-time group, UTC, e.g. 201510Z OCT 26. */
export function dtg(ms: number): string {
  const d = new Date(ms);
  return (
    p2(d.getUTCDate()) + p2(d.getUTCHours()) + p2(d.getUTCMinutes()) + "Z " +
    MONTHS[d.getUTCMonth()] + " " + String(d.getUTCFullYear()).slice(2)
  );
}

export function hms(ms: number): string {
  const d = new Date(ms);
  return `${p2(d.getUTCHours())}:${p2(d.getUTCMinutes())}:${p2(d.getUTCSeconds())}Z`;
}

export function mmss(totalSeconds: number): string {
  return `${p2(Math.floor(totalSeconds / 60))}:${p2(totalSeconds % 60)}`;
}

const EARTH_RADIUS_M = 6378137;

/** Inverse of the backend's CARLA conversion: a map lon/lat back to local X (east) and Y (south) metres. */
export function lonLatToLocal(p: { lon: number; lat: number }): { x: number; y: number } {
  return {
    x: (p.lon * Math.PI * EARTH_RADIUS_M) / 180,
    y: -Math.asinh(Math.tan((p.lat * Math.PI) / 180)) * EARTH_RADIUS_M,
  };
}

/** A position as the operator should read it: metres for a `local` frame, lat/lon otherwise. */
export function fmtPosition(p: { lon: number; lat: number }, frame: "geo" | "local" = "geo"): string {
  if (frame === "geo") return fmtLonLat(p);
  const { x, y } = lonLatToLocal(p);
  return `X ${x.toFixed(1)} m, Y ${y.toFixed(1)} m`;
}

export function fmtLonLat(p: { lon: number; lat: number }): string {
  return `${p.lat.toFixed(5)}, ${p.lon.toFixed(5)}`;
}
