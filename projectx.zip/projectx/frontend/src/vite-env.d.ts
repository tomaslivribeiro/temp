/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_URL?: string;
  readonly VITE_WS_URL?: string;
  readonly VITE_MAP_TILES_URL?: string;
  readonly VITE_FLEET_SOURCE?: "ws" | "local";
  readonly VITE_MOCK_CONSOLE_URL?: string;
}
