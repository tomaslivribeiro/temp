import { useMemo, useState } from "react";
import { STATE_LABEL, STATE_ORDER } from "../domain/constants";
import { regionOf } from "../domain/geo";
import { alertsOf, linkOf, maxSeverity } from "../domain/link";
import type { Drone } from "../domain/types";

interface Props {
  drones: Drone[];
  openTabs: string[];
  onOpen: (id: string) => void;
  onHover: (id: string | null) => void;
}

export function FleetList({ drones, openTabs, onOpen, onHover }: Props) {
  const [group, setGroup] = useState<"region" | "state">("region");
  const [search, setSearch] = useState("");

  const groups = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = drones.filter((d) => !q || d.id.toLowerCase().includes(q));
    const map = new Map<string, Drone[]>();
    for (const d of list) {
      const key = group === "region" ? regionOf(d) : STATE_LABEL[d.state];
      map.set(key, [...(map.get(key) ?? []), d]);
    }
    const keys = [...map.keys()];
    if (group === "state") keys.sort((a, b) => order(a) - order(b));
    else keys.sort();
    return keys.map((k) => [k, map.get(k)!] as const);
  }, [drones, group, search]);

  return (
    <aside className="panel a-list">
      <div className="search">
        <input placeholder="Search UAV…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search UAV" />
        <div className="seg">
          <button className={group === "region" ? "on" : ""} onClick={() => setGroup("region")}>Region</button>
          <button className={group === "state" ? "on" : ""} onClick={() => setGroup("state")}>State</button>
        </div>
      </div>
      {groups.map(([name, list]) => (
        <section className="grp" key={name}>
          <div className="grp-h cap">
            <span>{name}</span>
            <span className="muted">{list.length}</span>
          </div>
          {list.map((d) => {
            const link = linkOf(d);
            const sev = maxSeverity(alertsOf(d, link));
            return (
              <button
                key={d.id}
                className={`row${openTabs.includes(d.id) ? " open" : ""}`}
                onClick={() => onOpen(d.id)}
                onMouseEnter={() => onHover(d.id)}
                onMouseLeave={() => onHover(null)}
              >
                <span className="lt mono">{d.state}</span>
                <span className="row-col">
                  <span className="row-id">
                    {d.id}
                    {sev > 0 && <span className={`bd sev${sev}`}>{sev === 2 ? "!!" : "!"}</span>}
                  </span>
                  {group === "state" && <span className="row-rg">{regionOf(d)}</span>}
                </span>
                <span className="row-m">
                  <span className={`lk-${link.kind}`}>{link.short}</span>
                  <span className={`row-bat ${d.bat < 15 ? "b-crit" : d.bat < 30 ? "b-low" : ""}`}>{Math.round(d.bat)}%</span>
                </span>
              </button>
            );
          })}
        </section>
      ))}
      {groups.length === 0 && <p className="muted">No UAV matches “{search}”.</p>}
    </aside>
  );
}

function order(label: string): number {
  const code = STATE_ORDER.find((c) => STATE_LABEL[c] === label);
  return code ? STATE_ORDER.indexOf(code) : 99;
}
