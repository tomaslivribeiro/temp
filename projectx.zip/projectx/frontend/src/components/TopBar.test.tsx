// @vitest-environment jsdom
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { WsLink } from "../api/wsClient";
import { TopBar } from "./TopBar";

const bar = (ws: WsLink | "local") => (
  <TopBar backend={{ state: "online", info: null }} ws={ws} uavCount={1} alertCount={0} settingsOpen={false} onToggleSettings={() => {}} />
);

describe("TopBar", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(0);
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
  });

  it("shows the link state with its colour", () => {
    render(bar({ state: "open", attempt: 0, lastDataAt: 0 }));
    expect(screen.getByText("WS: connected").className).toContain("lk-ok");
  });

  it("counts down from the moment of the status change, not the last clock tick", () => {
    const { rerender } = render(bar({ state: "open", attempt: 0, lastDataAt: 0 }));
    vi.setSystemTime(900); // the 1 s clock has not ticked yet
    rerender(bar({ state: "closed", attempt: 1, retryAt: 1900, lastDataAt: 0 }));
    expect(screen.getByText("WS: disconnected · retry in 1s (attempt 1) · data 0s old").className).toContain("lk-lost");
  });

  it("names the local simulator", () => {
    render(bar("local"));
    expect(screen.getByText("Data: local simulator").className).toContain("muted");
  });
});
