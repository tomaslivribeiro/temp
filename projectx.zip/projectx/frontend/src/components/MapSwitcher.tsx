import { useEffect, useRef, useState } from "react";
import { MAPS, type MapId } from "../maps/registry";

interface Props {
  value: MapId;
  onChange: (id: MapId) => void;
}

/** Layer picker: shows the current map and lists every registered one. */
export function MapSwitcher({ value, onChange }: Props) {
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const current = MAPS.find((m) => m.id === value) ?? MAPS[0];

  useEffect(() => {
    if (!open) return;
    const close = (e: Event) => {
      if (e.target instanceof Node && !box.current?.contains(e.target)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("pointerdown", close);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("pointerdown", close);
      document.removeEventListener("keydown", esc);
    };
  }, [open]);

  return (
    <div className="map-switch" ref={box}>
      <button className="mbtn" aria-haspopup="listbox" aria-expanded={open} title="Change map" onClick={() => setOpen(!open)}>
        <span aria-hidden>◫</span>
        <span className="ms-label"> {current.label}</span>
      </button>
      {open && (
        <ul className="ms-list" role="listbox" aria-label="Map">
          {MAPS.map((m) => (
            <li key={m.id} role="option" aria-selected={m.id === value}>
              <button
                className={m.id === value ? "on" : ""}
                onClick={() => {
                  setOpen(false);
                  if (m.id !== value) onChange(m.id);
                }}
              >
                <b>{m.label}</b>
                <span className="muted">{m.hint}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
