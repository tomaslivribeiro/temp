import { BASES, STATE_LABEL } from "../domain/constants";
import { fmtPosition } from "../domain/format";
import { km, regionOf } from "../domain/geo";
import { alertsOf, linkOf } from "../domain/link";
import type { Drone } from "../domain/types";

function Row({ k, v, cls = "" }: { k: string; v: string; cls?: string }) {
  return (
    <div className="kv">
      <span className="muted">{k}</span>
      <span className={`mono ${cls}`}>{v}</span>
    </div>
  );
}

export function DroneHeader({ d }: { d: Drone }) {
  const link = linkOf(d);
  return (
    <div className="dhead a-head">
      <span className="lt mono big">{d.state}</span>
      <div>
        <div className="dname">{d.id}</div>
        <div className="muted">{STATE_LABEL[d.state]} · {regionOf(d)}</div>
      </div>
      <span className={`lk-${link.kind} mono`}>{link.label}</span>
    </div>
  );
}

export function TelemetryPanel({ d }: { d: Drone }) {
  const link = linkOf(d);
  const alerts = alertsOf(d, link);
  const base = BASES[d.base];
  const mins = Math.round((d.bat / 100) * 45);
  const total = d.a && d.b ? km(d.a, d.b) : 0;
  const rem = d.b ? km(d, d.b) : 0;
  const eta = d.spd > 0 && d.b ? Math.ceil((rem / d.spd) * 60) : null;

  return (
    <aside className="panel a-tel">
      {alerts.map((a, i) => (
        <p key={i} className={`note${a.sev === 2 ? " crit" : ""}`}>{a.text}</p>
      ))}
      <h3 className="cap h">Telemetry</h3>
      <div className="box">
        <Row k="Position" v={fmtPosition(d, d.frame)} />
        <Row k="Altitude AMSL" v={`${Math.round(d.alt)} m`} />
        <Row k="Speed" v={`${Math.round(d.spd)} km/h`} />
        <Row k="Heading" v={`${Math.round(d.hdg)}°`} />
        <Row k="Distance to base" v={`${km(d, base).toFixed(1)} km`} />
        <Row k="Battery" v={`${Math.round(d.bat)}% · ~${mins} min`} cls={d.bat < 15 ? "b-crit" : d.bat < 30 ? "b-low" : ""} />
        <Row k="GPS" v={d.gps === "good" ? `Good · ${d.sats} sat` : `Weak · ${d.sats} sat`} cls={d.gps === "weak" ? "b-low" : ""} />
        <Row k="Signal" v={link.label} cls={`lk-${link.kind}`} />
        <Row k="Last update" v={`${d.hb} s ago`} />
      </div>
      <h3 className="cap h">Mission</h3>
      <div className="box">
        {d.b && d.a ? (
          <>
            <Row k="From A" v={fmtPosition(d.a, d.frame)} />
            <Row k="To B" v={fmtPosition(d.b, d.frame)} />
            <Row k="Progress" v={`${total > 0 ? Math.round((1 - rem / total) * 100) : 0}%`} />
            <Row k="Remaining" v={`${rem.toFixed(1)} km`} />
            <Row k="ETA" v={eta === null ? "—" : `${eta} min`} />
          </>
        ) : (
          <p className="muted">No active mission.</p>
        )}
      </div>
    </aside>
  );
}
