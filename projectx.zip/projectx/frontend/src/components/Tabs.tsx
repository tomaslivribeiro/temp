import { alertsOf, linkOf, maxSeverity } from "../domain/link";
import type { Drone } from "../domain/types";

interface Props {
  active: string;
  tabs: string[];
  drones: Drone[];
  onSelect: (id: string) => void;
  onClose: (id: string) => void;
}

export function Tabs({ active, tabs, drones, onSelect, onClose }: Props) {
  return (
    <nav className="tabs">
      <button className={`tab${active === "fleet" ? " on" : ""}`} onClick={() => onSelect("fleet")}>
        Fleet
      </button>
      {tabs.map((id) => {
        const d = drones.find((x) => x.id === id);
        if (!d) return null;
        const sev = maxSeverity(alertsOf(d, linkOf(d)));
        return (
          <div key={id} className={`tab${active === id ? " on" : ""}`}>
            <button className="tab-main" onClick={() => onSelect(id)}>
              <span className="lt mono">{d.state}</span>
              {id}
              {sev > 0 && <span className={`bd sev${sev}`}>{sev === 2 ? "!!" : "!"}</span>}
            </button>
            <button className="tab-x" aria-label={`Close ${id}`} onClick={() => onClose(id)}>
              ×
            </button>
          </div>
        );
      })}
    </nav>
  );
}
