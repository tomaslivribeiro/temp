import maplibregl, { type GeoJSONSource, type Map as MlMap, type Marker } from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { useEffect, useRef, useState } from "react";
import imageUrl from "./Town10HD_map_grid.png";
import { api } from "../api/client";
import { BASES, MAP_PRESETS } from "../domain/constants";
import { advance, bearing, km } from "../domain/geo";
import {
  GEOZONE_STYLES,
  byRestriction,
  describeAltitude,
  describeValidity,
  geozonesNotice,
  sortBySeverity,
  type GeozoneProperties,
  type GeozoneSource,
} from "../domain/geozones";
import { linkOf } from "../domain/link";
import type { Drone, LonLat } from "../domain/types";
import { getLayerChoice, useLayerChoice } from "../maps/useLayerChoice";
import { useMapChoice } from "../maps/useMapChoice";
import { buildMilsymbol, buildWaypointMilsymbol } from "../symbology/milmarker";
import { LINE_STYLES, ROUTE_COLOR, overlay, plannedRouteWaypoints } from "./mapOverlay";
import { MapSwitcher } from "./MapSwitcher";
import { SymbologyLegend } from "./SymbologyLegend";

const TILES = import.meta.env.VITE_MAP_TILES_URL ?? "https://tile.openstreetmap.org/{z}/{x}/{y}.png";

// Floorplan dimensions and local-meter bounds used to place the X-Verse image.
const IMAGE_WIDTH = 2304;
const IMAGE_HEIGHT = 2304;
const IMAGE_METER_EXTENTS = {
  west: -232.4,
  south: -183.465,
  east: 210,
  north: 258.935,
};
const IMAGE_ORIGIN_PIXEL = { x: 1210.3, y: 955.5 };

interface Props {
  drones: Drone[];
  /** Drone to follow (drone view). Omit for the fleet overview. */
  followId?: string;
  selectedId?: string | null;
  hoverId?: string | null;
  picking?: boolean;
  draft?: LonLat[] | null;
  onSelect?: (id: string) => void;
  onPick?: (p: LonLat) => void;
  onCancelPick?: () => void;
  /** Dead-reckon markers between snapshots using each drone's last received speed and heading. */
  predict?: boolean;
}

/** Longest stretch we extrapolate after the last snapshot, in seconds (a snapshot arrives every ~1 s). */
const MAX_PREDICT_S = 1.5;

interface Track {
  at: LonLat;
  spd: number;
  hdg: number;
  moving: boolean;
  followingRoute: boolean;
  destination: LonLat | null;
  t: number;
  shown: LonLat;
}

function predictedPosition(track: Track, dt: number): LonLat {
  const meters = (track.spd / 3.6) * dt;
  if (track.destination) {
    const distance = km(track.at, track.destination) * 1000;
    if (track.followingRoute) {
      // Route movement follows the active leg, not the previous telemetry heading, and stops at its waypoint.
      return advance(track.at, bearing(track.at, track.destination), Math.min(meters, distance));
    }
    const targetBearing = bearing(track.at, track.destination);
    const headingDifference = Math.abs(((track.hdg - targetBearing + 540) % 360) - 180);
    if (headingDifference < 45 && meters >= distance) return track.destination;
  }
  return advance(track.at, track.hdg, meters);
}

function samePosition(a: LonLat | null, b: LonLat | null): boolean {
  return a?.lon === b?.lon && a?.lat === b?.lat;
}

function addOverlayLayers(map: MlMap) {
  // Share one GeoJSON overlay across route, trail, and field-of-view layers on either map style.
  map.addSource("ov", { type: "geojson", data: overlay([], null) });
  map.addLayer({
    id: "fov-fill",
    type: "fill",
    source: "ov",
    filter: ["==", "kind", "fov"],
    paint: { "fill-color": "#80E0FF", "fill-opacity": 0.12 },
  });
  map.addLayer({
    id: "fov-outline",
    type: "line",
    source: "ov",
    filter: ["==", "kind", "fov"],
    paint: { "line-color": "#80E0FF", "line-width": 1.2, "line-opacity": 0.7 },
  });
  const common = { type: "line" as const, source: "ov" };
  map.addLayer({ ...common, id: "trail", filter: ["==", "kind", "trail"], paint: { "line-color": ROUTE_COLOR, "line-width": 2, "line-opacity": 0.45 } });
  // Still to fly, from where the drone is now: dashed to the destination, dotted back to base.
  for (const id of ["route", "rtb"] as const) {
    const style = LINE_STYLES[id];
    map.addLayer({ ...common, id, filter: ["==", "kind", id], paint: { "line-color": style.color, "line-width": style.width, "line-dasharray": [...style.dash] } });
  }
  map.addLayer({ ...common, id: "draft", filter: ["==", "kind", "draft"], paint: { "line-color": "#FFFFFF", "line-width": 1.6, "line-dasharray": [2, 3] } });
  // Actual route flown (solid amber), ending where the remaining route (dashed cyan) starts.
  map.addLayer({ ...common, id: "actual", filter: ["==", "kind", "actual"], paint: { "line-color": LINE_STYLES.actual.color, "line-width": LINE_STYLES.actual.width, "line-opacity": 0.9 } });
}

const GEOZONE_LAYERS = ["geozones-fill", "geozones-line"] as const;

/** No-fly zones from the backend: added before the overlay layers so routes and FOV stay on top. */
function addGeozoneLayers(map: MlMap) {
  map.addSource("geozones", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
  const layout = { visibility: getLayerChoice().geozones ? ("visible" as const) : ("none" as const) };
  map.addLayer({
    id: "geozones-fill",
    type: "fill",
    source: "geozones",
    layout,
    paint: { "fill-color": byRestriction((s) => s.color, "#888888"), "fill-opacity": byRestriction((s) => s.fillOpacity, 0.1) },
  });
  map.addLayer({
    id: "geozones-line",
    type: "line",
    source: "geozones",
    layout,
    paint: { "line-color": byRestriction((s) => s.color, "#888888"), "line-width": 1.2, "line-opacity": 0.85 },
  });
}

function zonePopup(features: { properties: Record<string, unknown> }[]): HTMLElement {
  // Text comes from an external source: build the DOM with textContent, never innerHTML.
  const root = document.createElement("div");
  root.className = "gz-pop";
  const zones = sortBySeverity(features.map((f) => f.properties as unknown as GeozoneProperties), (z) => z.restriction);
  // Sorted before cutting, so the ones left out are always the least severe.
  for (const p of zones.slice(0, 4)) {
    const block = document.createElement("div");
    block.className = "gz-item";
    // Same colour as the zone on the map and in the legend.
    block.style.borderLeftColor = GEOZONE_STYLES[p.restriction]?.color ?? "#888888";
    const add = (cls: string, text: string) => {
      if (!text) return;
      const line = document.createElement("div");
      line.className = cls;
      line.textContent = text;
      block.appendChild(line);
    };
    add("gz-name", p.name);
    add("gz-meta", `${GEOZONE_STYLES[p.restriction]?.label ?? p.restriction} · ${describeAltitude(p)}`);
    add("gz-meta", describeValidity(p));
    add("gz-msg", p.message ?? "");
    root.appendChild(block);
  }
  if (features.length > 4) {
    const more = document.createElement("div");
    more.className = "gz-meta";
    more.textContent = `+${features.length - 4} more zones here`;
    root.appendChild(more);
  }
  return root;
}

export function MapView(props_: Props) {
  const [mapType, setMapType] = useMapChoice();
  const p = { ...props_, mapType };
  const el = useRef<HTMLDivElement>(null);
  const coordsDisplay = useRef<HTMLSpanElement>(null);
  const mapRef = useRef<MlMap | null>(null);
  const markers = useRef(new Map<string, Marker>());
  const destMarkers = useRef<Marker[]>([]);
  const tracks = useRef(new Map<string, Track>());
  const [ready, setReady] = useState(false);
  const [layers, setLayers] = useLayerChoice();
  const [zoneSources, setZoneSources] = useState<GeozoneSource[]>([]);
  const props = useRef(p);
  props.current = p;

  // Recreate the MapLibre instance when switching map types, since each mode uses a different style.
  useEffect(() => {
    const current = props.current;
    const follow = current.followId ? current.drones.find((d) => d.id === current.followId) : undefined;
    let imageBounds: { west: number; east: number; north: number; south: number } | undefined;
    let toMapCoordinate: ((x: number, y: number) => [number, number]) | undefined;
    let imageBoundsCoordinates: [[number, number], [number, number]] | undefined;
    let mercatorOrigin: maplibregl.MercatorCoordinate | undefined;
    let mercatorUnitsPerMeter: number | undefined;

    if (p.mapType === "xverse") {
      // Convert local floorplan meters into Mercator coordinates around the map origin.
      mercatorOrigin = maplibregl.MercatorCoordinate.fromLngLat([0, 0]);
      mercatorUnitsPerMeter = mercatorOrigin.meterInMercatorCoordinateUnits();
      const metersPerPixelX =
        (IMAGE_METER_EXTENTS.east - IMAGE_METER_EXTENTS.west) / IMAGE_WIDTH;
      const metersPerPixelY =
        (IMAGE_METER_EXTENTS.north - IMAGE_METER_EXTENTS.south) / IMAGE_HEIGHT;
      imageBounds = {
        west: -IMAGE_ORIGIN_PIXEL.x * metersPerPixelX,
        east: (IMAGE_WIDTH - IMAGE_ORIGIN_PIXEL.x) * metersPerPixelX,
        north: -IMAGE_ORIGIN_PIXEL.y * metersPerPixelY,
        south: (IMAGE_HEIGHT - IMAGE_ORIGIN_PIXEL.y) * metersPerPixelY,
      };
      toMapCoordinate = (x, y) => {
        const coordinate = new maplibregl.MercatorCoordinate(
          mercatorOrigin!.x + x * mercatorUnitsPerMeter!,
          mercatorOrigin!.y + y * mercatorUnitsPerMeter!,
          mercatorOrigin!.z,
        ).toLngLat();
        return [coordinate.lng, coordinate.lat];
      };
      imageBoundsCoordinates = [
        toMapCoordinate(imageBounds.west, imageBounds.south),
        toMapCoordinate(imageBounds.east, imageBounds.north),
      ];
    }

    const map = new maplibregl.Map({
      container: el.current!,
      style: p.mapType === "xverse"
        ? { version: 8, sources: {}, layers: [] }
        : {
            version: 8,
            sources: { base: { type: "raster", tiles: [TILES], tileSize: 256, attribution: "© OpenStreetMap" } },
            layers: [{ id: "base", type: "raster", source: "base", paint: { "raster-brightness-max": 0.55, "raster-saturation": -0.7, "raster-contrast": 0.15 } }],
          },
      center: p.mapType === "xverse"
        ? toMapCoordinate!((imageBounds!.west + imageBounds!.east) / 2, (imageBounds!.south + imageBounds!.north) / 2)
        : follow ? [follow.lon, follow.lat] : MAP_PRESETS[0].center,
      zoom: p.mapType === "xverse" ? 0 : follow ? 11 : MAP_PRESETS[0].zoom,
      attributionControl: { compact: true },
    });
    // Fills the viewport with the floorplan (the short side fits, the long side is pannable inside the image).
    const fitCover = () => {
      const [sw, ne] = imageBoundsCoordinates!;
      map.setMaxBounds(null);
      const contain = map.cameraForBounds([sw, ne]);
      if (!contain || contain.zoom === undefined) return;
      const { clientWidth: w, clientHeight: h } = map.getContainer();
      const rw = w / IMAGE_WIDTH;
      const rh = h / IMAGE_HEIGHT;
      const zoom = contain.zoom + Math.log2(Math.max(rw, rh) / Math.min(rw, rh));
      map.jumpTo({ center: contain.center, zoom });
      map.setMaxBounds([sw, ne]);
    };
    map.on("load", () => {
      if (p.mapType === "xverse") {
        // The floorplan mode uses the image as its only map layer.
        const bounds = imageBounds!;
        const coordinate = toMapCoordinate!;
        const [southWest, northEast] = imageBoundsCoordinates!;
        map.addSource("my-map-image", {
          type: "image",
          url: imageUrl,
          coordinates: [
            coordinate(bounds.west, bounds.north),
            coordinate(bounds.east, bounds.north),
            coordinate(bounds.east, bounds.south),
            coordinate(bounds.west, bounds.south),
          ],
        });
        map.addLayer({
          id: "map-layer",
          type: "raster",
          source: "my-map-image",
          paint: { "raster-fade-duration": 0 },
        });
        addOverlayLayers(map);
        fitCover();
        setReady(true);
        return;
      }

      addGeozoneLayers(map);
      addOverlayLayers(map);
      // Without a backend (local simulator) or on error the layer simply stays empty.
      api
        .geozones()
        .then((zones) => {
          if (mapRef.current !== map) return;
          (map.getSource("geozones") as GeoJSONSource | undefined)?.setData(zones as never);
          setZoneSources(zones.sources);
        })
        .catch(() => setZoneSources([]));
      for (const b of Object.values(BASES)) {
        const e = document.createElement("div");
        e.className = "base-b";
        e.innerHTML = `<span class="base-n">${b.id[0]}</span><span class="base-t">${b.id} · ${b.name}</span>`;
        new maplibregl.Marker({ element: e }).setLngLat([b.lon, b.lat]).addTo(map);
      }
      setReady(true);
    });
    map.on("click", (e) => {
      if (props.current.picking) {
        props.current.onPick?.({ lon: e.lngLat.lng, lat: e.lngLat.lat });
        return;
      }
      if (p.mapType !== "osm" || !map.getLayer("geozones-fill") || map.getLayoutProperty("geozones-fill", "visibility") === "none") return;
      const hits = map.queryRenderedFeatures(e.point, { layers: [...GEOZONE_LAYERS] });
      const unique = [...new Map(hits.map((h) => [h.properties?.id, h])).values()];
      if (unique.length === 0) return;
      new maplibregl.Popup({ maxWidth: "320px" })
        .setLngLat(e.lngLat)
        .setDOMContent(zonePopup(unique as unknown as { properties: Record<string, unknown> }[]))
        .addTo(map);
    });
    const toggleFar = () => el.current?.classList.toggle("far", map.getZoom() < 6);
    if (p.mapType === "osm") {
      map.on("zoom", toggleFar);
      toggleFar();
    } else {
      map.on("mousemove", (e) => {
        const pointer = maplibregl.MercatorCoordinate.fromLngLat(e.lngLat);
        const x = (pointer.x - mercatorOrigin!.x) / mercatorUnitsPerMeter!;
        const y = (pointer.y - mercatorOrigin!.y) / mercatorUnitsPerMeter!;
        const insideImage =
          x >= imageBounds!.west &&
          x <= imageBounds!.east &&
          y >= imageBounds!.north &&
          y <= imageBounds!.south;
        if (coordsDisplay.current) {
          coordsDisplay.current.textContent = insideImage
            ? `X: ${x.toFixed(3)} m | Y: ${y.toFixed(3)} m`
            : "Fora dos limites do mapa";
        }
      });
      map.on("mouseleave", () => {
        if (coordsDisplay.current) {
          coordsDisplay.current.textContent = "Mova o rato sobre o mapa...";
        }
      });
    }
    mapRef.current = map;
    // Panels reflow with the window size; keep the canvas in step and re-fit the floorplan to the new size.
    const observer = new ResizeObserver(() => {
      map.resize();
      if (p.mapType === "xverse" && map.getSource("my-map-image")) fitCover();
    });
    observer.observe(el.current!);
    return () => {
      // Clear per-map state so markers from the previous mode cannot be reused.
      observer.disconnect();
      map.remove();
      mapRef.current = null;
      markers.current.clear();
      destMarkers.current = [];
      tracks.current.clear();
      setReady(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.mapType]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready) return;
    // Both map styles share the same overlay source; it may be absent during a style transition.
    // Route, trail, and FOV geometry share one GeoJSON source for both map styles.
    const source = map.getSource("ov");
    if (!source) return;
    (source as GeoJSONSource).setData(overlay(p.drones, p.draft, p.followId, p.selectedId));

    const seen = new Set<string>();
    for (const d of p.drones) {
      seen.add(d.id);
      const link = linkOf(d);
      let mk = markers.current.get(d.id);
      if (!mk) {
        const e = document.createElement("button");
        e.className = "mk";
        e.addEventListener("click", (ev) => {
          ev.stopPropagation();
          props.current.onSelect?.(d.id);
        });
        // top-left + offset so the milsymbol anchor (not the SVG box centre) sits on the position.
        mk = new maplibregl.Marker({ element: e, anchor: "top-left" }).setLngLat([d.lon, d.lat]).addTo(map);
        markers.current.set(d.id, mk);
      }
      const prev = tracks.current.get(d.id);
      const destinationChanged = prev && !samePosition(prev.destination, d.b);
      const position = { lon: d.lon, lat: d.lat };
      // A new leg can turn sharply; restart prediction from telemetry instead of carrying the old leg forward.
      tracks.current.set(d.id, {
        at: position,
        spd: d.spd,
        hdg: d.hdg,
        moving: !destinationChanged && (d.state === "M" || d.state === "R"),
        followingRoute: Boolean(d.route?.length),
        destination: d.b,
        t: performance.now(),
        shown: destinationChanged ? position : prev?.shown ?? position,
      });
      if (destinationChanged) mk.setLngLat([position.lon, position.lat]);
      if (!p.predict || p.mapType !== "osm") mk.setLngLat([d.lon, d.lat]);
      const e = mk.getElement();
      const cls = ["maplibregl-marker", "mk"];
      if (link.kind === "lost" || link.kind === "unk") cls.push("lost");
      if (d.id === p.selectedId || d.id === p.followId) cls.push("sel");
      if (d.id === p.hoverId) cls.push("hl");
      if (p.followId && d.id !== p.followId) cls.push("dim");
      e.className = cls.join(" ");
      e.setAttribute("aria-label", `${d.callsign ?? d.id} ${d.state}`);
      // Show the next-leg bearing immediately, before telemetry reports the UAV's updated heading.
      const routeHeading = d.route?.length && d.b ? bearing(d, d.b) : undefined;
      const sym = buildMilsymbol(d, link, 34, routeHeading);
      // Only touch the DOM when the symbol changed, so hover/selection updates don't rebuild it.
      if (e.dataset.sidcKey !== sym.key) {
        e.dataset.sidcKey = sym.key;
        e.innerHTML = `<span class="sym-wrap">${sym.svg}</span>`;
        mk.setOffset([-sym.anchor.x, -sym.anchor.y]);
      }
    }
    for (const [id, mk] of markers.current) {
      if (!seen.has(id)) {
        mk.remove();
        markers.current.delete(id);
        tracks.current.delete(id);
      }
    }

    destMarkers.current.forEach((m) => m.remove());
    destMarkers.current = [];
    const dest = (pt: LonLat, label: string, draft: boolean, waypoint = false) => {
      const e = document.createElement("div");
      e.className = `dest${draft ? " draft" : ""}`;
      if (waypoint) {
        const symbol = buildWaypointMilsymbol(label);
        e.innerHTML = `<span class="sym-wrap">${symbol.svg}</span>`;
        destMarkers.current.push(
          new maplibregl.Marker({ element: e, anchor: "top-left" })
            .setOffset([-symbol.anchor.x, -symbol.anchor.y])
            .setLngLat([pt.lon, pt.lat])
            .addTo(map),
        );
        return;
      }
      e.innerHTML = `<span class="dest-b">B</span><span class="dest-l">${label}</span>`;
      destMarkers.current.push(new maplibregl.Marker({ element: e }).setLngLat([pt.lon, pt.lat]).addTo(map));
    };
    for (const d of p.drones) {
      if (p.followId && d.id !== p.followId) continue;
      if (d.route?.length) {
        plannedRouteWaypoints(d).forEach(({ point, index }) =>
          dest(point, `WP${index + 1}`, false, true)
        );
      }
      else if (d.state === "M" && d.b) dest(d.b, `${d.id} B`, false);
    }
    p.draft?.forEach((point, index) => dest(point, `WP${index + 1}`, true, true));
  }, [p.drones, p.draft, p.followId, p.selectedId, p.hoverId, p.mapType, ready]);

  // Smoothly dead-reckon marker positions between telemetry snapshots, with a short prediction cap.
  useEffect(() => {
    if (!p.predict || !ready || p.mapType !== "osm") return;
    let raf = 0;
    const frame = () => {
      const now = performance.now();
      for (const [id, tr] of tracks.current) {
        const mk = markers.current.get(id);
        if (!mk) continue;
        const dt = Math.min((now - tr.t) / 1000, MAX_PREDICT_S);
        const target = tr.moving && tr.spd > 0 ? predictedPosition(tr, dt) : tr.at;
        tr.shown = {
          lon: tr.shown.lon + (target.lon - tr.shown.lon) * 0.25,
          lat: tr.shown.lat + (target.lat - tr.shown.lat) * 0.25,
        };
        mk.setLngLat([tr.shown.lon, tr.shown.lat]);
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [p.predict, p.mapType, ready]);

  useEffect(() => {
    const map = mapRef.current;
    if (map) map.getCanvas().style.cursor = p.picking ? "crosshair" : "";
  }, [p.mapType, p.picking, ready]);

  // The no-fly layer toggle: only changes visibility, the data stays loaded.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready || p.mapType !== "osm") return;
    for (const id of GEOZONE_LAYERS) {
      if (map.getLayer(id)) map.setLayoutProperty(id, "visibility", layers.geozones ? "visible" : "none");
    }
  }, [layers.geozones, p.mapType, ready]);

  const follow = () => {
    const d = p.drones.find((x) => x.id === p.followId);
    if (d) mapRef.current?.easeTo({ center: [d.lon, d.lat], zoom: 11 });
  };

  return (
    <div className="viewport">
      <div ref={el} className="map-canvas" />
      <div className="map-tools">
        <MapSwitcher value={mapType} onChange={setMapType} />
        {mapType === "osm" && (
          <button
            type="button"
            className={`mbtn gz-toggle${layers.geozones ? " on" : ""}`}
            aria-pressed={layers.geozones}
            title={layers.geozones ? "Hide no-fly zones" : "Show no-fly zones"}
            onClick={() => setLayers({ geozones: !layers.geozones })}
          >
            NO-FLY ZONES · {layers.geozones ? "ON" : "OFF"}
          </button>
        )}
        {mapType === "osm" && (
          <div className="presets">
            {p.followId ? (
              <button className="mbtn" onClick={follow}>CENTRE ON {p.followId}</button>
            ) : (
              MAP_PRESETS.map((pr) => (
                <button key={pr.id} className="mbtn" onClick={() => mapRef.current?.flyTo({ center: pr.center, zoom: pr.zoom })}>
                  {pr.label}
                </button>
              ))
            )}
          </div>
        )}
      </div>
      {p.mapType === "xverse" && (
        <span ref={coordsDisplay} className="xverse-coords" role="status">
          Mova o rato sobre o mapa...
        </span>
      )}
      {p.mapType === "osm" && p.picking && (
        <div className="pick-ban">
          Click the map to add route waypoints
          <button className="mbtn" onClick={p.onCancelPick}>Cancel</button>
        </div>
      )}
      {p.mapType === "osm" && layers.geozones && zoneSources.length > 0 && (
        <div className="gz-note" role="note">{geozonesNotice(zoneSources)}</div>
      )}
      <SymbologyLegend showZones={mapType === "osm" && layers.geozones} />
    </div>
  );
}
