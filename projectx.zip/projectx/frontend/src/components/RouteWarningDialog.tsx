import { useEffect, useRef } from "react";
import {
  GEOZONE_STYLES,
  describeAltitude,
  describeValidity,
  type GeozoneProperties,
} from "../domain/geozones";

interface Props {
  /** Restricted zones the route crosses, in the order it reaches them; null when it could not be checked. */
  zones: GeozoneProperties[] | null;
  canContinue: boolean;
  /** Why the command can no longer be sent ("" = it can). */
  blocked: string;
  onBack: () => void;
  onContinue: () => void;
}

/** Asks the operator to confirm a route that crosses a no-fly zone, or that could not be checked. */
export function RouteWarningDialog({ zones, canContinue, blocked, onBack, onContinue }: Props) {
  const back = useRef<HTMLButtonElement>(null);

  // The safe choice has the focus: Enter or Escape never sends the route.
  useEffect(() => back.current?.focus(), []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onBack();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onBack]);

  return (
    <div className="rw-overlay">
      <div className="rw" role="alertdialog" aria-modal="true" aria-labelledby="rw-title" aria-describedby="rw-question">
        <h2 id="rw-title">{zones ? "Route crosses a no-fly zone" : "Route not checked"}</h2>
        {zones && (
          <ol className="rw-list">
            {zones.map((z, i) => {
              const style = GEOZONE_STYLES[z.restriction];
              const validity = describeValidity(z);
              return (
                // Same colour as the zone on the map and in the legend.
                <li key={z.id} className="rw-item" style={{ borderLeftColor: style?.color ?? "#888888" }}>
                  <div>
                    <span className="rw-order">{i + 1}.</span> <span className="rw-name">{z.name}</span>
                  </div>
                  <div className="muted">{`${style?.label ?? z.restriction} · ${describeAltitude(z)}`}</div>
                  {validity && <div className="muted">{validity}</div>}
                </li>
              );
            })}
          </ol>
        )}
        <p id="rw-question">
          {zones
            ? "Do you have authorisation to fly over these areas? Continue only if you do."
            : "Could not check the route against no-fly zones. Do you want to continue?"}
        </p>
        {blocked && <p className="note">{blocked}</p>}
        <div className="btns">
          <button ref={back} type="button" className="btn" onClick={onBack}>Back</button>
          <button type="button" className="btn primary" disabled={!canContinue} onClick={onContinue}>Continue</button>
        </div>
      </div>
    </div>
  );
}
