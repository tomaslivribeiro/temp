import { useCallback, useEffect, useState } from "react";
import { api, type AdminConfig, type RuntimeSettings, type UavAdminRecord } from "../api/client";
import { MAPS, isMapId } from "../maps/registry";
import { useMapChoice } from "../maps/useMapChoice";

const PLATFORM_OPTIONS = [
  "ROTARY_UAV", "FIXED_WING_UAV", "WHEELED_UGV", "TRACKED_UGV", "USV", "FOOT",
] as const;
const ECHELON_OPTIONS = [
  "", "TEAM", "SQUAD", "SECTION", "PLATOON", "COMPANY",
  "BATTALION", "REGIMENT", "BRIGADE", "DIVISION", "CORPS",
] as const;

const TOKEN_KEY = "c2.adminToken";
const ENDPOINT = /^(tcp|udp|tls|quic|ws)\/[\w.\-:[\]]+$/;

/** Mirrors the backend rule so typos are caught before the request. */
export function endpointError(value: string): string | null {
  const bad = value.split(",").map((p) => p.trim()).filter(Boolean).find((p) => !ENDPOINT.test(p));
  return bad ? `Invalid endpoint "${bad}". Use e.g. tcp/10.0.0.5:7447` : null;
}

/** Stored in this browser only, so it needs no admin token. */
function MapPreference() {
  const [map, setMap] = useMapChoice();
  return (
    <section className="card">
      <h3 className="cap">Display</h3>
      <label>
        Map
        <select className="inp" value={map} onChange={(e) => isMapId(e.target.value) && setMap(e.target.value)}>
          {MAPS.map((m) => (
            <option key={m.id} value={m.id}>
              {m.label} · {m.hint}
            </option>
          ))}
        </select>
      </label>
    </section>
  );
}

type Msg = { kind: "ok" | "bad"; text: string } | null;

export function SettingsView() {
  const [token, setToken] = useState(() => sessionStorage.getItem(TOKEN_KEY) ?? "");
  const [cfg, setCfg] = useState<AdminConfig | null>(null);
  const [form, setForm] = useState<RuntimeSettings | null>(null);
  const [msg, setMsg] = useState<Msg>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async (t: string) => {
    try {
      const c = await api.getConfig(t);
      sessionStorage.setItem(TOKEN_KEY, t);
      setCfg(c);
      setForm((f) => f ?? c.settings);
      return true;
    } catch (e) {
      setCfg(null);
      setForm(null);
      setMsg({ kind: "bad", text: e instanceof Error ? e.message : String(e) });
      return false;
    }
  }, []);

  useEffect(() => {
    if (token) void load(token);
    // only the first load uses the stored token; afterwards the buttons drive it
  }, []);

  useEffect(() => {
    if (!cfg) return;
    const id = setInterval(() => void load(token), 3000);
    return () => clearInterval(id);
  }, [cfg, token, load]);

  const run = async (fn: () => Promise<string>) => {
    setBusy(true);
    setMsg(null);
    try {
      setMsg({ kind: "ok", text: await fn() });
    } catch (e) {
      setMsg({ kind: "bad", text: e instanceof Error ? e.message : String(e) });
    } finally {
      setBusy(false);
    }
  };

  const connect = async () => {
    setMsg(null);
    setForm(null);
    await load(token);
  };

  if (!cfg || !form) {
    return (
      <div className="settings-page">
      <div className="settings">
        <h2 className="cap">Configuration</h2>
        <p className="muted">Enter the admin token (C2_ADMIN_TOKEN on the backend) to read and change settings.</p>
        <div className="btns">
          <input
            type="password"
            className="inp mono"
            placeholder="admin token"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void connect()}
          />
          <button className="btn primary" onClick={() => void connect()} disabled={!token}>
            Unlock
          </button>
        </div>
        {msg && <p className={`note ${msg.kind === "bad" ? "crit" : "info"}`}>{msg.text}</p>}
        <MapPreference />
      </div>
      </div>
    );
  }

  const set = <K extends keyof RuntimeSettings>(k: K, v: RuntimeSettings[K]) => setForm({ ...form, [k]: v });
  const epError = form.driver === "zenoh" ? endpointError(form.zenoh_connect) : null;
  const dirty = JSON.stringify(form) !== JSON.stringify(cfg.settings);
  const st = cfg.status;

  const apply = (c: AdminConfig) => {
    setCfg(c);
    setForm(c.settings);
    return c.persisted === false ? "Applied, but could not be saved to the database." : "Applied and saved.";
  };

  return (
    <div className="settings-page">
    <div className="settings">
      <h2 className="cap">Configuration</h2>
      {msg && <p className={`note ${msg.kind === "bad" ? "crit" : "info"}`}>{msg.text}</p>}
      {busy && <p className="note info">Working…</p>}

      <MapPreference />

      <section className="card">
        <h3 className="cap">Status</h3>
        <dl className="kv mono">
          <dt>Driver</dt>
          <dd>{st.driver}</dd>
          <dt>Link</dt>
          <dd className={st.connected && (st.peers ?? 1) > 0 ? "lk-ok" : "lk-bad"}>
            {st.peers === null ? "built-in simulator" : `${st.connected ? "session open" : "connecting"} · ${st.peers} node(s)`}
          </dd>
          <dt>Last message</dt>
          <dd>{st.last_message_s === null ? "—" : `${st.last_message_s}s ago`}</dd>
          <dt>Assets</dt>
          <dd>{st.assets}</dd>
          <dt>Settings from</dt>
          <dd>{cfg.origin === "saved" ? "saved in the database" : "environment variables"}</dd>
        </dl>
      </section>

      <section className="card">
        <h3 className="cap">Connection</h3>
        <label>
          Driver
          <select className="inp" value={form.driver} onChange={(e) => set("driver", e.target.value as RuntimeSettings["driver"])}>
            <option value="sim">Built-in simulator</option>
            <option value="zenoh">Zenoh (X-Verse)</option>
            <option value="nato" disabled>
              NATO (not implemented)
            </option>
          </select>
        </label>
        <label>
          Zenoh endpoints
          <input
            className="inp mono"
            value={form.zenoh_connect}
            placeholder="tcp/10.0.0.5:7447  (comma-separated; empty = auto-discovery)"
            disabled={form.driver !== "zenoh"}
            onChange={(e) => set("zenoh_connect", e.target.value)}
          />
        </label>
        {epError && <p className="note crit">{epError}</p>}
        <div className="btns">
          <button
            className="btn"
            disabled={busy || !!epError}
            onClick={() =>
              void run(async () => {
                const r = await api.testZenoh(token, form.zenoh_connect);
                if (!r.ok) throw new Error(r.detail);
                return r.detail;
              })
            }
          >
            Test connection
          </button>
        </div>
      </section>

      <section className="card">
        <h3 className="cap">Identity and mission</h3>
        <label>
          Operator ID
          <input className="inp mono" value={form.operator_id} onChange={(e) => set("operator_id", e.target.value)} />
        </label>
        <label>
          Default speed (m/s)
          <input
            className="inp mono"
            type="number"
            min={1}
            max={100}
            value={form.default_speed_mps}
            onChange={(e) => set("default_speed_mps", Number(e.target.value))}
          />
        </label>
      </section>

      <section className="card">
        <h3 className="cap">Monitoring</h3>
        <label>
          Mark asset as lost after (s)
          <input
            className="inp mono"
            type="number"
            min={3}
            max={300}
            value={form.lost_after_s}
            onChange={(e) => set("lost_after_s", Number(e.target.value))}
          />
        </label>
      </section>

      <AssetsCard token={token} />

      <p className="note info">
        Saving reconnects the fleet source. Switching driver clears the current fleet; assets reappear as soon as they
        publish again. Zenoh keeps retrying, so use Test connection before saving.
      </p>
      <div className="btns">
        <button
          className="btn primary"
          disabled={busy || !dirty || !!epError}
          onClick={() => void run(async () => apply(await api.saveConfig(token, form)))}
        >
          Save and apply
        </button>
        <button className="btn" disabled={busy || !dirty} onClick={() => setForm(cfg.settings)}>
          Discard changes
        </button>
        <button
          className="btn"
          disabled={busy || cfg.origin === "environment"}
          title={`Back to environment values (driver ${cfg.defaults.driver})`}
          onClick={() => void run(async () => apply(await api.resetConfig(token)))}
        >
          Reset to environment
        </button>
      </div>
    </div>
    </div>
  );
}


function AssetsCard({ token }: { token: string }) {
  const [rows, setRows] = useState<UavAdminRecord[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const { uavs } = await api.listUavs(token);
      setRows(uavs.slice().sort((a, b) => a.id.localeCompare(b.id)));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [token]);

  useEffect(() => {
    void load();
  }, [load]);

  const patch = async (asset: UavAdminRecord, field: keyof UavAdminRecord, raw: string) => {
    const value = raw === "" ? null : raw;
    setBusy(asset.id);
    try {
      const updated = await api.patchUav(token, asset.id, { [field]: value } as Record<string, string | null>);
      setRows((current) =>
        current ? current.map((r) => (r.id === asset.id ? { ...r, ...updated } : r)) : current,
      );
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  };

  return (
    <section className="card">
      <h3 className="cap">Assets (APP-6 metadata)</h3>
      <p className="muted">
        Edits apply on blur. Rows for real assets are created the first time they publish telemetry; sim rows exist
        once the operator edits them.
      </p>
      {error && <p className="note crit">{error}</p>}
      {rows === null ? (
        <p className="note info">Loading…</p>
      ) : rows.length === 0 ? (
        <p className="muted">No assets registered yet.</p>
      ) : (
        <table className="assets-table mono">
          <thead>
            <tr>
              <th>ID</th>
              <th>Platform type</th>
              <th>Callsign</th>
              <th>Higher formation</th>
              <th>Echelon</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className={busy === r.id ? "busy" : ""}>
                <td>{r.id}</td>
                <td>
                  <select
                    className="inp"
                    defaultValue={r.platformType}
                    onBlur={(e) => e.target.value !== r.platformType && void patch(r, "platformType", e.target.value)}
                  >
                    {PLATFORM_OPTIONS.map((p) => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </td>
                <td>
                  <input
                    className="inp"
                    defaultValue={r.callsign ?? ""}
                    placeholder={r.id}
                    onBlur={(e) => (e.target.value || null) !== r.callsign && void patch(r, "callsign", e.target.value)}
                  />
                </td>
                <td>
                  <input
                    className="inp"
                    defaultValue={r.higherFormation ?? ""}
                    onBlur={(e) =>
                      (e.target.value || null) !== r.higherFormation
                      && void patch(r, "higherFormation", e.target.value)
                    }
                  />
                </td>
                <td>
                  <select
                    className="inp"
                    defaultValue={r.echelon ?? ""}
                    onBlur={(e) => (e.target.value || null) !== r.echelon && void patch(r, "echelon", e.target.value)}
                  >
                    {ECHELON_OPTIONS.map((ech) => (
                      <option key={ech || "none"} value={ech}>
                        {ech || "(none)"}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}
