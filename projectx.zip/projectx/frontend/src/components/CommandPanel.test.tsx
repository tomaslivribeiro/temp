// @vitest-environment jsdom
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import type { Drone } from "../domain/types";
import { CommandPanel } from "./CommandPanel";

const drone = {
  id: "GAMA", state: "H", base: "ALFA", lon: -9, lat: 38.8, alt: 100, spd: 0, hdg: 0, bat: 80, hb: 0,
  flaky: false, lost: false, gps: "good", sats: 14, trail: [], a: null, b: null, timer: 0,
} as Drone;

const panel = (feedDown: boolean) => (
  <CommandPanel
    drone={drone}
    cmds={[]}
    profile="OPERATOR"
    feedDown={feedDown}
    picking={false}
    draft={null}
    onStartPick={() => {}}
    onCancelPick={() => {}}
    onSend={() => {}}
  />
);
const enabled = () => screen.getAllByRole("button").filter((b) => !(b as HTMLButtonElement).disabled);

describe("CommandPanel", () => {
  afterEach(cleanup);

  it("offers commands while the feed is up", () => {
    render(panel(false));
    expect(enabled().length).toBeGreaterThan(0);
  });

  it("blocks every command while the feed is down", () => {
    render(panel(true));
    expect(enabled()).toHaveLength(0);
    expect(screen.getByText(/Connection to the server lost/)).toBeTruthy();
  });
});
