// @vitest-environment jsdom
import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { api } from "../api/client";
import type { GeozoneProperties, Restriction } from "../domain/geozones";
import type { Drone, LonLat } from "../domain/types";
import { CommandPanel } from "./CommandPanel";

vi.mock("../api/client", () => ({ api: { checkRoute: vi.fn() } }));
const checkRoute = vi.mocked(api.checkRoute);

const drone = {
  id: "GAMA", state: "H", base: "ALFA", lon: -9, lat: 38.8, alt: 100, spd: 0, hdg: 0, bat: 80, hb: 0,
  flaky: false, lost: false, gps: "good", sats: 14, trail: [], a: null, b: null, timer: 0,
} as Drone;

const WAYPOINTS: LonLat[] = [{ lon: -9.1, lat: 38.77 }, { lon: -9.2, lat: 38.7 }];

const zone = (id: number, name: string, restriction: Restriction): GeozoneProperties => ({
  id, external_id: name, source_id: "anac", name, restriction, reason: null, message: null,
  lower_m: 0, upper_m: 120, lower_ref: "AGL", upper_ref: "AGL", valid_from: null, valid_to: null, shape_type: "circle",
});

const onSend = vi.fn();
const onCancelPick = vi.fn();

const panel = ({ feedDown = false, d = drone, draft = null as LonLat[] | null } = {}) => (
  <CommandPanel
    drone={d}
    cmds={[]}
    profile="OPERATOR"
    feedDown={feedDown}
    picking={false}
    draft={draft}
    onStartPick={() => {}}
    onCancelPick={onCancelPick}
    onSend={onSend}
  />
);
const enabled = () => screen.getAllByRole("button").filter((b) => !(b as HTMLButtonElement).disabled);
const button = (name: string | RegExp) => screen.getByRole("button", { name }) as HTMLButtonElement;
const click = async (name: string | RegExp) => {
  await act(async () => {
    fireEvent.click(button(name));
  });
};
const dialog = () => screen.queryByRole("alertdialog");

/** A check that stays pending until the test answers it. */
const pendingCheck = () => {
  let answer!: (r: { zones: GeozoneProperties[] }) => void;
  checkRoute.mockReturnValue(new Promise((resolve) => (answer = resolve)));
  return (zones: GeozoneProperties[]) => act(async () => answer({ zones }));
};

beforeEach(() => {
  vi.resetAllMocks();
});
afterEach(cleanup);

describe("CommandPanel", () => {
  it("offers commands while the feed is up", () => {
    render(panel());
    expect(enabled().length).toBeGreaterThan(0);
  });

  it("blocks every command while the feed is down", () => {
    render(panel({ feedDown: true }));
    expect(enabled()).toHaveLength(0);
    expect(screen.getByText(/Connection to the server lost/)).toBeTruthy();
  });
});

describe("CommandPanel no-fly zone check", () => {
  const submitRoute = async () => {
    const view = render(panel({ draft: WAYPOINTS }));
    await click(/Go to route/);
    await click("Confirm");
    return view;
  };

  it("checks the route from the drone position and sends it when clear", async () => {
    checkRoute.mockResolvedValue({ zones: [] });
    await submitRoute();
    expect(checkRoute).toHaveBeenCalledWith([{ lon: -9, lat: 38.8 }, ...WAYPOINTS]);
    expect(onSend).toHaveBeenCalledWith("goto", null, WAYPOINTS);
    expect(dialog()).toBeNull();
  });

  it("warns instead of sending when the route crosses a zone", async () => {
    checkRoute.mockResolvedValue({ zones: [zone(1, "CTR Lisboa", "CONDITIONAL")] });
    await submitRoute();
    expect(onSend).not.toHaveBeenCalled();
    expect(dialog()?.textContent).toContain("Route crosses a no-fly zone");
    expect(dialog()?.textContent).toContain("CTR Lisboa");
    expect(dialog()?.textContent).toContain("Conditions apply · GND – 120 m AGL");
    expect(dialog()?.textContent).toContain("Do you have authorisation to fly over these areas?");
    expect(document.activeElement).toBe(button("Back"));
  });

  it("lists every zone in the order the route passes them", async () => {
    checkRoute.mockResolvedValue({
      zones: [
        zone(1, "yellow", "CONDITIONAL"),
        zone(2, "orange", "REQUIRES_AUTHORISATION"),
        zone(3, "red", "PROHIBITED"),
        zone(4, "yellow-2", "CONDITIONAL"),
        zone(5, "yellow-3", "CONDITIONAL"),
      ],
    });
    await submitRoute();
    const names = [...document.querySelectorAll(".rw-name")].map((n) => n.textContent);
    expect(names).toEqual(["yellow", "orange", "red", "yellow-2", "yellow-3"]);
    const numbers = [...document.querySelectorAll(".rw-order")].map((n) => n.textContent);
    expect(numbers).toEqual(["1.", "2.", "3.", "4.", "5."]);
    expect((document.querySelector(".rw-item") as HTMLElement).style.borderLeftColor).toBe("rgb(230, 216, 74)");
  });

  it("sends the route when the operator continues", async () => {
    checkRoute.mockResolvedValue({ zones: [zone(1, "red", "PROHIBITED")] });
    await submitRoute();
    await click("Continue");
    expect(onSend).toHaveBeenCalledTimes(1);
    expect(onSend).toHaveBeenCalledWith("goto", null, WAYPOINTS);
    expect(dialog()).toBeNull();
  });

  it.each(["button", "Escape key"])("goes back to the route being edited with the %s", async (how) => {
    checkRoute.mockResolvedValue({ zones: [zone(1, "red", "PROHIBITED")] });
    await submitRoute();
    if (how === "button") await click("Back");
    else await act(async () => void fireEvent.keyDown(window, { key: "Escape" }));
    expect(dialog()).toBeNull();
    expect(onSend).not.toHaveBeenCalled();
    expect(onCancelPick).not.toHaveBeenCalled();
    expect(button("Confirm").disabled).toBe(false);
    expect(screen.getByText(/WP2/)).toBeTruthy();
  });

  it("says the route could not be checked and still allows continuing", async () => {
    checkRoute.mockRejectedValue(new Error("offline"));
    await submitRoute();
    expect(dialog()?.textContent).toContain("Could not check the route against no-fly zones. Do you want to continue?");
    expect(onSend).not.toHaveBeenCalled();
    await click("Continue");
    expect(onSend).toHaveBeenCalledWith("goto", null, WAYPOINTS);
  });

  it("checks and sends point B for change B", async () => {
    checkRoute.mockResolvedValue({ zones: [] });
    const b = WAYPOINTS[0];
    render(panel({ d: { ...drone, state: "M" }, draft: [b] }));
    await click(/Change B/);
    await click("Confirm");
    expect(checkRoute).toHaveBeenCalledWith([{ lon: -9, lat: 38.8 }, b]);
    expect(onSend).toHaveBeenCalledWith("changeb", b, []);
  });

  it("does not check commands without a route", async () => {
    render(panel());
    await click(/Return to base/);
    await click("Confirm");
    expect(checkRoute).not.toHaveBeenCalled();
    expect(onSend).toHaveBeenCalledWith("rtb", null, []);
  });

  it("cannot be confirmed twice while checking", async () => {
    const answer = pendingCheck();
    await submitRoute();
    expect(button("Checking route…").disabled).toBe(true);
    await click("Checking route…");
    await answer([]);
    expect(checkRoute).toHaveBeenCalledTimes(1);
    expect(onSend).toHaveBeenCalledTimes(1);
  });

  it("sends nothing when cancelled while checking", async () => {
    const answer = pendingCheck();
    await submitRoute();
    await click("Cancel");
    await answer([]);
    expect(onSend).not.toHaveBeenCalled();
    expect(dialog()).toBeNull();
  });

  it("discards the check when the route changes meanwhile", async () => {
    const answer = pendingCheck();
    const view = await submitRoute();
    view.rerender(panel({ draft: [...WAYPOINTS, { lon: -9.3, lat: 38.6 }] }));
    expect(button("Confirm").disabled).toBe(false);
    await answer([]);
    expect(onSend).not.toHaveBeenCalled();
    expect(dialog()).toBeNull();
  });

  it("sends nothing when the panel is closed while checking", async () => {
    const answer = pendingCheck();
    const view = await submitRoute();
    view.unmount();
    await answer([]);
    expect(onSend).not.toHaveBeenCalled();
  });

  it("does not allow continuing once commands are blocked", async () => {
    checkRoute.mockResolvedValue({ zones: [zone(1, "red", "PROHIBITED")] });
    const view = await submitRoute();
    view.rerender(panel({ draft: WAYPOINTS, feedDown: true }));
    expect(button("Continue").disabled).toBe(true);
    expect(dialog()?.textContent).toContain("Connection to the server lost");
  });
});
