import { useEffect, useState } from "react";
import { API_URL } from "../api/client";
import type { BackendStatus } from "../api/useBackendStatus";
import { WS_URL, type WsLink } from "../api/wsClient";
import { dtg } from "../domain/format";
import { wsLinkOf } from "../domain/link";

// Set by `make mock`; the link is hidden otherwise.
const MOCK_CONSOLE_URL = import.meta.env.VITE_MOCK_CONSOLE_URL;

interface Props {
  backend: BackendStatus;
  ws: WsLink | "local";
  uavCount: number;
  alertCount: number;
  settingsOpen: boolean;
  onToggleSettings: () => void;
}

export function TopBar({ backend, ws, uavCount, alertCount, settingsOpen, onToggleSettings }: Props) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const dot = backend.state === "online" ? "ok" : backend.state === "offline" ? "bad" : "wait";
  const text =
    backend.state === "checking"
      ? "Checking server…"
      : backend.state === "online"
        ? `Server online${backend.info ? ` · v${backend.info.version} · driver ${backend.info.driver}` : ""}`
        : `Server offline · ${API_URL}`;
  // Not `now`: that can be a second old right after a status change.
  const link = ws === "local" ? null : wsLinkOf(ws, Date.now());

  return (
    <header className="top">
      <div className="logo">
        <span className="logo-mark">X</span>
        <span className="cap">Project X · C2</span>
      </div>
      <div className="top-mid mono">
        <span>{dtg(now)}</span>
        <span className="muted">
          {uavCount} UAV · {alertCount} with alert
        </span>
      </div>
      <div className="top-r" title={backend.state === "offline" ? backend.error : undefined}>
        <span className={`dot ${dot}`} />
        <span>{text}</span>
        <span className={`mono top-link ${link ? `lk-${link.kind}` : "muted"}`} title={link ? `${link.label} · ${WS_URL}` : undefined}>
          {link === null ? "Data: local simulator" : link.label}
        </span>
        {MOCK_CONSOLE_URL && (
          <a className="mono" href={MOCK_CONSOLE_URL} target="_blank" rel="noreferrer">
            X-Verse mock console ↗
          </a>
        )}
        <button className="top-btn mono" onClick={onToggleSettings}>
          {settingsOpen ? "Back to map" : "Settings"}
        </button>
      </div>
    </header>
  );
}
