import { BASES } from "../domain/constants";
import { advance } from "../domain/geo";
import type { Drone, LonLat } from "../domain/types";

/** Colour of the actual route on the map and in the legend. */
export const ACTUAL_ROUTE_COLOR = "#FFC857";
/** Colour of the routes still to fly (to the destination, back to base) and of the raw trail. */
export const ROUTE_COLOR = "#80E0FF";

/** Line styles shared by the map layers (MapView) and the legend. `dash` is in line widths, as in MapLibre. */
export const LINE_STYLES = {
  route: { color: ROUTE_COLOR, width: 1.6, dash: [5, 4] },
  rtb: { color: ROUTE_COLOR, width: 1.6, dash: [1, 3] },
  actual: { color: ACTUAL_ROUTE_COLOR, width: 2.4, dash: undefined },
} as const;

type Coord = [number, number];

interface Props {
  kind: string;
  id: string;
}

type Feature = { type: "Feature"; properties: Props; geometry: { type: "LineString"; coordinates: Coord[] } };
type PolygonFeature = {
  type: "Feature";
  properties: Props;
  geometry: { type: "Polygon"; coordinates: Coord[][] };
};

function line(kind: string, coords: Coord[], id = ""): Feature {
  return { type: "Feature", properties: { kind, id }, geometry: { type: "LineString", coordinates: coords } };
}

function fovSector(drone: Drone): PolygonFeature | null {
  const { horizontal_fov: fov, visual_los: range } = drone;
  if (
    typeof fov !== "number" || !Number.isFinite(fov) || fov <= 0 || fov > 360 ||
    typeof range !== "number" || !Number.isFinite(range) || range <= 0 ||
    !Number.isFinite(drone.hdg)
  ) return null;

  const steps = Math.max(12, Math.ceil(fov / 5));
  const ring: Coord[] = [[drone.lon, drone.lat]];
  for (let i = 0; i <= steps; i++) {
    const heading = drone.hdg - fov / 2 + fov * i / steps;
    const point = advance(drone, heading, range);
    ring.push([point.lon, point.lat]);
  }
  ring.push([drone.lon, drone.lat]);
  return {
    type: "Feature",
    properties: { kind: "fov", id: drone.id },
    geometry: { type: "Polygon", coordinates: [ring] },
  };
}

/** Actual route flown: just the line (turns, deviations and curves are already part of its shape). */
function actualRoute(d: Drone): Feature[] {
  const track = d.track ?? [];
  return track.length < 2 ? [] : [line("actual", track, d.id)];
}

/** Builds the OSM overlay from actual routes (or raw trails), mission routes, RTB paths, and the draft destination. */
export function overlay(drones: Drone[], draft: LonLat | null | undefined, followId?: string, selectedId?: string | null) {
  const f: Array<Feature | PolygonFeature> = [];
  for (const d of drones) {
    // Field-of-view sectors are sensor coverage, so show them for every UAV regardless of selection.
    const sector = fovSector(d);
    if (sector) f.push(sector);
    // Paths show only for the drone the operator clicked (selected or followed), to keep the general map clean.
    if (d.id !== selectedId && d.id !== followId) continue;
    const actual = actualRoute(d);
    // The actual route replaces the raw trail; sources that do not send it yet still show the trail.
    if (actual.length) f.push(...actual);
    else if (d.trail.length > 1) f.push(line("trail", d.trail));
    // Remaining route: from where the drone is now to its destination, for every drone (like the RTB path).
    if (d.state === "M" && d.b) f.push(line("route", [[d.lon, d.lat], [d.b.lon, d.b.lat]]));
    if (d.state === "R") f.push(line("rtb", [[d.lon, d.lat], [BASES[d.base].lon, BASES[d.base].lat]]));
  }
  if (draft && followId) {
    const d = drones.find((x) => x.id === followId);
    if (d) f.push(line("draft", [[d.lon, d.lat], [draft.lon, draft.lat]]));
  }
  return { type: "FeatureCollection" as const, features: f };
}
