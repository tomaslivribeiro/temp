import { describe, expect, it } from "vitest";
import { initialDrones } from "../sim/simulator";
import type { Drone } from "../domain/types";
import { overlay } from "./mapOverlay";

const base = initialDrones().find((d) => d.id === "GOMES")!;
// No sensor by default, so the path tests only see path features; the FOV tests set it explicitly.
const drone = (over: Partial<Drone>): Drone => ({ ...base, horizontal_fov: null, visual_los: null, ...over });

const kinds = (fc: ReturnType<typeof overlay>) => fc.features.map((f) => f.properties.kind);

describe("map overlay", () => {
  it("draws the actual route as a single line, with no dots for origin or vertices", () => {
    const d = drone({
      state: "M",
      trail: [[0, 0], [1, 0]],
      track: [[0, 0], [1, 0], [1, 1], [1, 1.5]],
    });
    const fc = overlay([d], null, undefined, d.id);
    expect(kinds(fc)).not.toContain("trail");
    expect(kinds(fc)).toEqual(["actual"]);
    expect(fc.features[0].geometry).toEqual({ type: "LineString", coordinates: d.track });
  });

  it("keeps the actual route after the mission while hovering", () => {
    const d = drone({ state: "H", trail: [], track: [[0, 0], [1, 0]] });
    expect(kinds(overlay([d], null, undefined, d.id))).toEqual(["actual"]);
  });

  it("falls back to the raw trail when the source sends no actual route", () => {
    const d = drone({ state: "R", trail: [[0, 0], [1, 0]], track: undefined });
    expect(kinds(overlay([d], null, undefined, d.id))).toContain("trail");
  });

  it("draws no paths on the general map, only for the clicked drone", () => {
    const a = drone({ id: "A", state: "M", lon: 1, lat: 1, b: { lon: 5, lat: 5 }, track: [[0, 0], [1, 1]] });
    const b = drone({ id: "B", state: "R", lon: 2, lat: 3, track: [[0, 0], [2, 3]] });
    expect(overlay([a, b], null).features).toEqual([]);
    expect(kinds(overlay([a, b], null, undefined, "A"))).toEqual(["actual", "route"]);
    expect(kinds(overlay([a, b], null, "B", null))).toEqual(["actual", "rtb"]);
  });

  it("draws a UAV's sensor sector even when its route is not selected", () => {
    const d = drone({ horizontal_fov: 78, visual_los: 1000, hdg: 90 });
    const sector = overlay([d], null).features[0];
    expect(sector.properties.kind).toBe("fov");
    expect(sector.geometry.type).toBe("Polygon");
    if (sector.geometry.type === "Polygon") {
      expect(sector.geometry.coordinates[0][0]).toEqual([d.lon, d.lat]);
      const ring = sector.geometry.coordinates[0];
      expect(ring[ring.length - 1]).toEqual([d.lon, d.lat]);
    }
  });

  it("draws a sensor sector for every simulated UAV", () => {
    const drones = initialDrones();
    const sectors = overlay(drones, null).features.filter((f) => f.properties.kind === "fov");
    expect(sectors.map((f) => f.properties.id)).toEqual(drones.map((d) => d.id));
  });

  it("draws the remaining route from the current position to the destination of the clicked drone", () => {
    const a = drone({ id: "A", state: "M", lon: 1, lat: 1, a: { lon: 0, lat: 0 }, b: { lon: 5, lat: 5 } });
    const b = drone({ id: "B", state: "M", lon: 2, lat: 3, a: { lon: 0, lat: 0 }, b: { lon: 6, lat: 6 } });
    const routeOf = (id: string) =>
      overlay([a, b], null, undefined, id).features.find((f) => f.properties.kind === "route")?.geometry.coordinates;
    expect(routeOf("A")).toEqual([[1, 1], [5, 5]]);
    expect(routeOf("B")).toEqual([[2, 3], [6, 6]]);
  });
});
