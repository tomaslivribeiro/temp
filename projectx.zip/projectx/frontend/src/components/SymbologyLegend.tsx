import ms from "milsymbol";
import { useState } from "react";

import { buildSidc, type PlatformType } from "../symbology/sidc";
import { GEOZONE_STYLES, type Restriction } from "../domain/geozones";
import { LINE_STYLES } from "./mapOverlay";

interface LegendEntry {
  label: string;
  platform: PlatformType;
  status?: "PRESENT" | "DAMAGED";
}

const ENTRIES: LegendEntry[] = [
  { label: "Friend · rotary UAV", platform: "ROTARY_UAV" },
  { label: "Friend · fixed-wing UAV", platform: "FIXED_WING_UAV" },
  { label: "Friend · UGV (wheeled)", platform: "WHEELED_UGV" },
  { label: "Friend · USV", platform: "USV" },
  { label: "Friend · rotary UAV · damaged", platform: "ROTARY_UAV", status: "DAMAGED" },
];

/** Map line styles, taken from the same LINE_STYLES as the overlay layers in MapView. */
const ROUTE_ENTRIES = [
  { label: "Remaining route to destination", style: LINE_STYLES.route },
  { label: "Return to base", style: LINE_STYLES.rtb },
  { label: "Actual route", style: LINE_STYLES.actual },
];

type LineStyle = (typeof ROUTE_ENTRIES)[number]["style"];

function routeSwatch({ color, width, dash }: LineStyle) {
  // MapLibre dashes are in line widths; SVG dashes are in pixels.
  const svgDash = dash?.map((n) => n * width).join(" ");
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true">
      <line x1="1" y1="11" x2="21" y2="11" stroke={color} strokeWidth={width} strokeDasharray={svgDash} />
    </svg>
  );
}

function miniSymbol(e: LegendEntry): string {
  const sidc = buildSidc({
    affiliation: "FRIEND",
    platformType: e.platform,
    status: e.status ?? "PRESENT",
  });
  return new ms.Symbol(sidc, { size: 22, standard: "APP6" }).asSVG();
}

export function SymbologyLegend({ showZones = false }: { showZones?: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`legend${open ? " open" : ""}`}>
      <button type="button" className="lg-tg" onClick={() => setOpen(!open)}>
        Legend · APP-6 E
      </button>
      {open && (
        <ul className="lg-list">
          {ENTRIES.map((e) => (
            <li key={e.label}>
              <span className="lg-k" dangerouslySetInnerHTML={{ __html: miniSymbol(e) }} />
              <span className="lg-lbl">{e.label}</span>
            </li>
          ))}
          {ROUTE_ENTRIES.map((r) => (
            <li key={r.label}>
              <span className="lg-k">{routeSwatch(r.style)}</span>
              <span className="lg-lbl">{r.label}</span>
            </li>
          ))}
          {showZones &&
            (Object.keys(GEOZONE_STYLES) as Restriction[]).map((r) => (
              <li key={r}>
                <span className="lg-k">
                  <svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true">
                    <rect x="2" y="5" width="18" height="12" fill={GEOZONE_STYLES[r].color} fillOpacity={Math.max(GEOZONE_STYLES[r].fillOpacity, 0.25)} stroke={GEOZONE_STYLES[r].color} strokeWidth="1.2" />
                  </svg>
                </span>
                <span className="lg-lbl">Zone · {GEOZONE_STYLES[r].label}</span>
              </li>
            ))}
          <li className="lg-footnote">Lost telemetry: icon stays, colour desaturates.</li>
        </ul>
      )}
    </div>
  );
}
