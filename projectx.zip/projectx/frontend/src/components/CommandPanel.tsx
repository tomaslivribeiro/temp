import { useState } from "react";
import { ACTION_LABEL, POINT_B_ACTIONS, STAGES } from "../domain/constants";
import { actionStates, blockedReason, type Profile } from "../domain/commands";
import { fmtPosition } from "../domain/format";
import { linkOf } from "../domain/link";
import type { ActionId, Command, Drone, LonLat } from "../domain/types";

interface Props {
  drone: Drone;
  cmds: Command[];
  profile: Profile;
  feedDown: boolean;
  picking: boolean;
  draft: LonLat | null;
  onStartPick: (a: ActionId) => void;
  onCancelPick: () => void;
  onSend: (a: ActionId, b: LonLat | null) => void;
}

export function CommandPanel({ drone, cmds, profile, feedDown, picking, draft, onStartPick, onCancelPick, onSend }: Props) {
  const [pending, setPending] = useState<ActionId | null>(null);
  const link = linkOf(drone);
  const mine = cmds.filter((c) => c.droneId === drone.id);
  const active = mine.some((c) => !c.final);
  const blocked = blockedReason(drone, link, active, profile, feedDown);
  const actions = actionStates(drone, blocked !== "");
  const needsB = pending !== null && POINT_B_ACTIONS.includes(pending);

  const choose = (id: ActionId) => {
    setPending(id);
    if (POINT_B_ACTIONS.includes(id)) onStartPick(id);
  };
  const cancel = () => {
    setPending(null);
    onCancelPick();
  };
  const confirm = () => {
    if (!pending) return;
    onSend(pending, needsB ? draft : null);
    setPending(null);
  };

  return (
    <aside className="panel a-cmd">
      <h3 className="cap h">Commands</h3>
      {blocked && <p className="note info">{blocked}</p>}

      {pending ? (
        <div className="box">
          <strong>{ACTION_LABEL[pending]} · {drone.id}</strong>
          {needsB && (
            <p className="muted">{draft ? `Point B: ${fmtPosition(draft, drone.frame)}` : picking ? "Click the map to choose point B." : "Choose point B."}</p>
          )}
          <div className="btns">
            <button className="btn primary" disabled={needsB && !draft} onClick={confirm}>Confirm</button>
            <button className="btn" onClick={cancel}>Cancel</button>
          </div>
        </div>
      ) : (
        <div>
          {actions.map((a) => (
            <button key={a.id} className="cmdrow" disabled={a.disabled} onClick={() => choose(a.id)}>
              <span>{a.label}</span>
              <span className="muted sub">{a.sub}</span>
            </button>
          ))}
        </div>
      )}

      <h3 className="cap h">Command status</h3>
      {mine.length === 0 && <p className="muted">No commands sent.</p>}
      {[...mine].reverse().map((c) => (
        <div className="box" key={c.key}>
          <div className="h">
            <strong>{ACTION_LABEL[c.action]}</strong>
            <span className={`st-pill ${c.final === "completed" ? "c-done" : c.final === "rejected" ? "c-fail" : c.final === "unknown" ? "c-unk" : "c-run"}`}>
              {c.final ?? "in progress"}
            </span>
          </div>
          <ol className="stages">
            {STAGES.map((s, i) => (
              <li key={s} className={i <= c.stage ? "done" : ""}>
                <span>{s}</span>
                <span className="mono muted">{c.times[i] ?? ""}</span>
              </li>
            ))}
          </ol>
          {c.reason && <p className={`note${c.final === "rejected" ? " crit" : ""}`}>{c.reason}</p>}
        </div>
      ))}
    </aside>
  );
}
