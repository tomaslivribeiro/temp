import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "../api/client";
import { ACTION_LABEL, MAP_PICK_ACTIONS, STAGES } from "../domain/constants";
import { actionStates, blockedReason, type Profile } from "../domain/commands";
import { fmtPosition } from "../domain/format";
import type { GeozoneProperties } from "../domain/geozones";
import { linkOf } from "../domain/link";
import type { ActionId, Command, Drone, LonLat } from "../domain/types";
import { RouteWarningDialog } from "./RouteWarningDialog";

/** No-fly zone check of one drafted route. `zones` is null when it could not be checked. */
type RouteCheck = { draft: LonLat[] | null } & (
  | { status: "checking" }
  | { status: "warning"; zones: GeozoneProperties[] | null }
);

interface Props {
  drone: Drone;
  cmds: Command[];
  profile: Profile;
  feedDown: boolean;
  picking: boolean;
  draft: LonLat[] | null;
  onStartPick: (a: ActionId) => void;
  onCancelPick: () => void;
  onSend: (a: ActionId, b: LonLat | null, waypoints: LonLat[]) => void;
}

export function CommandPanel({ drone, cmds, profile, feedDown, picking, draft, onStartPick, onCancelPick, onSend }: Props) {
  const [pending, setPending] = useState<ActionId | null>(null);
  const link = linkOf(drone);
  const mine = cmds.filter((c) => c.droneId === drone.id);
  const active = mine.some((c) => !c.final);
  const blocked = blockedReason(drone, link, active, profile, feedDown);
  const actions = actionStates(drone, blocked !== "");
  const needsDestination = pending !== null && MAP_PICK_ACTIONS.includes(pending);
  const waypoints = draft ?? [];

  const [check, setCheck] = useState<RouteCheck | null>(null);
  // A check only holds for the route it was made for: editing the draft discards it.
  const current = check && check.draft === draft ? check : null;
  const latestDraft = useRef(draft);
  latestDraft.current = draft;
  // Bumped to ignore the answer of a check that was cancelled, or whose panel is gone.
  const request = useRef(0);
  useEffect(() => () => void request.current++, []);
  const discardCheck = useCallback(() => {
    request.current++;
    setCheck(null);
  }, []);

  // Map clicks append route points for goto but replace the one point used by changeb.
  const choose = (id: ActionId) => {
    setPending(id);
    if (MAP_PICK_ACTIONS.includes(id)) onStartPick(id);
  };
  const cancel = () => {
    discardCheck();
    setPending(null);
    onCancelPick();
  };
  const send = () => {
    if (!pending) return;
    onSend(pending, pending === "changeb" ? waypoints[0] ?? null : null, pending === "goto" ? waypoints : []);
    discardCheck();
    setPending(null);
  };
  // Routes drawn on the map are checked against the no-fly zones before they are sent.
  const confirm = async () => {
    if (!pending) return;
    if (!needsDestination) return send();
    const id = ++request.current;
    setCheck({ draft, status: "checking" });
    let zones: GeozoneProperties[] | null = null;
    try {
      zones = (await api.checkRoute([{ lon: drone.lon, lat: drone.lat }, ...waypoints])).zones;
    } catch {
      // Not verified: the operator is told and decides.
    }
    if (id !== request.current || latestDraft.current !== draft) return;
    if (zones?.length === 0) return send();
    setCheck({ draft, status: "warning", zones });
  };
  const stillAvailable = actions.some((a) => a.id === pending && !a.disabled);

  return (
    <aside className="panel a-cmd">
      <h3 className="cap h">Commands</h3>
      {blocked && <p className="note info">{blocked}</p>}

      {pending ? (
        <div className="box">
          <strong>{ACTION_LABEL[pending]} · {drone.id}</strong>
          {needsDestination && (
            <div className="muted">
              {pending === "goto" ? (
                waypoints.length ? (
                  <ol>
                    {waypoints.map((point, index) => (
                      <li key={index}>WP{index + 1}: {fmtPosition(point, drone.frame)}</li>
                    ))}
                  </ol>
                ) : <p>{picking ? "Click the map to add route waypoints." : "Add at least one waypoint."}</p>
              ) : (
                <p>{waypoints[0] ? `Point B: ${fmtPosition(waypoints[0], drone.frame)}` : picking ? "Click the map to choose point B." : "Choose point B."}</p>
              )}
            </div>
          )}
          <div className="btns">
            <button className="btn primary" disabled={(needsDestination && !waypoints.length) || current !== null} onClick={confirm}>
              {current?.status === "checking" ? "Checking route…" : "Confirm"}
            </button>
            <button className="btn" onClick={cancel}>Cancel</button>
          </div>
        </div>
      ) : (
        <div>
          {actions.map((a) => (
            <button key={a.id} className="cmdrow" disabled={a.disabled} onClick={() => choose(a.id)}>
              <span>{a.label}</span>
              <span className="muted sub">{a.sub}</span>
            </button>
          ))}
        </div>
      )}

      {pending && current?.status === "warning" && (
        <RouteWarningDialog
          zones={current.zones}
          canContinue={stillAvailable}
          blocked={stillAvailable ? "" : blocked || (actions.find((a) => a.id === pending)?.sub ?? "")}
          onBack={discardCheck}
          onContinue={send}
        />
      )}

      <h3 className="cap h">Command status</h3>
      {mine.length === 0 && <p className="muted">No commands sent.</p>}
      {[...mine].reverse().map((c) => (
        <div className="box" key={c.key}>
          <div className="h">
            <strong>{ACTION_LABEL[c.action]}</strong>
            <span className={`st-pill ${c.final === "completed" ? "c-done" : c.final === "rejected" ? "c-fail" : c.final === "unknown" ? "c-unk" : "c-run"}`}>
              {c.final ?? "in progress"}
            </span>
          </div>
          <ol className="stages">
            {STAGES.map((s, i) => (
              <li key={s} className={i <= c.stage ? "done" : ""}>
                <span>{s}</span>
                <span className="mono muted">{c.times[i] ?? ""}</span>
              </li>
            ))}
          </ol>
          {c.reason && <p className={`note${c.final === "rejected" ? " crit" : ""}`}>{c.reason}</p>}
        </div>
      ))}
    </aside>
  );
}
