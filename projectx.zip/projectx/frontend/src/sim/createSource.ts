import type { FleetSource } from "../domain/types";
import { LocalSimulator } from "./simulator";
import { WsFleetSource } from "./wsFleetSource";

/** VITE_FLEET_SOURCE=local runs the in-browser simulator (no backend needed); default is the backend. */
export function createSource(): FleetSource {
  return import.meta.env.VITE_FLEET_SOURCE === "local" ? new LocalSimulator() : new WsFleetSource();
}
