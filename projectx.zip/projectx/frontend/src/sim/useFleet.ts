import { useEffect, useReducer, useRef, useState } from "react";
import { INITIAL_LINK, type WsLink } from "../api/wsClient";
import { ageSnapshot, dataAgeS } from "../domain/link";
import type { ActionId, FleetSnapshot, FleetSource, LonLat } from "../domain/types";

/**
 * Subscribes to a FleetSource; `link` is the connection state ("local" for the simulator). While the
 * feed is down `snap` ages by the second, so per-drone status shows the real freshness of the data.
 */
export function useFleet(createSource: () => FleetSource): {
  snap: FleetSnapshot;
  link: WsLink | "local";
  feedDown: boolean;
  // Fleet sources accept an optional ordered waypoint array.
  send: (id: string, a: ActionId, b?: LonLat | null, waypoints?: LonLat[]) => void;
} {
  const ref = useRef<FleetSource | null>(null);
  if (!ref.current) ref.current = createSource();
  const src = ref.current;
  const [snap, setSnap] = useState(() => src.snapshot());
  const [link, setLink] = useState<WsLink>(INITIAL_LINK);
  const [, tick] = useReducer((n: number) => n + 1, 0);
  const feedDown = src.kind !== "local" && link.state !== "open";

  useEffect(() => src.start(setSnap, setLink), [src]);

  useEffect(() => {
    if (!feedDown) return;
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [feedDown]);

  return {
    snap: feedDown ? ageSnapshot(snap, dataAgeS(link, Date.now())) : snap,
    link: src.kind === "local" ? "local" : link,
    feedDown,
    send: (id, a, b, waypoints) => src.send(id, a, b, waypoints),
  };
}
