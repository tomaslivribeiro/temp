import { describe, expect, it, vi } from "vitest";
import { BASES } from "../domain/constants";
import { km } from "../domain/geo";
import type { Command } from "../domain/types";
import { initialDrones, LocalSimulator, stepCommand, stepDrone } from "./simulator";

describe("simulator", () => {
  it("moves a mission drone towards B and hovers on arrival", () => {
    let d = initialDrones().find((x) => x.id === "GAMA")!;
    const start = km(d, d.b!);
    d = stepDrone(d, 2);
    expect(km(d, { lon: -8.42, lat: 40.2 })).toBeLessThan(start);
    for (let t = 3; t < 200 && d.state === "M"; t++) d = stepDrone(d, t);
    expect(d.state).toBe("H");
  });

  it("returns to base, lands and ends in standby", () => {
    let d = initialDrones().find((x) => x.id === "BARTOLOMEU")!;
    for (let t = 1; t < 400 && d.state !== "S"; t++) d = stepDrone(d, t);
    expect(d.state).toBe("S");
    expect(km(d, BASES.CHARLIE)).toBeLessThan(0.1);
  });

  it("rejects goto when battery is below the minimum", () => {
    const d = { ...initialDrones().find((x) => x.id === "BARTOLOMEU")!, state: "H" as const, bat: 20 };
    const c: Command = { key: 1, droneId: d.id, action: "goto", b: { lon: -8, lat: 38 }, stage: 0, times: [] };
    const out = stepCommand(c, d, 0);
    expect(out.final).toBe("rejected");
  });

  it("tracks the actual route from the goto origin and keeps it after the mission", () => {
    vi.useFakeTimers();
    try {
      const sim = new LocalSimulator();
      let snap = sim.snapshot();
      const stop = sim.start((s) => { snap = s; });
      const gomes = () => snap.drones.find((x) => x.id === "GOMES")!;
      expect(snap.drones.find((x) => x.id === "GAMA")!.track?.[0]).toEqual([-9.1869, 38.7542]);
      const origin = [gomes().lon, gomes().lat];
      sim.send("GOMES", "goto", { lon: -8.5, lat: 41.2 });
      vi.advanceTimersByTime(5000); // the command pipeline applies the goto after a few ticks
      for (let i = 0; i < 60 && gomes().state !== "H"; i++) vi.advanceTimersByTime(1000);
      expect(gomes().state).toBe("H");
      expect(gomes().track?.[0]).toEqual(origin);
      expect(gomes().track?.at(-1)).toEqual([gomes().lon, gomes().lat]);
      stop();
    } finally {
      vi.useRealTimers();
    }
  });
});
