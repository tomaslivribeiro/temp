import { describe, expect, it } from "vitest";
import type { FleetSnapshot } from "../domain/types";
import { applyMessage } from "./wsFleetSource";

const base: FleetSnapshot = { t: 0, startMs: 123, drones: [], cmds: [] };

describe("applyMessage", () => {
  it("replaces drones and commands from a fleet.snapshot, keeping startMs", () => {
    const out = applyMessage(base, {
      type: "fleet.snapshot",
      payload: { t: 7, drones: [{ id: "GAMA" }], cmds: [] },
      ts: "",
    });
    expect(out.t).toBe(7);
    expect(out.drones).toHaveLength(1);
    expect(out.startMs).toBe(123);
  });

  it("ignores other message types", () => {
    expect(applyMessage(base, { type: "server.heartbeat", payload: {}, ts: "" })).toBe(base);
  });
});
