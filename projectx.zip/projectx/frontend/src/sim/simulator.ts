import { AIRBORNE, BASES, STAGES } from "../domain/constants";
import { hms } from "../domain/format";
import { ActualRoute } from "../domain/actualRoute";
import { bearing, km } from "../domain/geo";
import type { ActionId, BaseId, Command, Drone, FleetSnapshot, FleetSource, LonLat, StateCode } from "../domain/types";

const SPEED_KM_PER_TICK = 1.5;
const MIN_MISSION_BATTERY = 30;
const KEEP_COMMANDS = 30;
// Sensor geometry for the map's field-of-view sector; same values the X-Verse mock publishes.
const HORIZONTAL_FOV_DEG = 78;
const VISUAL_LOS_M = 1000;

function at(id: string, state: StateCode, base: BaseId, bat: number, over: Partial<Drone> = {}): Drone {
  const b = BASES[base];
  return {
    id, state, base, lon: b.lon, lat: b.lat, alt: b.elev, spd: 0, hdg: 0, bat, hb: 0,
    flaky: false, lost: false, gps: "good", sats: 14, trail: [], a: null, b: null, timer: 0,
    horizontal_fov: HORIZONTAL_FOV_DEG, visual_los: VISUAL_LOS_M, ...over,
  };
}

export function initialDrones(): Drone[] {
  return [
    at("EANES", "O", "ALFA", 100),
    at("TRISTÃO", "S", "ALFA", 96),
    at("GAMA", "M", "ALFA", 78, {
      lon: -8.919, lat: 39.26, alt: 420, spd: 65, hdg: 22,
      a: { lon: -9.1869, lat: 38.7542 }, b: { lon: -8.42, lat: 40.2 },
      trail: [[-9.1869, 38.7542], [-9.05, 39.0], [-8.919, 39.26]],
    }),
    at("GOMES", "H", "BRAVO", 61, { lon: -8.62, lat: 41.16, alt: 260, gps: "weak", sats: 5 }),
    at("BARTOLOMEU", "R", "CHARLIE", 24, {
      lon: -8.2, lat: 38.0, alt: 380, spd: 65, hdg: 25,
      trail: [[-8.5, 37.5], [-8.35, 37.75], [-8.2, 38.0]],
    }),
    at("DIOGO CÃO", "S", "BRAVO", 88),
    at("MAGALHÃES", "H", "BRAVO", 47, { lon: -6.78, lat: 41.72, alt: 900, hb: 38, lost: true }),
    at("CORTE-REAL", "G", "CHARLIE", 9, { lon: -8.66, lat: 37.16, alt: 40 }),
    at("ZARCO", "H", "CHARLIE", 72, { lon: -7.75, lat: 38.8, alt: 300, flaky: true }),
    at("CABRAL", "M", "DELTA", 83, {
          lon: -7.3, lat: 40.56, alt: 350, spd: 65, hdg: 20,
          a: { lon: -7.5022, lat: 40.1375 }, b: { lon: -7.0, lat: 41.2 },
          trail: [[-7.5022, 40.1375], [-7.4, 40.35], [-7.3, 40.56]],
    }),
  ];
}

function applyCommand(c: Command, d: Drone): void {
  switch (c.action) {
    case "poweron": d.state = "S"; break;
    case "poweroff": d.state = "O"; break;
    case "takeoff": d.state = "T"; d.timer = 0; break;
    case "goto":
    case "changeb":
      if (d.state === "S") d.alt += 120;
      d.state = "M";
      d.a = { lon: d.lon, lat: d.lat };
      // Goto owns an ordered list; changeb keeps the legacy single-destination behavior.
      d.route = c.action === "goto" ? (c.waypoints ?? (c.b ? [c.b] : [])) : (c.b ? [c.b] : []);
      d.routeIndex = 0;
      d.b = d.route[0] ?? null;
      d.trail = [[d.lon, d.lat]];
      break;
    case "hold": d.state = "H"; d.spd = 0; break;
    case "rtb": d.state = "R"; if (!d.trail.length) d.trail = [[d.lon, d.lat]]; break;
    case "land": d.state = "L"; d.timer = 0; break;
  }
}

function isDone(c: Command, d: Drone): boolean {
  switch (c.action) {
    case "goto":
    case "changeb":
    case "takeoff": return d.state === "H";
    case "rtb": return d.state === "S";
    case "land": return d.state === "S" || d.state === "G";
    default: return true;
  }
}

/** Advances a drone by one second of simulated time. */
export function stepDrone(d0: Drone, t: number): Drone {
  const d: Drone = { ...d0 };
  if (d.state === "O") { d.hb = 0; return d; }
  if (d.lost) d.hb += 1; else if (d.flaky) d.hb = t % 9; else d.hb = 0;
  if (d.hb >= 10) return d;

  if (d.state === "T") {
    d.timer += 1; d.alt += 30;
    if (d.timer >= 3) { d.state = "H"; d.timer = 0; }
  }
  if (d.state === "L") {
    d.timer += 1; d.spd = 0; d.alt = Math.max(BASES[d.base].elev, d.alt - 80);
    if (d.timer >= 4) {
      d.timer = 0;
      const bs = BASES[d.base];
      if (km(d, bs) < 0.8) {
        d.state = "S"; d.lon = bs.lon; d.lat = bs.lat; d.alt = bs.elev; d.trail = []; d.b = null;
      } else d.state = "G";
    }
  }
  const target: LonLat | null = d.state === "M" ? d.b : d.state === "R" ? BASES[d.base] : null;
  if (target) {
    const dist = km(d, target);
    d.hdg = bearing(d, target);
    if (dist <= SPEED_KM_PER_TICK) {
      d.lon = target.lon; d.lat = target.lat; d.trail = [...d.trail, [d.lon, d.lat]];
      if (d.state === "M") {
        // Advance the active destination without completing the mission until the final waypoint.
        const nextIndex = (d.routeIndex ?? 0) + 1;
        if (d.route?.[nextIndex]) {
          d.routeIndex = nextIndex;
          d.b = d.route[nextIndex];
        } else {
          d.state = "H"; d.spd = 0; d.trail = []; d.b = null; d.route = []; d.routeIndex = 0;
        }
      }
      else { d.state = "L"; d.timer = 0; }
    } else {
      const f = SPEED_KM_PER_TICK / dist;
      d.lon += (target.lon - d.lon) * f; d.lat += (target.lat - d.lat) * f; d.spd = 65;
      if (t % 2 === 0) d.trail = [...d.trail, [d.lon, d.lat] as [number, number]].slice(-150);
    }
  }
  if (AIRBORNE.includes(d.state)) d.bat = Math.max(0, d.bat - 0.04);
  return d;
}

/** Moves a command one step through its pipeline (Sent → … → Completed). Mutates the drone when it executes. */
export function stepCommand(c0: Command, d: Drone, nowMs: number): Command {
  const c: Command = { ...c0, times: [...c0.times] };
  if (c.final) return c;
  if (c.stage < 3) {
    c.stage += 1;
    c.times[c.stage] = hms(nowMs);
    if (c.stage === 1 && (c.action === "goto" || c.action === "changeb") && d.bat < MIN_MISSION_BATTERY) {
      c.final = "rejected";
      c.reason = `Rejected by server: battery too low for mission (${Math.round(d.bat)}%, minimum ${MIN_MISSION_BATTERY}%). Drone state unchanged.`;
    } else if (c.stage === 2 && d.hb >= 3) {
      c.final = "unknown";
      c.reason = "Link to drone degraded after sending. Result unknown: check the real drone state before retrying.";
    } else if (c.stage === 3) applyCommand(c, d);
  } else if (isDone(c, d)) {
    c.stage = STAGES.length - 1;
    c.times[c.stage] = hms(nowMs);
    c.final = "completed";
  }
  return c;
}

/** Local stand-in for the backend: same shape the WebSocket stream will deliver later. */
export class LocalSimulator implements FleetSource {
  readonly kind = "local" as const;
  private state: FleetSnapshot = { t: 0, startMs: Date.now(), drones: initialDrones(), cmds: [] };
  private seq = 0;
  private listener: ((s: FleetSnapshot) => void) | null = null;
  private readonly routes = new Map<string, ActualRoute>();

  constructor() {
    // Drones already flying start with the path they flew so far, like the backend simulator.
    const drones = this.state.drones.map((d) => {
      const route = new ActualRoute();
      for (const p of d.trail) route.update(p);
      this.routes.set(d.id, route);
      return { ...d, ...route.snapshotFields() };
    });
    this.state = { ...this.state, drones };
  }

  snapshot(): FleetSnapshot {
    return this.state;
  }

  start(listener: (s: FleetSnapshot) => void): () => void {
    this.listener = listener;
    const id = setInterval(() => this.tick(), 1000);
    return () => {
      clearInterval(id);
      this.listener = null;
    };
  }

  send(droneId: string, action: ActionId, b: LonLat | null = null, waypoints?: LonLat[]): void {
    const route = action === "goto" ? (waypoints ?? (b ? [b] : [])) : undefined;
    const destination = route?.[route.length - 1] ?? b;
    const c: Command = { key: ++this.seq, droneId, action, b: destination, ...(route ? { waypoints: route } : {}), stage: 0, times: [hms(Date.now())] };
    this.state = { ...this.state, cmds: [...this.state.cmds, c] };
    this.listener?.(this.state);
  }

  private tick(): void {
    const t = this.state.t + 1;
    const drones = this.state.drones.map((d) => stepDrone(d, t));
    const by = new Map(drones.map((d, i) => [d.id, i]));
    const now = Date.now();
    const cmds = this.state.cmds.map((c) => {
      const i = by.get(c.droneId)!;
      const d = { ...drones[i] };
      const next = stepCommand(c, d, now);
      if (c.stage < 3 && next.stage === 3 && c.action === "changeb" && !next.final) {
        this.routes.get(d.id)!.markVertex([d.lon, d.lat]);
      }
      if (next.final === "completed" && (c.action === "goto" || c.action === "changeb")) {
        // Final waypoint reached: clear the yellow real route while preserving it during intermediate legs.
        this.routes.get(d.id)!.clear();
        d.track = [];
      }
      // A new goto starts a new actual route; changeb keeps it, so the turn shows as a vertex.
      if (c.action === "goto" && c.stage < 3 && next.stage === 3 && !next.final) this.routes.get(d.id)!.reset([d.lon, d.lat]);
      drones[i] = d;
      return next;
    });
    for (let i = 0; i < drones.length; i++) {
      const d = drones[i];
      const route = this.routes.get(d.id)!;
      route.observe(d.state, [d.lon, d.lat]);
      drones[i] = { ...d, ...route.snapshotFields() };
    }
    this.state = { ...this.state, t, drones, cmds: cmds.slice(-KEEP_COMMANDS) };
    this.listener?.(this.state);
  }
}
