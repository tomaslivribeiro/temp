// @vitest-environment jsdom
import { act, cleanup, renderHook } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { WsLink } from "../api/wsClient";
import { linkOf } from "../domain/link";
import type { Drone, FleetSnapshot, FleetSource } from "../domain/types";
import { useFleet } from "./useFleet";

const drone = { id: "GAMA", state: "H", hb: 0 } as Drone;
const snap: FleetSnapshot = { t: 1, startMs: 0, drones: [drone], cmds: [] };

function fakeSource(kind: FleetSource["kind"]) {
  const src = {
    kind,
    snapshot: () => snap,
    send: vi.fn(),
    stop: vi.fn(),
    status: (_: WsLink) => {},
    start(_: (s: FleetSnapshot) => void, onStatus?: (s: WsLink) => void) {
      src.status = onStatus ?? src.status;
      return src.stop;
    },
  };
  return src;
}

describe("useFleet", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(100000);
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
  });

  it("shows the snapshot as is while the feed is up", () => {
    const src = fakeSource("ws");
    const { result } = renderHook(() => useFleet(() => src));
    act(() => src.status({ state: "open", attempt: 0, lastDataAt: Date.now() }));
    expect(result.current.feedDown).toBe(false);
    expect(result.current.snap).toBe(snap);
  });

  it("ages the drones second by second during an outage and recovers", () => {
    const src = fakeSource("ws");
    const { result } = renderHook(() => useFleet(() => src));
    const lastDataAt = Date.now();
    act(() => src.status({ state: "closed", attempt: 1, retryAt: lastDataAt + 1000, lastDataAt }));
    expect(result.current.feedDown).toBe(true);

    act(() => void vi.advanceTimersByTime(3000));
    expect(linkOf(result.current.snap.drones[0]).kind).toBe("delayed");
    act(() => void vi.advanceTimersByTime(21000));
    expect(result.current.snap.drones[0].hb).toBe(24);
    expect(linkOf(result.current.snap.drones[0]).kind).toBe("lost");

    act(() => src.status({ state: "open", attempt: 0, lastDataAt: Date.now() }));
    expect(result.current.feedDown).toBe(false);
    expect(result.current.snap).toBe(snap);
  });

  it("is never down on the local simulator", () => {
    const src = fakeSource("local");
    const { result } = renderHook(() => useFleet(() => src));
    expect(result.current.link).toBe("local");
    expect(result.current.feedDown).toBe(false);
  });

  it("stops the source on unmount", () => {
    const src = fakeSource("ws");
    renderHook(() => useFleet(() => src)).unmount();
    expect(src.stop).toHaveBeenCalledOnce();
  });
});
