import { API_URL } from "../api/client";
import { connectWs, FLEET_SNAPSHOT, type WsMessage, type WsLink } from "../api/wsClient";
import type { ActionId, FleetSnapshot, FleetSource, LonLat } from "../domain/types";

/** Applies a `fleet.snapshot` message; any other message leaves the state untouched. */
export function applyMessage(state: FleetSnapshot, m: WsMessage): FleetSnapshot {
  if (m.type !== FLEET_SNAPSHOT) return state;
  const p = m.payload as Pick<FleetSnapshot, "t" | "drones" | "cmds">;
  return { ...state, t: p.t, drones: p.drones, cmds: p.cmds };
}

/** Real data: the backend pushes snapshots over WebSocket; commands go out over HTTP. */
export class WsFleetSource implements FleetSource {
  readonly kind = "ws" as const;
  private state: FleetSnapshot = { t: 0, startMs: Date.now(), drones: [], cmds: [] };

  snapshot(): FleetSnapshot {
    return this.state;
  }

  start(listener: (s: FleetSnapshot) => void, onStatus?: (s: WsLink) => void): () => void {
    return connectWs({
      onStatus,
      onMessage: (m) => {
        const next = applyMessage(this.state, m);
        if (next !== this.state) {
          this.state = next;
          listener(next);
        }
      },
    });
  }

  send(droneId: string, action: ActionId, b: LonLat | null = null): void {
    fetch(`${API_URL}/uavs/${encodeURIComponent(droneId)}/commands`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, b }),
    })
      .then((r) => {
        if (!r.ok) console.error(`Command ${action} for ${droneId} refused: HTTP ${r.status}`);
      })
      .catch((e) => console.error(`Command ${action} for ${droneId} failed`, e));
  }
}
