import { useSyncExternalStore } from "react";

/** Optional map layers an operator can switch on and off. */
export interface LayerChoice {
  geozones: boolean;
}

const KEY = "c2.layers";
const DEFAULTS: LayerChoice = { geozones: true };
const listeners = new Set<() => void>();

function read(): LayerChoice {
  try {
    const stored = JSON.parse(localStorage.getItem(KEY) ?? "null") as Partial<LayerChoice> | null;
    return { geozones: typeof stored?.geozones === "boolean" ? stored.geozones : DEFAULTS.geozones };
  } catch {
    return DEFAULTS;
  }
}

let current = read();

export function getLayerChoice(): LayerChoice {
  return current;
}

export function setLayerChoice(patch: Partial<LayerChoice>) {
  current = { ...current, ...patch };
  try {
    localStorage.setItem(KEY, JSON.stringify(current));
  } catch {
    // Storage can be blocked; the choice still applies for this session.
  }
  listeners.forEach((l) => l());
}

/** Which optional layers are on, shared by every view and remembered across reloads. */
export function useLayerChoice(): [LayerChoice, (patch: Partial<LayerChoice>) => void] {
  const choice = useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => void listeners.delete(l);
    },
    () => current,
  );
  return [choice, setLayerChoice];
}
