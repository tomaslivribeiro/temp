import { useSyncExternalStore } from "react";
import { DEFAULT_MAP, isMapId, type MapId } from "./registry";

const KEY = "c2.map";
const listeners = new Set<() => void>();

function read(): MapId {
  try {
    const v = localStorage.getItem(KEY);
    return isMapId(v) ? v : DEFAULT_MAP;
  } catch {
    return DEFAULT_MAP;
  }
}

let current = read();

export function setMapChoice(id: MapId) {
  current = id;
  try {
    localStorage.setItem(KEY, id);
  } catch {
    // Storage can be blocked; the choice still applies for this session.
  }
  listeners.forEach((l) => l());
}

/** The selected map, shared by every view and remembered across reloads. */
export function useMapChoice(): [MapId, (id: MapId) => void] {
  const id = useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => void listeners.delete(l);
    },
    () => current,
  );
  return [id, setMapChoice];
}
