/** Every map the console can show. To add one: add an entry here and handle its id in MapView. */
export const MAPS = [
  { id: "xverse", label: "X-Verse", hint: "Local floorplan" },
  { id: "osm", label: "OpenStreetMap", hint: "Geographic tiles" },
] as const;

export type MapId = (typeof MAPS)[number]["id"];

export const DEFAULT_MAP: MapId = "xverse";

export function isMapId(v: unknown): v is MapId {
  return MAPS.some((m) => m.id === v);
}
