# Frontend design reference

`prototype/` is a **design mockup** (exported HTML, "Project X · Fleet"), not production code.
Use it as a visual reference: colors, fonts (IBM Plex Mono / Sans Condensed), spacing, radii and layout live in the inline styles of `Main.dc.html`. Reimplement them in the React components under `src/`.

To view it, serve the folder and open `Main.dc.html` (some browsers block the scripts over `file://`):
```
cd frontend/design/prototype
python3 -m http.server 8080
```
It is not part of the Docker build or the app bundle.
